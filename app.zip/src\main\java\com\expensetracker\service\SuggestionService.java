package com.expensetracker.service;

import com.expensetracker.dto.SmartSuggestionDto;
import com.expensetracker.model.Transaction;
import com.expensetracker.model.User;
import com.expensetracker.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SuggestionService {

    @Autowired
    private TransactionRepository transactionRepository;

    public List<SmartSuggestionDto> generateSuggestions(User user) {
        List<SmartSuggestionDto> suggestions = new ArrayList<>();
        YearMonth currentYm = YearMonth.now();
        LocalDate startOfMonth = currentYm.atDay(1);
        LocalDate endOfMonth = currentYm.atEndOfMonth();

        BigDecimal monthlyIncome = transactionRepository.sumAmountByUserIdAndTypeAndDateBetween(
                user.getId(), "INCOME", startOfMonth, endOfMonth);
        if (monthlyIncome == null) monthlyIncome = BigDecimal.ZERO;

        BigDecimal monthlyExpense = transactionRepository.sumAmountByUserIdAndTypeAndDateBetween(
                user.getId(), "EXPENSE", startOfMonth, endOfMonth);
        if (monthlyExpense == null) monthlyExpense = BigDecimal.ZERO;

        List<Transaction> monthlyTx = transactionRepository.findByUserIdAndTransactionDateBetween(
                user.getId(), startOfMonth, endOfMonth);

        // 1. Food Expense Analysis
        BigDecimal foodSpend = BigDecimal.ZERO;
        for (Transaction t : monthlyTx) {
            if (t != null && "EXPENSE".equalsIgnoreCase(t.getType()) && t.getCategory() != null && t.getAmount() != null) {
                String catName = t.getCategory().getName();
                if ("Food".equalsIgnoreCase(catName) || "Grocery".equalsIgnoreCase(catName)) {
                    foodSpend = foodSpend.add(t.getAmount());
                }
            }
        }

        String currency = (user.getCurrency() != null && !user.getCurrency().isEmpty()) ? user.getCurrency() : "₹";

        if (monthlyExpense.compareTo(BigDecimal.ZERO) > 0) {
            double foodRatio = foodSpend.divide(monthlyExpense, 4, RoundingMode.HALF_UP).doubleValue();
            if (foodRatio > 0.25) {
                suggestions.add(new SmartSuggestionDto(
                        "FOOD",
                        "High Dining & Food Spending",
                        "Your food & dining expenses account for " + Math.round(foodRatio * 100) + "% (" + currency + foodSpend + ") of this month's total spending. Consider meal planning or setting a separate weekly food budget.",
                        "HIGH",
                        "fa-utensils",
                        "#budget"
                ));
            }
        }

        // 2. Shopping Expense Analysis
        BigDecimal shoppingSpend = BigDecimal.ZERO;
        for (Transaction t : monthlyTx) {
            if (t != null && "EXPENSE".equalsIgnoreCase(t.getType()) && t.getCategory() != null && t.getAmount() != null) {
                if ("Shopping".equalsIgnoreCase(t.getCategory().getName())) {
                    shoppingSpend = shoppingSpend.add(t.getAmount());
                }
            }
        }

        if (monthlyExpense.compareTo(BigDecimal.ZERO) > 0) {
            double shoppingRatio = shoppingSpend.divide(monthlyExpense, 4, RoundingMode.HALF_UP).doubleValue();
            if (shoppingRatio > 0.20) {
                suggestions.add(new SmartSuggestionDto(
                        "SHOPPING",
                        "Shopping Discretionary Spending Alert",
                        "Shopping represents " + Math.round(shoppingRatio * 100) + "% (" + currency + shoppingSpend + ") of your monthly expenses. Review recent purchases to distinguish between essentials and impulsive buys.",
                        "MEDIUM",
                        "fa-bag-shopping",
                        "#transactions"
                ));
            }
        }

        // 3. Savings Rate Check
        if (monthlyIncome.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal savings = monthlyIncome.subtract(monthlyExpense);
            double savingsRate = savings.divide(monthlyIncome, 4, RoundingMode.HALF_UP).doubleValue();
            if (savingsRate < 0.20) {
                suggestions.add(new SmartSuggestionDto(
                        "SAVINGS",
                        "Low Monthly Savings Rate",
                        "Your current savings rate is " + Math.round(savingsRate * 100) + "% (" + user.getCurrency() + savings + "). Financial experts recommend saving at least 20% of your income. Consider reducing non-essential expenses.",
                        "HIGH",
                        "fa-piggy-bank",
                        "#budget"
                ));
            } else {
                suggestions.add(new SmartSuggestionDto(
                        "SAVINGS",
                        "Healthy Savings Rate",
                        "Great job! You are currently saving " + Math.round(savingsRate * 100) + "% (" + user.getCurrency() + savings + ") of your income this month. Keep up the disciplined financial habit!",
                        "LOW",
                        "fa-circle-check",
                        "#analysis"
                ));
            }
        }

        // 4. Repeated Subscriptions Detection
        List<Transaction> allRecentExpenses = transactionRepository.findByUserIdOrderByTransactionDateDescCreatedAtDesc(user.getId())
                .stream().filter(t -> "EXPENSE".equalsIgnoreCase(t.getType()))
                .collect(Collectors.toList());

        Map<String, Long> recurringKeywords = new HashMap<>();
        String[] subscriptionKeywords = {"netflix", "spotify", "prime", "gym", "hotstar", "youtube", "icloud", "chatgpt", "subscription"};

        for (Transaction t : allRecentExpenses) {
            String desc = t.getDescription().toLowerCase();
            for (String kw : subscriptionKeywords) {
                if (desc.contains(kw)) {
                    recurringKeywords.put(kw, recurringKeywords.getOrDefault(kw, 0L) + 1);
                }
            }
        }

        long activeSubscriptions = recurringKeywords.values().stream().filter(count -> count >= 1).count();
        if (activeSubscriptions >= 2) {
            suggestions.add(new SmartSuggestionDto(
                    "SUBSCRIPTIONS",
                    "Multiple Active Recurring Subscriptions",
                    "We detected " + activeSubscriptions + " recurring digital service charges (" + String.join(", ", recurringKeywords.keySet()) + "). Review them periodically to cancel unused memberships and save money.",
                    "MEDIUM",
                    "fa-repeat",
                    "#transactions"
            ));
        }

        // Default suggestion if few transactions
        if (suggestions.isEmpty()) {
            suggestions.add(new SmartSuggestionDto(
                    "GENERAL",
                    "Track Daily Expenses Regularly",
                    "Consistent tracking is the key to financial freedom. Remember to log your UPI and cash micro-transactions as they happen.",
                    "LOW",
                    "fa-lightbulb",
                    "#transactions"
            ));
        }

        return suggestions;
    }
}
