package com.expensetracker.model;

import jakarta.persistence.*;

@Entity
@Table(name = "categories")
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user; // null if default category, non-null if custom

    @Column(nullable = false, length = 50)
    private String name;

    @Column(length = 50)
    private String icon = "fa-tags";

    @Column(length = 255)
    private String description;

    public Category() {}

    public Category(String name, String icon, String description, User user) {
        this.name = name;
        this.icon = icon != null ? icon : "fa-tags";
        this.description = description;
        this.user = user;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
