$s = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$loginBody = '{"email":"demo@expensetracker.com","password":"Password123"}'
$login = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/login" -Method Post -ContentType "application/json" -Body $loginBody -WebSession $s
Write-Host "Login: $($login.message)" -ForegroundColor Cyan

# 1. Transaction Create
try {
    $newTx = @{
        amount = 350.50
        type = "EXPENSE"
        categoryId = 1
        description = "Test Coffee & Snack"
        transactionDate = "2026-09-21"
        paymentMethod = "UPI"
        merchantName = "Test Cafe"
        notes = "Automated test note"
    } | ConvertTo-Json
    $txRes = Invoke-RestMethod -Uri "http://localhost:8080/api/transactions" -Method Post -ContentType "application/json" -Body $newTx -WebSession $s
    Write-Host "[PASS] Create Transaction (ID: $($txRes.id))" -ForegroundColor Green

    # Update Transaction
    $updateTx = @{
        amount = 400.00
        type = "EXPENSE"
        categoryId = 1
        description = "Updated Coffee & Snack"
        transactionDate = "2026-09-21"
        paymentMethod = "CASH"
        merchantName = "Test Cafe Updated"
    } | ConvertTo-Json
    $upRes = Invoke-RestMethod -Uri "http://localhost:8080/api/transactions/$($txRes.id)" -Method Put -ContentType "application/json" -Body $updateTx -WebSession $s
    Write-Host "[PASS] Update Transaction (New Amount: $($upRes.amount))" -ForegroundColor Green

    # Delete Transaction
    Invoke-RestMethod -Uri "http://localhost:8080/api/transactions/$($txRes.id)" -Method Delete -WebSession $s
    Write-Host "[PASS] Delete Transaction" -ForegroundColor Green
} catch {
    Write-Host "[FAIL] Transaction Mutation: $($_.Exception.Message)" -ForegroundColor Red
}

# 2. Category Create, Update, Delete
try {
    $newCat = @{
        name = "Test Category"
        icon = "fa-flask"
        description = "Temporary test category"
    } | ConvertTo-Json
    $catRes = Invoke-RestMethod -Uri "http://localhost:8080/api/categories" -Method Post -ContentType "application/json" -Body $newCat -WebSession $s
    Write-Host "[PASS] Create Category (ID: $($catRes.id))" -ForegroundColor Green

    $updateCat = @{
        name = "Test Category Renamed"
        icon = "fa-vial"
        description = "Updated test description"
    } | ConvertTo-Json
    $catUp = Invoke-RestMethod -Uri "http://localhost:8080/api/categories/$($catRes.id)" -Method Put -ContentType "application/json" -Body $updateCat -WebSession $s
    Write-Host "[PASS] Update Category" -ForegroundColor Green

    Invoke-RestMethod -Uri "http://localhost:8080/api/categories/$($catRes.id)" -Method Delete -WebSession $s
    Write-Host "[PASS] Delete Category" -ForegroundColor Green
} catch {
    Write-Host "[FAIL] Category Mutation: $($_.Exception.Message)" -ForegroundColor Red
}

# 3. Budget Set
try {
    $setBudget = @{
        month = 9
        year = 2026
        amount = "45000.00"
    } | ConvertTo-Json
    $bRes = Invoke-RestMethod -Uri "http://localhost:8080/api/budget" -Method Post -ContentType "application/json" -Body $setBudget -WebSession $s
    Write-Host "[PASS] Set Budget (Amount: $($bRes.amount))" -ForegroundColor Green
} catch {
    Write-Host "[FAIL] Budget Mutation: $($_.Exception.Message)" -ForegroundColor Red
}

# 4. Alerts Mark Read
try {
    Invoke-RestMethod -Uri "http://localhost:8080/api/alerts/mark-all-read" -Method Put -WebSession $s
    $cnt = Invoke-RestMethod -Uri "http://localhost:8080/api/alerts/unread-count" -Method Get -WebSession $s
    Write-Host "[PASS] Mark All Alerts Read (Unread: $($cnt.count))" -ForegroundColor Green
} catch {
    Write-Host "[FAIL] Alerts Mutation: $($_.Exception.Message)" -ForegroundColor Red
}

# 5. Bank Confirm
try {
    $pending = Invoke-RestMethod -Uri "http://localhost:8080/api/bank/pending" -Method Get -WebSession $s
    if ($pending.Count -gt 0) {
        $singleJson = $pending[0] | ConvertTo-Json
        $confirmItem = "[$singleJson]"
        $confirmRes = Invoke-RestMethod -Uri "http://localhost:8080/api/bank/confirm" -Method Post -ContentType "application/json" -Body $confirmItem -WebSession $s
        Write-Host "[PASS] Confirm Bank Tx: $($confirmRes.message)" -ForegroundColor Green
    } else {
        Write-Host "[SKIP] No pending bank transactions to confirm" -ForegroundColor Yellow
    }
} catch {
    Write-Host "[FAIL] Bank Confirm: $($_.Exception.Message)" -ForegroundColor Red
}
