package com.expensetracker.controller;

import com.expensetracker.model.Alert;
import com.expensetracker.model.User;
import com.expensetracker.security.SecurityUtil;
import com.expensetracker.service.AlertService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/alerts")
public class AlertController {

    @Autowired
    private AlertService alertService;

    @Autowired
    private SecurityUtil securityUtil;

    @GetMapping
    public ResponseEntity<List<Alert>> getAllAlerts(@RequestParam(required = false, defaultValue = "false") boolean unreadOnly) {
        User user = securityUtil.getRequiredCurrentUser();
        List<Alert> list = unreadOnly ? alertService.getUnreadAlerts(user.getId()) : alertService.getAllAlerts(user.getId());
        return ResponseEntity.ok(list);
    }

    @GetMapping("/unread-count")
    public ResponseEntity<Map<String, Object>> getUnreadCount() {
        User user = securityUtil.getRequiredCurrentUser();
        long count = alertService.getUnreadCount(user.getId());
        Map<String, Object> map = new HashMap<>();
        map.put("count", count);
        return ResponseEntity.ok(map);
    }

    @PutMapping("/{id}/read")
    public ResponseEntity<Void> markAsRead(@PathVariable Long id) {
        User user = securityUtil.getRequiredCurrentUser();
        alertService.markAsRead(id, user.getId());
        return ResponseEntity.ok().build();
    }

    @PutMapping("/mark-all-read")
    public ResponseEntity<Void> markAllAsRead() {
        User user = securityUtil.getRequiredCurrentUser();
        alertService.markAllAsRead(user.getId());
        return ResponseEntity.ok().build();
    }
}
