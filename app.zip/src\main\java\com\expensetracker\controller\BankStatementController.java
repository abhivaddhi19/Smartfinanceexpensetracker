package com.expensetracker.controller;

import com.expensetracker.dto.BankImportItemDto;
import com.expensetracker.model.User;
import com.expensetracker.security.SecurityUtil;
import com.expensetracker.service.BankStatementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bank")
public class BankStatementController {

    @Autowired
    private BankStatementService bankStatementService;

    @Autowired
    private SecurityUtil securityUtil;

    @PostMapping("/import")
    public ResponseEntity<?> importStatement(@RequestParam("file") MultipartFile file) {
        User user = securityUtil.getRequiredCurrentUser();
        try {
            List<BankImportItemDto> items = bankStatementService.parseAndStageStatement(file, user);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Bank statement parsed successfully! " + items.size() + " transactions found for review.");
            response.put("transactions", items);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Failed to process bank statement: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @GetMapping("/pending")
    public ResponseEntity<List<BankImportItemDto>> getPendingTransactions() {
        User user = securityUtil.getRequiredCurrentUser();
        return ResponseEntity.ok(bankStatementService.getPendingTransactions(user));
    }

    @PostMapping("/confirm")
    public ResponseEntity<Map<String, Object>> confirmTransactions(@RequestBody List<BankImportItemDto> items) {
        User user = securityUtil.getRequiredCurrentUser();
        int confirmed = bankStatementService.confirmTransactions(user, items);

        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("confirmedCount", confirmed);
        response.put("message", confirmed + " bank transactions successfully imported and saved.");
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/pending")
    public ResponseEntity<Map<String, Object>> clearPendingTransactions() {
        User user = securityUtil.getRequiredCurrentUser();
        int count = bankStatementService.clearPendingTransactions(user);

        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("clearedCount", count);
        response.put("message", count + " pending bank transactions cleared.");
        return ResponseEntity.ok(response);
    }
}
