package com.expensetracker.repository;

import com.expensetracker.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {

    @Query("SELECT c FROM Category c WHERE c.user IS NULL OR c.user.id = :userId ORDER BY c.name ASC")
    List<Category> findAllForUser(@Param("userId") Long userId);

    List<Category> findByUserId(Long userId);

    Optional<Category> findByNameIgnoreCaseAndUserId(String name, Long userId);

    Optional<Category> findByNameIgnoreCaseAndUserIsNull(String name);

    default Optional<Category> findByNameIgnoreCaseForUser(String name, Long userId) {
        Optional<Category> userCat = findByNameIgnoreCaseAndUserId(name, userId);
        if (userCat.isPresent()) return userCat;
        return findByNameIgnoreCaseAndUserIsNull(name);
    }
}
