package com.expensetracker.service;

import com.expensetracker.dto.AnalysisDto;
import com.expensetracker.dto.BudgetDto;
import com.expensetracker.dto.TransactionDto;
import com.expensetracker.model.Category;
import com.expensetracker.model.Transaction;
import com.expensetracker.model.User;
import com.expensetracker.repository.CategoryRepository;
import com.expensetracker.repository.TransactionRepository;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReportService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private BudgetService budgetService;

    @Autowired
    private AnalysisService analysisService;

    @Autowired
    private TransactionService transactionService;

    public Map<String, Object> getMonthlyReportData(User user, int month, int year) {
        YearMonth ym = YearMonth.of(year, month);
        LocalDate start = ym.atDay(1);
        LocalDate end = ym.atEndOfMonth();

        BigDecimal income = transactionRepository.sumAmountByUserIdAndTypeAndDateBetween(user.getId(), "INCOME", start, end);
        if (income == null) income = BigDecimal.ZERO;

        BigDecimal expense = transactionRepository.sumAmountByUserIdAndTypeAndDateBetween(user.getId(), "EXPENSE", start, end);
        if (expense == null) expense = BigDecimal.ZERO;

        BigDecimal savings = income.subtract(expense);

        BudgetDto budget = budgetService.getBudgetDetails(user, month, year);
        List<AnalysisDto.CategoryShare> categoryBreakdown = analysisService.getCategoryExpenses(user, start, end);

        List<Transaction> monthlyTx = transactionRepository.findByUserIdAndTransactionDateBetween(user.getId(), start, end);


        String highestCategory = categoryBreakdown.isEmpty() ? "None" : categoryBreakdown.get(0).getName();
        BigDecimal highestCategoryAmount = categoryBreakdown.isEmpty() ? BigDecimal.ZERO : categoryBreakdown.get(0).getAmount();

        // Weekly analysis data available via analysisService if needed

        int daysInMonth = ym.lengthOfMonth();
        BigDecimal avgDaily = expense.divide(BigDecimal.valueOf(daysInMonth), 2, RoundingMode.HALF_UP);

        Map<String, Object> report = new LinkedHashMap<>();
        report.put("userName", user.getName());
        report.put("userEmail", user.getEmail());
        report.put("month", ym.getMonth().toString());
        report.put("monthValue", month);
        report.put("year", year);
        report.put("currency", user.getCurrency());
        report.put("totalIncome", income);
        report.put("totalExpense", expense);
        report.put("totalSavings", savings);
        report.put("monthlyBudget", budget.getAmount());
        report.put("remainingBudget", budget.getRemaining());
        report.put("budgetUsagePercentage", budget.getUsagePercentage());
        report.put("highestCategory", highestCategory);
        report.put("highestCategoryAmount", highestCategoryAmount);
        report.put("averageDailyExpense", avgDaily);
        report.put("transactionCount", monthlyTx.size());
        report.put("categories", categoryBreakdown);
        report.put("transactions", monthlyTx.stream().map(transactionService::toDto).collect(Collectors.toList()));

        return report;
    }

    public Map<String, Object> getCategoryReportData(User user, Long categoryId, int month, int year) {
        YearMonth ym = YearMonth.of(year, month);
        LocalDate start = ym.atDay(1);
        LocalDate end = ym.atEndOfMonth();

        Category category = categoryRepository.findById(Objects.requireNonNull(categoryId))
                .orElseThrow(() -> new IllegalArgumentException("Category not found"));

        List<Transaction> txList = transactionRepository.findByUserIdAndCategoryIdAndTransactionDateBetween(
                user.getId(), categoryId, start, end);

        BigDecimal totalSpend = BigDecimal.ZERO;
        for (Transaction t : txList) {
            if (t != null && "EXPENSE".equalsIgnoreCase(t.getType()) && t.getAmount() != null) {
                totalSpend = totalSpend.add(t.getAmount());
            }
        }

        BigDecimal totalMonthlyExpense = transactionRepository.sumAmountByUserIdAndTypeAndDateBetween(
                user.getId(), "EXPENSE", start, end);
        if (totalMonthlyExpense == null || totalMonthlyExpense.compareTo(BigDecimal.ZERO) == 0) {
            totalMonthlyExpense = BigDecimal.ONE;
        }

        double percentage = totalSpend.divide(totalMonthlyExpense, 4, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100)).doubleValue();

        BigDecimal avgTx = txList.isEmpty() ? BigDecimal.ZERO :
                totalSpend.divide(BigDecimal.valueOf(txList.size()), 2, RoundingMode.HALF_UP);

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("categoryId", category.getId());
        data.put("categoryName", category.getName());
        data.put("categoryIcon", category.getIcon());
        data.put("totalSpending", totalSpend);
        data.put("transactionCount", txList.size());
        data.put("averageTransaction", avgTx);
        data.put("percentageOfTotalExpenses", Math.round(percentage * 10.0) / 10.0);
        data.put("transactions", txList.stream().map(transactionService::toDto).collect(Collectors.toList()));

        return data;
    }

    public byte[] generateMonthlyPdfReport(User user, int month, int year) {
        Map<String, Object> report = getMonthlyReportData(user, month, year);

        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Document document = new Document(PageSize.A4, 36, 36, 36, 36);
            PdfWriter.getInstance(document, out);
            document.open();

            // Colors
            Color primaryColor = new Color(79, 70, 229); // #4f46e5
            Color darkColor = new Color(30, 41, 59); // #1e293b
            // Light background color: new Color(248, 250, 252) available if needed
            Color accentColor = new Color(16, 185, 129); // #10b981
            Color dangerColor = new Color(239, 68, 68);

            // Fonts
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20, primaryColor);
            Font subtitleFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Color.GRAY);
            Font sectionFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 13, darkColor);
            Font regularFont = FontFactory.getFont(FontFactory.HELVETICA, 9, darkColor);
            Font boldFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, darkColor);
            Font whiteBoldFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, Color.WHITE);

            // Title Banner
            Paragraph title = new Paragraph("SMART EXPENSE TRACKER & PERSONAL FINANCE", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            Paragraph subtitle = new Paragraph("Monthly Financial Summary Report - " + report.get("month") + " " + report.get("year"), subtitleFont);
            subtitle.setAlignment(Element.ALIGN_CENTER);
            subtitle.setSpacingAfter(15);
            document.add(subtitle);

            // User Info & Metadata Table
            PdfPTable infoTable = new PdfPTable(2);
            infoTable.setWidthPercentage(100);
            infoTable.setSpacingAfter(15);

            PdfPCell userCell = new PdfPCell();
            userCell.setBorder(Rectangle.NO_BORDER);
            userCell.addElement(new Paragraph("Account Holder: " + report.get("userName"), boldFont));
            userCell.addElement(new Paragraph("Email: " + report.get("userEmail"), regularFont));
            userCell.addElement(new Paragraph("Generated On: " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")), regularFont));
            infoTable.addCell(userCell);

            PdfPCell statusCell = new PdfPCell();
            statusCell.setBorder(Rectangle.NO_BORDER);
            statusCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
            statusCell.addElement(new Paragraph("Budget Status: " + report.get("budgetUsagePercentage") + "% Used", boldFont));
            statusCell.addElement(new Paragraph("Total Transactions: " + report.get("transactionCount"), regularFont));
            statusCell.addElement(new Paragraph("Currency: INR (" + report.get("currency") + ")", regularFont));
            infoTable.addCell(statusCell);

            document.add(infoTable);

            // Financial Summary Cards Table
            Paragraph sumTitle = new Paragraph("Financial Overview", sectionFont);
            sumTitle.setSpacingAfter(8);
            document.add(sumTitle);

            PdfPTable summaryTable = new PdfPTable(4);
            summaryTable.setWidthPercentage(100);
            summaryTable.setSpacingAfter(15);

            String curr = (String) report.get("currency");
            addMetricCell(summaryTable, "Total Income", curr + report.get("totalIncome"), accentColor, whiteBoldFont);
            addMetricCell(summaryTable, "Total Expenses", curr + report.get("totalExpense"), dangerColor, whiteBoldFont);
            addMetricCell(summaryTable, "Net Savings", curr + report.get("totalSavings"), primaryColor, whiteBoldFont);
            addMetricCell(summaryTable, "Remaining Budget", curr + report.get("remainingBudget"), new Color(14, 165, 233), whiteBoldFont);
            document.add(summaryTable);

            // Category Breakdown Table
            Paragraph catTitle = new Paragraph("Category-Wise Spending Breakdown", sectionFont);
            catTitle.setSpacingAfter(8);
            document.add(catTitle);

            PdfPTable catTable = new PdfPTable(3);
            catTable.setWidthPercentage(100);
            catTable.setWidths(new float[]{4, 3, 3});
            catTable.setSpacingAfter(15);

            addTableHeader(catTable, "Category Name", primaryColor, whiteBoldFont);
            addTableHeader(catTable, "Amount Spent", primaryColor, whiteBoldFont);
            addTableHeader(catTable, "% of Total Spending", primaryColor, whiteBoldFont);

            @SuppressWarnings("unchecked")
            List<AnalysisDto.CategoryShare> categories = (List<AnalysisDto.CategoryShare>) report.get("categories");
            if (categories.isEmpty()) {
                PdfPCell emptyCell = new PdfPCell(new Phrase("No expense records recorded for this month.", regularFont));
                emptyCell.setColspan(3);
                emptyCell.setPadding(8);
                catTable.addCell(emptyCell);
            } else {
                for (AnalysisDto.CategoryShare cs : categories) {
                    catTable.addCell(createCell(cs.getName(), regularFont));
                    catTable.addCell(createCell(curr + cs.getAmount().toString(), regularFont));
                    catTable.addCell(createCell(cs.getPercentage() + "%", regularFont));
                }
            }
            document.add(catTable);

            // Detailed Recent Transactions Table
            Paragraph txTitle = new Paragraph("Transactions Recorded", sectionFont);
            txTitle.setSpacingAfter(8);
            document.add(txTitle);

            PdfPTable txTable = new PdfPTable(5);
            txTable.setWidthPercentage(100);
            txTable.setWidths(new float[]{2, 4, 2, 2, 2});
            txTable.setSpacingAfter(15);

            addTableHeader(txTable, "Date", darkColor, whiteBoldFont);
            addTableHeader(txTable, "Description", darkColor, whiteBoldFont);
            addTableHeader(txTable, "Category", darkColor, whiteBoldFont);
            addTableHeader(txTable, "Method", darkColor, whiteBoldFont);
            addTableHeader(txTable, "Amount", darkColor, whiteBoldFont);

            @SuppressWarnings("unchecked")
            List<TransactionDto> txList = (List<TransactionDto>) report.get("transactions");
            if (txList.isEmpty()) {
                PdfPCell emptyTx = new PdfPCell(new Phrase("No transactions logged for this period.", regularFont));
                emptyTx.setColspan(5);
                emptyTx.setPadding(8);
                txTable.addCell(emptyTx);
            } else {
                for (TransactionDto tx : txList) {
                    txTable.addCell(createCell(tx.getTransactionDate().toString(), regularFont));
                    txTable.addCell(createCell(tx.getDescription(), regularFont));
                    txTable.addCell(createCell(tx.getCategoryName() != null ? tx.getCategoryName() : "Other", regularFont));
                    txTable.addCell(createCell(tx.getPaymentMethod(), regularFont));

                    String sign = "EXPENSE".equalsIgnoreCase(tx.getType()) ? "-" : "+";
                    Phrase amtPhrase = new Phrase(sign + curr + tx.getAmount(),
                            "EXPENSE".equalsIgnoreCase(tx.getType()) ?
                                    FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, dangerColor) :
                                    FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, accentColor));
                    PdfPCell amtCell = new PdfPCell(amtPhrase);
                    amtCell.setPadding(5);
                    txTable.addCell(amtCell);
                }
            }
            document.add(txTable);

            // Footer note
            Paragraph footer = new Paragraph("This report was automatically generated by Smart Expense Tracker & Personal Finance Management System.", subtitleFont);
            footer.setAlignment(Element.ALIGN_CENTER);
            document.add(footer);

            document.close();
            return out.toByteArray();

        } catch (Exception e) {
            throw new RuntimeException("Error generating PDF report: " + e.getMessage(), e);
        }
    }

    private void addMetricCell(PdfPTable table, String label, String value, Color bgColor, Font font) {
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(bgColor);
        cell.setPadding(8);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.addElement(new Paragraph(label, FontFactory.getFont(FontFactory.HELVETICA, 8, Color.WHITE)));
        cell.addElement(new Paragraph(value, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, Color.WHITE)));
        table.addCell(cell);
    }

    private void addTableHeader(PdfPTable table, String text, Color bgColor, Font font) {
        PdfPCell header = new PdfPCell(new Phrase(text, font));
        header.setBackgroundColor(bgColor);
        header.setPadding(6);
        table.addCell(header);
    }

    private PdfPCell createCell(String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setPadding(5);
        return cell;
    }
}
