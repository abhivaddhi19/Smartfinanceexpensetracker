package com.expensetracker.dto;

import java.math.BigDecimal;

public class BudgetDto {
    private Long id;
    private Integer month;
    private Integer year;
    private BigDecimal amount = BigDecimal.ZERO;
    private BigDecimal spent = BigDecimal.ZERO;
    private BigDecimal remaining = BigDecimal.ZERO;
    private double usagePercentage = 0.0;
    private String status; // HEALTHY, WARNING_70, WARNING_85, EXCEEDED
    private String alertMessage;

    public BudgetDto() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Integer getMonth() { return month; }
    public void setMonth(Integer month) { this.month = month; }

    public Integer getYear() { return year; }
    public void setYear(Integer year) { this.year = year; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public BigDecimal getSpent() { return spent; }
    public void setSpent(BigDecimal spent) { this.spent = spent; }

    public BigDecimal getRemaining() { return remaining; }
    public void setRemaining(BigDecimal remaining) { this.remaining = remaining; }

    public double getUsagePercentage() { return usagePercentage; }
    public void setUsagePercentage(double usagePercentage) { this.usagePercentage = usagePercentage; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getAlertMessage() { return alertMessage; }
    public void setAlertMessage(String alertMessage) { this.alertMessage = alertMessage; }
}
