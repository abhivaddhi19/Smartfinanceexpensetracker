package com.expensetracker.controller;

import com.expensetracker.dto.AnalysisDto;
import com.expensetracker.model.User;
import com.expensetracker.security.SecurityUtil;
import com.expensetracker.service.AnalysisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/analysis")
public class AnalysisController {

    @Autowired
    private AnalysisService analysisService;

    @Autowired
    private SecurityUtil securityUtil;

    @GetMapping("/daily")
    public ResponseEntity<AnalysisDto.DailyAnalysis> getDailyAnalysis(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {

        User user = securityUtil.getRequiredCurrentUser();
        return ResponseEntity.ok(analysisService.getDailyAnalysis(user, date != null ? date : LocalDate.now()));
    }

    @GetMapping("/weekly")
    public ResponseEntity<AnalysisDto.WeeklyAnalysis> getWeeklyAnalysis(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {

        User user = securityUtil.getRequiredCurrentUser();
        return ResponseEntity.ok(analysisService.getWeeklyAnalysis(user, date != null ? date : LocalDate.now()));
    }

    @GetMapping("/monthly")
    public ResponseEntity<AnalysisDto.MonthlyAnalysis> getMonthlyAnalysis(
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year) {

        User user = securityUtil.getRequiredCurrentUser();
        LocalDate now = LocalDate.now();
        int m = month != null ? month : now.getMonthValue();
        int y = year != null ? year : now.getYear();

        return ResponseEntity.ok(analysisService.getMonthlyAnalysis(user, m, y));
    }

    @GetMapping("/categories")
    public ResponseEntity<List<AnalysisDto.CategoryShare>> getCategoryExpenses(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        User user = securityUtil.getRequiredCurrentUser();
        return ResponseEntity.ok(analysisService.getCategoryExpenses(user, startDate, endDate));
    }
}
