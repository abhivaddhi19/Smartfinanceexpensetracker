$s = New-Object Microsoft.PowerShell.Commands.WebRequestSession
Invoke-RestMethod -Uri "http://localhost:8080/api/auth/login" -Method Post -ContentType "application/json" -Body '{"email":"demo@expensetracker.com","password":"Password123"}' -WebSession $s | Out-Null
$txs = Invoke-RestMethod -Uri "http://localhost:8080/api/transactions" -WebSession $s
Write-Host "Count: $($txs.Count)"
Write-Host ($txs[0] | ConvertTo-Json)
