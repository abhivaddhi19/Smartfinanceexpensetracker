package com.expensetracker.dto;

public class SmartSuggestionDto {
    private String category; // FOOD, SHOPPING, SAVINGS, SUBSCRIPTIONS, BUDGET
    private String title;
    private String description;
    private String impact; // HIGH, MEDIUM, LOW
    private String icon;
    private String actionUrl;

    public SmartSuggestionDto() {}

    public SmartSuggestionDto(String category, String title, String description, String impact, String icon, String actionUrl) {
        this.category = category;
        this.title = title;
        this.description = description;
        this.impact = impact;
        this.icon = icon;
        this.actionUrl = actionUrl;
    }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getImpact() { return impact; }
    public void setImpact(String impact) { this.impact = impact; }

    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }

    public String getActionUrl() { return actionUrl; }
    public void setActionUrl(String actionUrl) { this.actionUrl = actionUrl; }
}
