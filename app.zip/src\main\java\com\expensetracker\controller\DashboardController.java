package com.expensetracker.controller;

import com.expensetracker.dto.DashboardSummaryDto;
import com.expensetracker.dto.TransactionDto;
import com.expensetracker.model.User;
import com.expensetracker.security.SecurityUtil;
import com.expensetracker.service.DashboardService;
import com.expensetracker.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private SecurityUtil securityUtil;

    @GetMapping("/summary")
    public ResponseEntity<DashboardSummaryDto> getSummary(
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year) {

        User user = securityUtil.getRequiredCurrentUser();
        LocalDate now = LocalDate.now();
        int m = month != null ? month : now.getMonthValue();
        int y = year != null ? year : now.getYear();

        DashboardSummaryDto summary = dashboardService.getSummary(user, m, y);
        return ResponseEntity.ok(summary);
    }

    @GetMapping("/recent-transactions")
    public ResponseEntity<List<TransactionDto>> getRecentTransactions(
            @RequestParam(defaultValue = "5") int limit) {

        User user = securityUtil.getRequiredCurrentUser();
        List<TransactionDto> recent = transactionService.getRecentTransactions(user.getId(), limit);
        return ResponseEntity.ok(recent);
    }
}
