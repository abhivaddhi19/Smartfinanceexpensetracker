package com.expensetracker.controller;

import com.expensetracker.model.User;
import com.expensetracker.repository.UserRepository;
import com.expensetracker.security.SecurityUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private SecurityUtil securityUtil;

    @GetMapping
    public ResponseEntity<Map<String, Object>> getProfile() {
        User user = securityUtil.getRequiredCurrentUser();
        Map<String, Object> map = new HashMap<>();
        map.put("id", user.getId());
        map.put("name", user.getName());
        map.put("email", user.getEmail());
        map.put("mobile", user.getMobile());
        map.put("currency", user.getCurrency());
        map.put("createdAt", user.getCreatedAt());
        return ResponseEntity.ok(map);
    }

    @PutMapping
    public ResponseEntity<Map<String, Object>> updateProfile(@RequestBody Map<String, String> payload) {
        User user = securityUtil.getRequiredCurrentUser();

        if (payload.containsKey("name") && payload.get("name") != null && !payload.get("name").trim().isEmpty()) {
            user.setName(payload.get("name").trim());
        }
        if (payload.containsKey("mobile")) {
            user.setMobile(payload.get("mobile"));
        }
        if (payload.containsKey("currency") && payload.get("currency") != null && !payload.get("currency").trim().isEmpty()) {
            user.setCurrency(payload.get("currency").trim());
        }

        User updated = userRepository.save(Objects.requireNonNull(user));
        Map<String, Object> map = new HashMap<>();
        map.put("success", true);
        map.put("message", "Profile updated successfully!");
        map.put("name", updated.getName());
        map.put("currency", updated.getCurrency());
        return ResponseEntity.ok(map);
    }

    @PutMapping("/password")
    public ResponseEntity<Map<String, Object>> changePassword(@RequestBody Map<String, String> payload) {
        User user = securityUtil.getRequiredCurrentUser();
        String currentPass = payload.get("currentPassword");
        String newPass = payload.get("newPassword");
        String confirmPass = payload.get("confirmPassword");

        if (currentPass == null || !passwordEncoder.matches(currentPass, user.getPassword())) {
            Map<String, Object> err = new HashMap<>();
            err.put("success", false);
            err.put("message", "Incorrect current password.");
            return ResponseEntity.badRequest().body(err);
        }

        if (newPass == null || newPass.length() < 6) {
            Map<String, Object> err = new HashMap<>();
            err.put("success", false);
            err.put("message", "New password must be at least 6 characters.");
            return ResponseEntity.badRequest().body(err);
        }

        if (!newPass.equals(confirmPass)) {
            Map<String, Object> err = new HashMap<>();
            err.put("success", false);
            err.put("message", "New password and confirmation do not match.");
            return ResponseEntity.badRequest().body(err);
        }

        user.setPassword(passwordEncoder.encode(newPass));
        userRepository.save(Objects.requireNonNull(user));

        Map<String, Object> map = new HashMap<>();
        map.put("success", true);
        map.put("message", "Password changed successfully!");
        return ResponseEntity.ok(map);
    }
}
