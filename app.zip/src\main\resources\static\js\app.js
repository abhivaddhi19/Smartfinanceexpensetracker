/**
 * Smart Expense Tracker & Personal Finance Management System
 * Main Application Logic & View Controller
 */

// Application State
const AppState = {
    user: null,
    currency: '₹',
    categories: [],
    currentMonth: new Date().getMonth() + 1,
    currentYear: new Date().getFullYear(),
    charts: {},
    activeView: 'dashboard'
};

// ==========================================================================
// Initialization & Authentication Lifecycle
// ==========================================================================

// Theme management
const savedAppTheme = localStorage.getItem('app-theme') || 'sunset';
document.documentElement.setAttribute('data-theme', savedAppTheme);

function initTheme() {
    const saved = localStorage.getItem('app-theme') || 'sunset';
    setAppTheme(saved, false);
}

function setAppTheme(themeName, showNotification = true) {
    document.documentElement.setAttribute('data-theme', themeName);
    document.body.setAttribute('data-theme', themeName);
    localStorage.setItem('app-theme', themeName);

    const labels = {
        'emerald': 'Emerald Green',
        'sapphire': 'Sapphire Blue',
        'violet': 'Royal Violet',
        'sunset': 'Sunset Amber',
        'dark': 'Midnight Dark'
    };

    const labelEl = document.getElementById('current-theme-label');
    if (labelEl) {
        labelEl.textContent = labels[themeName] || 'Colors';
    }

    if (showNotification) {
        showToast(`Theme changed to ${labels[themeName] || themeName}!`, 'info');
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    initTheme();
    initDateBadges();
    setupRouting();
    setupEventListeners();
    await checkAuth();
});

function initDateBadges() {
    const today = new Date();
    const options = { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' };
    const dateStr = today.toLocaleDateString('en-US', options);
    document.querySelectorAll('.current-date-display').forEach(el => el.textContent = dateStr);

    // Populate month selectors
    const monthSelects = document.querySelectorAll('.month-selector');
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    monthSelects.forEach(select => {
        select.innerHTML = months.map((m, idx) =>
            `<option value="${idx + 1}" ${idx + 1 === AppState.currentMonth ? 'selected' : ''}>${m}</option>`
        ).join('');
    });

    // Populate budget year selector
    const budgetYearSel = document.getElementById('budget-year-selector');
    if (budgetYearSel) {
        const curYear = AppState.currentYear;
        budgetYearSel.innerHTML = '';
        for (let y = curYear - 2; y <= curYear + 1; y++) {
            const opt = document.createElement('option');
            opt.value = y;
            opt.textContent = y;
            if (y === curYear) opt.selected = true;
            budgetYearSel.appendChild(opt);
        }
    }
}

async function checkAuth() {
    try {
        const res = await API.auth.getCurrentUser();
        if (res && res.success) {
            AppState.user = res;
            AppState.currency = res.currency || '₹';
            updateUserUI();
            await loadCategories();
            handleRoute();
            startAlertPolling();
        } else {
            showAuthView('login');
        }
    } catch (err) {
        showAuthView('login');
    }
}

function updateUserUI() {
    if (!AppState.user) return;
    document.querySelectorAll('.user-name-display').forEach(el => el.textContent = AppState.user.name);
    document.querySelectorAll('.user-email-display').forEach(el => el.textContent = AppState.user.email);
    document.querySelectorAll('.user-currency-symbol').forEach(el => el.textContent = AppState.currency);
    document.getElementById('app-wrapper').style.display = 'flex';
    document.getElementById('auth-container').style.display = 'none';
}

function showAuthView(type = 'login') {
    document.getElementById('app-wrapper').style.display = 'none';
    document.getElementById('auth-container').style.display = 'flex';
    if (type === 'login') {
        document.getElementById('login-card').style.display = 'block';
        document.getElementById('register-card').style.display = 'none';
    } else {
        document.getElementById('login-card').style.display = 'none';
        document.getElementById('register-card').style.display = 'block';
    }
}

// ==========================================================================
// Routing & View Switcher
// ==========================================================================

function setupRouting() {
    window.addEventListener('hashchange', handleRoute);
}

function handleRoute() {
    if (!AppState.user) {
        const hash = window.location.hash;
        if (hash === '#register') {
            showAuthView('register');
        } else {
            showAuthView('login');
        }
        return;
    }

    const hash = window.location.hash.replace('#', '') || 'dashboard';
    AppState.activeView = hash;

    // Update navigation sidebar active state
    document.querySelectorAll('.sidebar-link').forEach(link => {
        if (link.getAttribute('href') === `#${hash}`) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });

    // Hide all view sections
    document.querySelectorAll('.view-section').forEach(section => {
        section.style.display = 'none';
    });

    // Show target section
    const targetSection = document.getElementById(`view-${hash}`);
    if (targetSection) {
        targetSection.style.display = 'block';
    } else {
        document.getElementById('view-dashboard').style.display = 'block';
    }

    // Set Topbar Title
    const titleMap = {
        'dashboard': 'Financial Dashboard',
        'transactions': 'Transaction Records',
        'add-transaction': 'Record Transaction',
        'categories': 'Expense Categories',
        'analysis': 'Expense Analysis & Insights',
        'charts': 'Charts & Analytics',
        'budget': 'Monthly Budget Management',
        'alerts': 'Smart Financial Alerts',
        'suggestions': 'AI Financial Suggestions',
        'bank': 'Bank Statement Import',
        'monthly-report': 'Monthly Financial Report',
        'category-report': 'Category Spending Report',
        'scanner': 'Receipt Scanner - Add Transaction',
        'profile': 'Account Profile',
        'settings': 'System Settings'
    };
    document.getElementById('topbar-page-title').textContent = titleMap[hash] || 'Personal Finance';

    // Close mobile sidebar if open
    document.getElementById('sidebar').classList.remove('show');

    // Trigger View Loaders
    loadViewData(hash);
}

function loadViewData(view) {
    switch (view) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'transactions':
            loadTransactionsTable();
            break;
        case 'categories':
            loadCategoriesView();
            break;
        case 'analysis':
            loadAnalysisView();
            break;
        case 'charts':
            loadChartsView();
            break;
        case 'budget':
            loadBudgetView();
            break;
        case 'alerts':
            loadAlertsView();
            break;
        case 'suggestions':
            loadSuggestionsView();
            break;
        case 'bank':
            loadBankPendingTransactions();
            break;
        case 'monthly-report':
            loadMonthlyReport();
            break;
        case 'category-report':
            loadCategoryReport();
            break;
        case 'scanner':
            resetScannerView();
            break;
        case 'profile':
            loadProfileView();
            break;
    }
}

// ==========================================================================
// Dashboard View
// ==========================================================================

async function loadDashboard() {
    try {
        const [summary, recentTx] = await Promise.all([
            API.dashboard.getSummary(AppState.currentMonth, AppState.currentYear),
            API.dashboard.getRecentTransactions(6)
        ]);

        // 1. Update Financial Summary Cards
        const c = AppState.currency;
        document.getElementById('dash-income').textContent = `${c}${formatNumber(summary.totalIncome)}`;
        document.getElementById('dash-expense').textContent = `${c}${formatNumber(summary.totalExpenses)}`;
        document.getElementById('dash-balance').textContent = `${c}${formatNumber(summary.currentBalance)}`;
        document.getElementById('dash-monthly-spend').textContent = `${c}${formatNumber(summary.monthlyExpenses)}`;
        document.getElementById('dash-savings').textContent = `${c}${formatNumber(summary.monthlySavings)}`;
        document.getElementById('dash-budget').textContent = `${c}${formatNumber(summary.monthlyBudget)}`;
        document.getElementById('dash-remaining').textContent = `${c}${formatNumber(summary.remainingBudget)}`;

        // Budget usage progress
        const budgetUsageBar = document.getElementById('dash-budget-progress-bar');
        const budgetUsageText = document.getElementById('dash-budget-usage-pct');
        const pct = summary.budgetUsagePercentage || 0;
        budgetUsageBar.style.width = `${Math.min(pct, 100)}%`;
        budgetUsageText.textContent = `${pct}%`;

        if (pct > 100) {
            budgetUsageBar.className = 'progress-bar-budget bg-danger';
        } else if (pct >= 85) {
            budgetUsageBar.className = 'progress-bar-budget bg-danger';
        } else if (pct >= 70) {
            budgetUsageBar.className = 'progress-bar-budget bg-warning';
        } else {
            budgetUsageBar.className = 'progress-bar-budget bg-success';
        }

        // 2. Render Recent Transactions Table
        renderRecentTransactions(recentTx);

        // 3. Render Dashboard Charts
        renderDashboardCharts();

    } catch (err) {
        showToast('Error loading dashboard: ' + err.message, 'error');
    }
}

function renderRecentTransactions(list) {
    const tbody = document.getElementById('dash-recent-tx-body');
    if (!list || list.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="text-center py-4 text-muted">No transactions recorded yet. Click "Add Expense" to get started!</td></tr>`;
        return;
    }

    tbody.innerHTML = list.map(tx => {
        const isExpense = tx.type === 'EXPENSE';
        const sign = isExpense ? '-' : '+';
        const amtClass = isExpense ? 'badge-expense' : 'badge-income';
        const icon = tx.categoryIcon || 'fa-tags';

        return `
            <tr>
                <td>${formatDate(tx.transactionDate)}</td>
                <td>
                    <div class="fw-semibold text-dark">${escapeHtml(tx.description)}</div>
                    ${tx.merchantName ? `<small class="text-muted"><i class="fa-solid fa-store me-1"></i>${escapeHtml(tx.merchantName)}</small>` : ''}
                </td>
                <td>
                    <span class="badge-category">
                        <i class="fa-solid ${icon} text-primary"></i>
                        ${escapeHtml(tx.categoryName || 'Other')}
                    </span>
                </td>
                <td><span class="badge ${isExpense ? 'bg-danger-subtle text-danger' : 'bg-success-subtle text-success'}">${tx.type}</span></td>
                <td class="${amtClass}">${sign}${AppState.currency}${formatNumber(tx.amount)}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="openEditTransactionModal(${tx.id})" title="Edit"><i class="fa-solid fa-pen-to-square"></i></button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteTransactionPrompt(${tx.id})" title="Delete"><i class="fa-solid fa-trash"></i></button>
                </td>
            </tr>
        `;
    }).join('');
}

async function renderDashboardCharts() {
    try {
        const [monthlyData, catData] = await Promise.all([
            API.analysis.getMonthly(AppState.currentMonth, AppState.currentYear),
            API.analysis.getCategories()
        ]);

        // Monthly Trend Line Chart
        destroyChart('dashTrendChart');
        const ctxTrend = document.getElementById('dashTrendChart');
        if (ctxTrend && monthlyData && monthlyData.dailyTrend) {
            AppState.charts.dashTrendChart = new Chart(ctxTrend, {
                type: 'line',
                data: {
                    labels: monthlyData.dailyTrend.map(d => `Day ${d.day}`),
                    datasets: [{
                        label: 'Daily Expenses',
                        data: monthlyData.dailyTrend.map(d => d.amount),
                        borderColor: '#4f46e5',
                        backgroundColor: 'rgba(79, 70, 229, 0.08)',
                        tension: 0.35,
                        fill: true,
                        pointBackgroundColor: '#4f46e5',
                        pointRadius: 3
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        y: { beginAtZero: true, grid: { color: '#f1f5f9' } },
                        x: { grid: { display: false } }
                    }
                }
            });
        }

        // Category Doughnut Chart
        destroyChart('dashCategoryChart');
        const ctxCat = document.getElementById('dashCategoryChart');
        if (ctxCat && catData && catData.length > 0) {
            const colors = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#0ea5e9', '#ec4899', '#14b8a6', '#f97316', '#64748b'];
            AppState.charts.dashCategoryChart = new Chart(ctxCat, {
                type: 'doughnut',
                data: {
                    labels: catData.map(c => c.name),
                    datasets: [{
                        data: catData.map(c => c.amount),
                        backgroundColor: colors.slice(0, catData.length),
                        borderWidth: 2,
                        borderColor: '#ffffff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'bottom', labels: { boxWidth: 12, padding: 12, font: { size: 11 } } }
                    },
                    cutout: '70%'
                }
            });
        }
    } catch (err) {
        console.error('Error rendering dashboard charts:', err);
    }
}

// ==========================================================================
// Transactions Management Module
// ==========================================================================

async function loadTransactionsTable() {
    const type = document.getElementById('filter-tx-type').value;
    const categoryId = document.getElementById('filter-tx-category').value;
    const startDate = document.getElementById('filter-tx-start-date').value;
    const endDate = document.getElementById('filter-tx-end-date').value;
    const paymentMethod = document.getElementById('filter-tx-method').value;
    const minAmount = document.getElementById('filter-tx-min').value;
    const maxAmount = document.getElementById('filter-tx-max').value;
    const keyword = document.getElementById('filter-tx-search').value;

    try {
        const transactions = await API.transactions.list({
            type, categoryId, startDate, endDate, paymentMethod, minAmount, maxAmount, keyword
        });

        const tbody = document.getElementById('transactions-table-body');
        const countBadge = document.getElementById('tx-total-count-badge');
        countBadge.textContent = `${transactions.length} record(s)`;

        if (!transactions || transactions.length === 0) {
            tbody.innerHTML = `<tr><td colspan="8" class="text-center py-5 text-muted"><i class="fa-regular fa-folder-open fs-2 mb-2 d-block"></i>No transactions found for the selected filters.</td></tr>`;
            return;
        }

        tbody.innerHTML = transactions.map(tx => {
            const isExpense = tx.type === 'EXPENSE';
            const sign = isExpense ? '-' : '+';
            const amtClass = isExpense ? 'badge-expense' : 'badge-income';
            const icon = tx.categoryIcon || 'fa-tags';

            return `
                <tr>
                    <td>${formatDate(tx.transactionDate)}</td>
                    <td>
                        <div class="fw-bold text-dark">${escapeHtml(tx.description)}</div>
                        ${tx.notes ? `<small class="text-muted d-block">${escapeHtml(tx.notes)}</small>` : ''}
                    </td>
                    <td>
                        <span class="badge-category">
                            <i class="fa-solid ${icon} text-primary"></i>
                            ${escapeHtml(tx.categoryName || 'Other')}
                        </span>
                    </td>
                    <td><span class="badge ${isExpense ? 'bg-danger-subtle text-danger' : 'bg-success-subtle text-success'}">${tx.type}</span></td>
                    <td class="${amtClass}">${sign}${AppState.currency}${formatNumber(tx.amount)}</td>
                    <td><span class="badge bg-light text-secondary border">${tx.paymentMethod}</span></td>
                    <td>${tx.merchantName ? `<span class="badge bg-light text-dark border">${escapeHtml(tx.merchantName)}</span>` : '<span class="text-muted">-</span>'}</td>
                    <td>
                        <div class="btn-group btn-group-sm">
                            ${tx.receiptPath ? `<button class="btn btn-outline-info" onclick="viewReceiptImage('${tx.receiptPath}')" title="Receipt"><i class="fa-solid fa-receipt"></i></button>` : ''}
                            <button class="btn btn-outline-primary" onclick="openEditTransactionModal(${tx.id})" title="Edit"><i class="fa-solid fa-pen-to-square"></i></button>
                            <button class="btn btn-outline-danger" onclick="deleteTransactionPrompt(${tx.id})" title="Delete"><i class="fa-solid fa-trash"></i></button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');

    } catch (err) {
        showToast('Error loading transactions: ' + err.message, 'error');
    }
}

function openAddTransactionModal(defaultType = 'EXPENSE') {
    document.getElementById('txModalTitle').textContent = 'Record Transaction';
    document.getElementById('tx-form-id').value = '';
    document.getElementById('tx-form-amount').value = '';
    document.getElementById('tx-form-desc').value = '';
    document.getElementById('tx-form-merchant').value = '';
    document.getElementById('tx-form-notes').value = '';
    document.getElementById('tx-form-date').value = new Date().toISOString().split('T')[0];
    document.getElementById('tx-form-method').value = 'UPI';

    setTransactionModalType(defaultType);
    populateCategoryDropdown('tx-form-category');

    const modal = new bootstrap.Modal(document.getElementById('transactionModal'));
    modal.show();
}

async function openEditTransactionModal(id) {
    try {
        const tx = await API.transactions.get(id);
        document.getElementById('txModalTitle').textContent = 'Edit Transaction';
        document.getElementById('tx-form-id').value = tx.id;
        document.getElementById('tx-form-amount').value = tx.amount;
        document.getElementById('tx-form-desc').value = tx.description;
        document.getElementById('tx-form-merchant').value = tx.merchantName || '';
        document.getElementById('tx-form-notes').value = tx.notes || '';
        document.getElementById('tx-form-date').value = tx.transactionDate;
        document.getElementById('tx-form-method').value = tx.paymentMethod;

        setTransactionModalType(tx.type);
        populateCategoryDropdown('tx-form-category', tx.categoryId);

        const modal = new bootstrap.Modal(document.getElementById('transactionModal'));
        modal.show();
    } catch (err) {
        showToast('Failed to load transaction: ' + err.message, 'error');
    }
}

function setTransactionModalType(type) {
    document.getElementById('tx-form-type').value = type;
    const btnExpense = document.getElementById('btn-type-expense');
    const btnIncome = document.getElementById('btn-type-income');

    if (type === 'EXPENSE') {
        btnExpense.className = 'btn btn-danger flex-fill';
        btnIncome.className = 'btn btn-outline-success flex-fill';
    } else {
        btnIncome.className = 'btn btn-success flex-fill';
        btnExpense.className = 'btn btn-outline-danger flex-fill';
    }
}

async function saveTransactionForm() {
    const id = document.getElementById('tx-form-id').value;
    const type = document.getElementById('tx-form-type').value;
    const amount = document.getElementById('tx-form-amount').value;
    const categoryId = document.getElementById('tx-form-category').value;
    const description = document.getElementById('tx-form-desc').value;
    const transactionDate = document.getElementById('tx-form-date').value;
    const paymentMethod = document.getElementById('tx-form-method').value;
    const merchantName = document.getElementById('tx-form-merchant').value;
    const notes = document.getElementById('tx-form-notes').value;

    if (!amount || parseFloat(amount) <= 0) {
        showToast('Please enter a valid amount greater than 0', 'warning');
        return;
    }
    if (!description.trim()) {
        showToast('Please enter a transaction description', 'warning');
        return;
    }
    if (!transactionDate) {
        showToast('Please select a valid date', 'warning');
        return;
    }

    const payload = {
        type,
        amount: parseFloat(amount),
        categoryId: categoryId ? parseInt(categoryId) : null,
        description: description.trim(),
        transactionDate,
        paymentMethod,
        merchantName: merchantName ? merchantName.trim() : null,
        notes: notes ? notes.trim() : null
    };

    try {
        if (id) {
            await API.transactions.update(id, payload);
            showToast('Transaction updated successfully!', 'success');
        } else {
            await API.transactions.create(payload);
            showToast('Transaction recorded successfully!', 'success');
        }

        bootstrap.Modal.getInstance(document.getElementById('transactionModal')).hide();

        if (AppState.activeView === 'dashboard') {
            loadDashboard();
        } else if (AppState.activeView === 'transactions') {
            loadTransactionsTable();
        } else {
            loadViewData(AppState.activeView);
        }

        startAlertPolling(); // refresh alerts after transaction check
    } catch (err) {
        showToast('Error saving transaction: ' + err.message, 'error');
    }
}

async function deleteTransactionPrompt(id) {
    if (!confirm('Are you sure you want to delete this transaction record?')) return;
    try {
        await API.transactions.delete(id);
        showToast('Transaction deleted successfully', 'success');
        if (AppState.activeView === 'dashboard') loadDashboard();
        else if (AppState.activeView === 'transactions') loadTransactionsTable();
    } catch (err) {
        showToast('Error deleting transaction: ' + err.message, 'error');
    }
}

// ==========================================================================
// Category Management Module
// ==========================================================================

let activeCategoryFilter = 'all';

async function loadCategories() {
    try {
        AppState.categories = await API.categories.list();
        syncAllCategoryDropdowns();
    } catch (err) {
        console.error('Error fetching categories:', err);
    }
}

function syncAllCategoryDropdowns() {
    populateCategoryDropdown('filter-tx-category', null, true);
    populateCategoryDropdown('tx-form-category');
    populateCategoryDropdown('ocr-category');
    populateCategoryDropdown('category-report-selector');
}

function populateCategoryDropdown(elementId, selectedId = null, includeAll = false) {
    const el = document.getElementById(elementId);
    if (!el) return;

    let html = includeAll ? `<option value="">All Categories</option>` : `<option value="">Select Category</option>`;
    html += AppState.categories.map(c => `
        <option value="${c.id}" ${selectedId && c.id === selectedId ? 'selected' : ''}>
            ${escapeHtml(c.name)} ${c.isCustom ? '(Custom)' : ''}
        </option>
    `).join('');
    el.innerHTML = html;
}

function setCategoryFilter(filter, btn) {
    activeCategoryFilter = filter;
    document.querySelectorAll('.cat-filter-btn').forEach(b => {
        b.classList.remove('active', 'btn-primary', 'btn-secondary', 'btn-success');
        b.classList.add('btn-outline-secondary');
    });
    if (btn) {
        btn.classList.add('active');
        if (filter === 'all') btn.classList.add('btn-primary');
        else if (filter === 'system') btn.classList.add('btn-secondary');
        else if (filter === 'custom') btn.classList.add('btn-success');
        btn.classList.remove('btn-outline-secondary');
    }
    filterCategoriesGrid();
}

function filterCategoriesGrid() {
    const searchTerm = (document.getElementById('cat-search-input')?.value || '').toLowerCase().trim();
    const container = document.getElementById('categories-grid');
    if (!container) return;

    const filtered = AppState.categories.filter(c => {
        const matchesSearch = c.name.toLowerCase().includes(searchTerm) || 
                              (c.description && c.description.toLowerCase().includes(searchTerm));
        if (!matchesSearch) return false;

        if (activeCategoryFilter === 'system') return !c.isCustom;
        if (activeCategoryFilter === 'custom') return c.isCustom;
        return true;
    });

    if (filtered.length === 0) {
        container.innerHTML = `
            <div class="col-12 text-center py-5">
                <div class="text-muted mb-2"><i class="fa-solid fa-tags fa-2x"></i></div>
                <h6 class="text-muted">No categories match your search or filter</h6>
                <button class="btn btn-sm btn-outline-primary mt-2" onclick="document.getElementById('cat-search-input').value=''; setCategoryFilter('all');">Clear Filters</button>
            </div>
        `;
        return;
    }

    container.innerHTML = filtered.map(c => {
        const isCustom = c.isCustom;
        const totalSpent = c.totalSpent || 0;
        const txCount = c.transactionCount || 0;
        const icon = c.icon || 'fa-tags';

        return `
            <div class="col-md-4 col-lg-3">
                <div class="summary-card h-100 d-flex flex-column text-center p-3 category-card position-relative ${isCustom ? 'border-primary-subtle' : ''}">
                    <div class="position-absolute top-0 end-0 p-2">
                        ${isCustom ? 
                            `<span class="badge bg-primary-subtle text-primary border border-primary-subtle" style="font-size: 0.65rem;">Custom</span>` : 
                            `<span class="badge bg-light text-muted border" style="font-size: 0.65rem;">System</span>`}
                    </div>
                    <div class="card-icon-wrap mx-auto mb-2 mt-2" style="background: var(--primary-soft); color: var(--primary); font-size: 1.4rem; width: 50px; height: 50px; display: inline-flex; align-items: center; justify-content: center; border-radius: 12px;">
                        <i class="fa-solid ${icon}"></i>
                    </div>
                    <h6 class="fw-bold mb-1 text-truncate" title="${escapeHtml(c.name)}">${escapeHtml(c.name)}</h6>
                    <small class="text-muted d-block mb-3 text-truncate-2" style="font-size: 0.78rem; min-height: 2.2em;">
                        ${escapeHtml(c.description || 'General expense category')}
                    </small>

                    <!-- Spending stats badge -->
                    <div class="p-2 rounded bg-light border mb-3 mt-auto small">
                        <div class="d-flex justify-content-between text-muted" style="font-size: 0.75rem;">
                            <span>Total Spent:</span>
                            <span class="fw-bold text-danger">${AppState.currency}${formatNumber(totalSpent)}</span>
                        </div>
                        <div class="d-flex justify-content-between text-muted" style="font-size: 0.75rem;">
                            <span>Transactions:</span>
                            <span class="fw-semibold text-dark">${txCount}</span>
                        </div>
                    </div>

                    <div class="d-flex gap-1 justify-content-center flex-wrap">
                        <button class="btn btn-xs btn-outline-primary" onclick="viewCategoryReport(${c.id})" title="View Spending Report">
                            <i class="fa-solid fa-chart-column me-1"></i>Report
                        </button>
                        ${isCustom ? `
                            <button class="btn btn-xs btn-outline-secondary" onclick="openEditCategoryModal(${c.id})" title="Edit category">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </button>
                            <button class="btn btn-xs btn-outline-danger" onclick="deleteCategoryPrompt(${c.id})" title="Delete category">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

async function loadCategoriesView() {
    await loadCategories();
    
    // Update count badges
    const totalCount = AppState.categories.length;
    const systemCount = AppState.categories.filter(c => !c.isCustom).length;
    const customCount = AppState.categories.filter(c => c.isCustom).length;

    const elAll = document.getElementById('cat-count-all');
    const elSys = document.getElementById('cat-count-system');
    const elCust = document.getElementById('cat-count-custom');
    if (elAll) elAll.textContent = totalCount;
    if (elSys) elSys.textContent = systemCount;
    if (elCust) elCust.textContent = customCount;

    filterCategoriesGrid();
}

function updateCatIconPreview(iconClass) {
    const preview = document.getElementById('cat-icon-preview');
    if (preview) {
        preview.innerHTML = `<i class="fa-solid ${iconClass || 'fa-tag'} text-primary"></i>`;
    }
}

function openAddCategoryModal() {
    document.getElementById('catModalTitle').textContent = 'Create Custom Category';
    document.getElementById('cat-form-id').value = '';
    document.getElementById('cat-form-name').value = '';
    document.getElementById('cat-form-icon').value = 'fa-tag';
    updateCatIconPreview('fa-tag');
    document.getElementById('cat-form-desc').value = '';
    bootstrap.Modal.getOrCreateInstance(document.getElementById('categoryModal')).show();
}

function openEditCategoryModal(id) {
    const cat = AppState.categories.find(c => c.id === id);
    if (!cat) return;

    document.getElementById('catModalTitle').textContent = 'Edit Custom Category';
    document.getElementById('cat-form-id').value = cat.id;
    document.getElementById('cat-form-name').value = cat.name;
    document.getElementById('cat-form-icon').value = cat.icon || 'fa-tag';
    updateCatIconPreview(cat.icon || 'fa-tag');
    document.getElementById('cat-form-desc').value = cat.description || '';
    bootstrap.Modal.getOrCreateInstance(document.getElementById('categoryModal')).show();
}

async function saveCategoryForm() {
    const id = document.getElementById('cat-form-id').value;
    const name = document.getElementById('cat-form-name').value.trim();
    const icon = document.getElementById('cat-form-icon').value.trim();
    const description = document.getElementById('cat-form-desc').value.trim();

    if (!name) {
        showToast('Please enter a category name', 'warning');
        return;
    }

    try {
        if (id) {
            await API.categories.update(id, { name, icon, description });
            showToast('Category updated successfully!', 'success');
        } else {
            await API.categories.create({ name, icon, description });
            showToast('Custom category created successfully!', 'success');
        }

        const modalEl = document.getElementById('categoryModal');
        const modal = bootstrap.Modal.getInstance(modalEl) || bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.hide();

        await loadCategories();
        loadCategoriesView();
    } catch (err) {
        showToast('Error saving category: ' + err.message, 'error');
    }
}

async function deleteCategoryPrompt(id) {
    const cat = AppState.categories.find(c => c.id === id);
    const catName = cat ? cat.name : 'this category';
    if (!confirm(`Are you sure you want to delete "${catName}"? Any transactions assigned to it will be safely reassigned to 'Other'.`)) {
        return;
    }

    try {
        await API.categories.delete(id);
        showToast('Category deleted successfully! Transactions reassigned to Other.', 'success');
        await loadCategories();
        loadCategoriesView();
    } catch (err) {
        showToast('Failed to delete category: ' + err.message, 'error');
    }
}

// ==========================================================================
// Expense Analysis Module
// ==========================================================================

async function loadAnalysisView() {
    const month = document.getElementById('analysis-month-selector').value || AppState.currentMonth;
    const year = AppState.currentYear;

    try {
        const [daily, weekly, monthly, categories] = await Promise.all([
            API.analysis.getDaily(),
            API.analysis.getWeekly(),
            API.analysis.getMonthly(month, year),
            API.analysis.getCategories()
        ]);

        const c = AppState.currency;

        // 1. Daily Analysis Cards
        document.getElementById('daily-total-spend').textContent = `${c}${formatNumber(daily.todayTotal)}`;
        document.getElementById('daily-tx-count').textContent = daily.transactionCount;
        document.getElementById('daily-highest-spend').textContent = `${c}${formatNumber(daily.highestExpense)}`;
        document.getElementById('daily-avg-spend').textContent = `${c}${formatNumber(daily.averageExpense)}`;

        // 2. Weekly Analysis Cards & Bar Chart
        document.getElementById('weekly-total-spend').textContent = `${c}${formatNumber(weekly.totalWeekly)}`;
        document.getElementById('weekly-avg-daily').textContent = `${c}${formatNumber(weekly.averageDaily)}`;
        document.getElementById('weekly-highest-day').textContent = `${weekly.highestSpendingDay} (${c}${formatNumber(weekly.highestSpendingAmount)})`;
        document.getElementById('weekly-lowest-day').textContent = `${weekly.lowestSpendingDay} (${c}${formatNumber(weekly.lowestSpendingAmount)})`;

        renderWeeklyBarChart(weekly.daySpending);

        // 3. Monthly Analysis Cards & Trend
        document.getElementById('monthly-income-val').textContent = `${c}${formatNumber(monthly.totalIncome)}`;
        document.getElementById('monthly-expense-val').textContent = `${c}${formatNumber(monthly.totalExpenses)}`;
        document.getElementById('monthly-savings-val').textContent = `${c}${formatNumber(monthly.monthlySavings)}`;
        document.getElementById('monthly-avg-daily-val').textContent = `${c}${formatNumber(monthly.averageDailyExpense)}`;

        renderMonthlyTrendChart(monthly.dailyTrend);

        // 4. Category-Wise Analysis Table & Chart
        renderCategoryAnalysis(categories);

    } catch (err) {
        showToast('Error loading analysis data: ' + err.message, 'error');
    }
}

function renderWeeklyBarChart(dayMap) {
    destroyChart('weeklyBarChart');
    const ctx = document.getElementById('weeklyBarChart');
    if (!ctx || !dayMap) return;

    AppState.charts.weeklyBarChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(dayMap),
            datasets: [{
                label: 'Spending by Day',
                data: Object.values(dayMap),
                backgroundColor: '#4f46e5',
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, grid: { color: '#f1f5f9' } },
                x: { grid: { display: false } }
            }
        }
    });
}

function renderMonthlyTrendChart(trendList) {
    destroyChart('analysisMonthlyTrendChart');
    const ctx = document.getElementById('analysisMonthlyTrendChart');
    if (!ctx || !trendList) return;

    AppState.charts.analysisMonthlyTrendChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: trendList.map(t => `Day ${t.day}`),
            datasets: [{
                label: 'Spending Trend',
                data: trendList.map(t => t.amount),
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true } }
        }
    });
}

function renderCategoryAnalysis(categories) {
    const tbody = document.getElementById('analysis-categories-body');
    if (!tbody) return;

    if (!categories || categories.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" class="text-center py-4 text-muted">No expenses recorded for this period.</td></tr>`;
        return;
    }

    tbody.innerHTML = categories.map(cat => `
        <tr>
            <td>
                <span class="badge-category">
                    <i class="fa-solid ${cat.icon || 'fa-tags'} text-primary"></i>
                    ${escapeHtml(cat.name)}
                </span>
            </td>
            <td class="fw-bold text-danger">${AppState.currency}${formatNumber(cat.amount)}</td>
            <td>
                <div class="d-flex align-items-center gap-2">
                    <div class="progress flex-grow-1" style="height: 8px;">
                        <div class="progress-bar bg-primary" style="width: ${cat.percentage}%"></div>
                    </div>
                    <span class="fw-semibold text-muted" style="min-width: 45px;">${cat.percentage}%</span>
                </div>
            </td>
            <td>
                <button class="btn btn-sm btn-outline-primary" onclick="viewCategoryReport(${cat.id || 1})">View Details</button>
            </td>
        </tr>
    `).join('');
}

// ==========================================================================
// Charts & Analytics View
// ==========================================================================

async function loadChartsView() {
    try {
        const ym = new Date();
        const year = AppState.currentYear;
        const month = AppState.currentMonth;
        // First day of current month
        const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
        // Last day of current month
        const lastDay = new Date(year, month, 0).getDate();
        const endDate = `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;

        const [monthly, categories] = await Promise.all([
            API.analysis.getMonthly(month, year),
            API.analysis.getCategories(startDate, endDate)
        ]);

        const c = AppState.currency;

        // 1. Category Pie Chart
        destroyChart('chartCategoryPie');
        const ctxPie = document.getElementById('chartCategoryPie');
        if (ctxPie && categories.length > 0) {
            const colors = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#0ea5e9', '#ec4899', '#14b8a6', '#f97316', '#64748b'];
            AppState.charts.chartCategoryPie = new Chart(ctxPie, {
                type: 'pie',
                data: {
                    labels: categories.map(c => c.name),
                    datasets: [{
                        data: categories.map(c => c.amount),
                        backgroundColor: colors.slice(0, categories.length)
                    }]
                },
                options: { responsive: true, maintainAspectRatio: false }
            });
        }

        // 2. Income vs Expenses Bar Chart
        destroyChart('chartIncomeExpenseBar');
        const ctxBar = document.getElementById('chartIncomeExpenseBar');
        if (ctxBar && monthly) {
            AppState.charts.chartIncomeExpenseBar = new Chart(ctxBar, {
                type: 'bar',
                data: {
                    labels: ['Income', 'Expenses', 'Net Savings'],
                    datasets: [{
                        label: 'Amount (' + c + ')',
                        data: [monthly.totalIncome, monthly.totalExpenses, monthly.monthlySavings],
                        backgroundColor: ['#10b981', '#ef4444', '#4f46e5'],
                        borderRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: { y: { beginAtZero: true } }
                }
            });
        }

        // 3. Savings Trend
        destroyChart('chartSavingsTrend');
        const ctxSavings = document.getElementById('chartSavingsTrend');
        if (ctxSavings) {
            AppState.charts.chartSavingsTrend = new Chart(ctxSavings, {
                type: 'line',
                data: {
                    labels: ['June', 'July', 'August', 'September'],
                    datasets: [{
                        label: 'Savings Trend',
                        data: [12000, 15500, 14200, monthly ? monthly.monthlySavings : 17500],
                        borderColor: '#8b5cf6',
                        backgroundColor: 'rgba(139, 92, 246, 0.15)',
                        fill: true,
                        tension: 0.35
                    }]
                },
                options: { responsive: true, maintainAspectRatio: false }
            });
        }

    } catch (err) {
        showToast('Error loading charts: ' + err.message, 'error');
    }
}

// ==========================================================================
// Budget Management Module
// ==========================================================================

async function loadBudgetView() {
    const monthEl = document.getElementById('budget-month-selector');
    const yearEl = document.getElementById('budget-year-selector');

    // Ensure selector options exist
    if (monthEl && monthEl.children.length === 0) {
        const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        monthEl.innerHTML = months.map((m, idx) =>
            `<option value="${idx + 1}" ${idx + 1 === AppState.currentMonth ? 'selected' : ''}>${m}</option>`
        ).join('');
    }
    if (yearEl && yearEl.children.length === 0) {
        const curYear = AppState.currentYear;
        yearEl.innerHTML = '';
        for (let y = curYear - 2; y <= curYear + 1; y++) {
            const opt = document.createElement('option');
            opt.value = y;
            opt.textContent = y;
            if (y === curYear) opt.selected = true;
            yearEl.appendChild(opt);
        }
    }

    const month = parseInt(monthEl && monthEl.value ? monthEl.value : AppState.currentMonth) || AppState.currentMonth;
    const year = parseInt(yearEl && yearEl.value ? yearEl.value : AppState.currentYear) || AppState.currentYear;

    try {
        const mStr = String(month).padStart(2, '0');
        const lastDay = new Date(year, month, 0).getDate();
        const startDate = `${year}-${mStr}-01`;
        const endDate = `${year}-${mStr}-${String(lastDay).padStart(2, '0')}`;

        const [budget, categories] = await Promise.all([
            API.budget.get(month, year),
            API.analysis.getCategories(startDate, endDate)
        ]);
        const c = AppState.currency || '₹';

        const amountEl = document.getElementById('budget-view-amount');
        if (amountEl) amountEl.textContent = `${c}${formatNumber(budget ? budget.amount : 0)}`;

        const spentEl = document.getElementById('budget-view-spent');
        if (spentEl) spentEl.textContent = `${c}${formatNumber(budget ? budget.spent : 0)}`;

        const remaining = budget ? budget.remaining : 0;
        const remEl = document.getElementById('budget-view-remaining');
        if (remEl) {
            remEl.textContent = `${remaining < 0 ? '-' : ''}${c}${formatNumber(Math.abs(remaining))}`;
            remEl.className = remaining < 0 ? 'fs-5 fw-bold text-danger' : 'fs-5 fw-bold text-success';
        }

        const pct = (budget && budget.usagePercentage) ? budget.usagePercentage : 0;
        const pctEl = document.getElementById('budget-view-pct');
        if (pctEl) pctEl.textContent = `${Math.round(pct * 10) / 10}%`;

        // Input value pre-fill
        const inputAmount = document.getElementById('budget-input-amount');
        if (inputAmount && budget && budget.amount > 0) {
            inputAmount.value = budget.amount;
        }

        // Progress bar
        const progressBar = document.getElementById('budget-view-progress-bar');
        if (progressBar) {
            progressBar.style.width = `${Math.min(pct, 100)}%`;
            if (pct > 100) {
                progressBar.className = 'progress-bar bg-danger';
            } else if (pct >= 85) {
                progressBar.className = 'progress-bar bg-danger';
            } else if (pct >= 70) {
                progressBar.className = 'progress-bar bg-warning';
            } else {
                progressBar.className = 'progress-bar bg-success';
            }
        }

        const alertBanner = document.getElementById('budget-alert-banner');
        if (alertBanner) {
            alertBanner.textContent = (budget && budget.alertMessage) ? budget.alertMessage : 'Budget status loaded.';
            if (pct > 100 || pct >= 85) {
                alertBanner.className = 'alert alert-danger fw-bold mb-4';
            } else if (pct >= 70) {
                alertBanner.className = 'alert alert-warning fw-bold mb-4';
            } else {
                alertBanner.className = 'alert alert-success fw-bold mb-4';
            }
        }

        // Budget gauge chart
        destroyChart('budgetGaugeChart');
        const ctxGauge = document.getElementById('budgetGaugeChart');
        if (ctxGauge && typeof Chart !== 'undefined') {
            const spent = parseFloat(budget ? budget.spent : 0) || 0;
            const budgetAmt = parseFloat(budget ? budget.amount : 0) || 0;
            const remaining2 = Math.max(0, budgetAmt - spent);
            AppState.charts.budgetGaugeChart = new Chart(ctxGauge, {
                type: 'doughnut',
                data: {
                    labels: ['Spent', 'Remaining'],
                    datasets: [{
                        data: budgetAmt > 0 ? [spent, remaining2] : [1, 0],
                        backgroundColor: pct >= 85 ? ['#ef4444', '#e5e7eb'] : pct >= 70 ? ['#f59e0b', '#e5e7eb'] : ['#10b981', '#e5e7eb'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    circumference: 180,
                    rotation: -90,
                    cutout: '75%',
                    plugins: {
                        legend: { position: 'bottom', labels: { boxWidth: 12, padding: 10 } },
                        tooltip: {
                            callbacks: {
                                label: (ctx) => `${ctx.label}: ${c}${formatNumber(ctx.raw)}`
                            }
                        }
                    }
                }
            });
        }

        // Category breakdown table
        renderBudgetCategoryBreakdown(categories, budget);

    } catch (err) {
        console.error('Error in loadBudgetView:', err);
        showToast('Error loading budget details: ' + (err.message || err), 'error');
    }
}

function renderBudgetCategoryBreakdown(categories, budget) {
    const tbody = document.getElementById('budget-categories-body');
    if (!tbody) return;

    const budgetAmt = parseFloat(budget ? budget.amount : 0) || 0;
    const c = AppState.currency || '₹';

    if (!Array.isArray(categories) || categories.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" class="text-center py-4 text-muted">No spending recorded for this period.</td></tr>`;
        return;
    }

    tbody.innerHTML = categories.map(cat => {
        const pctOfBudget = budgetAmt > 0 ? Math.round((cat.amount / budgetAmt) * 100 * 10) / 10 : 0;
        const barColor = pctOfBudget > 30 ? 'bg-danger' : pctOfBudget > 15 ? 'bg-warning' : 'bg-success';
        const icon = cat.icon || 'fa-tags';
        return `
            <tr>
                <td>
                    <span class="badge-category">
                        <i class="fa-solid ${icon} text-primary"></i>
                        ${escapeHtml(cat.name)}
                    </span>
                </td>
                <td class="fw-bold text-danger">${c}${formatNumber(cat.amount)}</td>
                <td><span class="badge ${pctOfBudget > 30 ? 'bg-danger-subtle text-danger' : pctOfBudget > 15 ? 'bg-warning-subtle text-warning' : 'bg-success-subtle text-success'}">${pctOfBudget}%</span></td>
                <td style="min-width: 120px;">
                    <div class="progress" style="height: 8px;">
                        <div class="progress-bar ${barColor}" style="width: ${Math.min(pctOfBudget, 100)}%"></div>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

async function saveMonthlyBudget() {
    const monthEl = document.getElementById('budget-month-selector');
    const yearEl = document.getElementById('budget-year-selector');
    const month = parseInt(monthEl ? monthEl.value : AppState.currentMonth) || AppState.currentMonth;
    const year = parseInt(yearEl ? yearEl.value : AppState.currentYear) || AppState.currentYear;
    const amount = document.getElementById('budget-input-amount').value;

    if (!amount || parseFloat(amount) <= 0) {
        showToast('Please enter a budget amount greater than 0', 'warning');
        return;
    }

    const btn = document.getElementById('btn-save-budget');
    if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Saving...'; }

    try {
        await API.budget.set(month, year, parseFloat(amount));
        const monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        showToast(`Budget for ${monthNames[month-1]} ${year} set to ${AppState.currency}${formatNumber(parseFloat(amount))}!`, 'success');
        loadBudgetView();
        startAlertPolling();
    } catch (err) {
        showToast('Error setting budget: ' + err.message, 'error');
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-floppy-disk me-1"></i> Save Budget'; }
    }
}

function setBudgetPreset(amount) {
    document.getElementById('budget-input-amount').value = amount;
    showToast(`Preset ${AppState.currency}${formatNumber(amount)} selected. Click Save Budget to apply.`, 'info');
}

// ==========================================================================
// Smart Alerts & Notifications
// ==========================================================================

async function loadAlertsView() {
    try {
        const alerts = await API.alerts.list(false);
        const container = document.getElementById('alerts-list-container');

        if (!alerts || alerts.length === 0) {
            container.innerHTML = `<div class="text-center py-5 text-muted"><i class="fa-regular fa-bell-slash fs-1 mb-2 d-block"></i>No financial alerts at this time. You are all set!</div>`;
            return;
        }

        container.innerHTML = alerts.map(alert => {
            const isUnread = !alert.isRead;
            let iconClass = 'fa-bell';
            let iconBg = 'alert-icon-info';

            if (alert.alertType === 'BUDGET') {
                iconClass = 'fa-chart-pie';
                iconBg = 'alert-icon-budget';
            } else if (alert.alertType === 'HIGH_SPENDING') {
                iconClass = 'fa-triangle-exclamation';
                iconBg = 'alert-icon-spend';
            } else if (alert.alertType === 'BILL_REMINDER') {
                iconClass = 'fa-file-invoice-dollar';
                iconBg = 'alert-icon-bill';
            }

            return `
                <div class="alert-item ${isUnread ? 'unread' : ''}">
                    <div class="alert-icon ${iconBg}">
                        <i class="fa-solid ${iconClass}"></i>
                    </div>
                    <div class="flex-grow-1">
                        <div class="d-flex align-items-center justify-content-between mb-1">
                            <h6 class="fw-bold mb-0">${escapeHtml(alert.title)}</h6>
                            <small class="text-muted">${formatDate(alert.createdAt)}</small>
                        </div>
                        <p class="text-secondary small mb-1">${escapeHtml(alert.message)}</p>
                        ${isUnread ? `<button class="btn btn-xs btn-outline-primary" onclick="markAlertAsRead(${alert.id})">Mark as Read</button>` : '<small class="text-muted"><i class="fa-solid fa-check text-success me-1"></i>Read</small>'}
                    </div>
                </div>
            `;
        }).join('');

    } catch (err) {
        showToast('Error loading alerts: ' + err.message, 'error');
    }
}

async function markAlertAsRead(id) {
    try {
        await API.alerts.markAsRead(id);
        loadAlertsView();
        startAlertPolling();
    } catch (err) {
        showToast('Error: ' + err.message, 'error');
    }
}

async function markAllAlertsAsRead() {
    try {
        await API.alerts.markAllAsRead();
        showToast('All notifications marked as read', 'success');
        loadAlertsView();
        startAlertPolling();
    } catch (err) {
        showToast('Error: ' + err.message, 'error');
    }
}

async function startAlertPolling() {
    try {
        const res = await API.alerts.unreadCount();
        const badge = document.getElementById('header-unread-badge');
        if (badge) {
            if (res && res.count > 0) {
                badge.style.display = 'flex';
                badge.textContent = res.count > 9 ? '9+' : res.count;
            } else {
                badge.style.display = 'none';
            }
        }
    } catch (e) {
        // silent polling error
    }
}

// ==========================================================================
// Smart Suggestions Module
// ==========================================================================

async function loadSuggestionsView() {
    try {
        const suggestions = await API.suggestions.list();
        const container = document.getElementById('suggestions-list-container');

        if (!suggestions || suggestions.length === 0) {
            container.innerHTML = `<div class="text-center py-5 text-muted">No suggestions right now. Keep logging transactions to receive intelligent financial advice.</div>`;
            return;
        }

        container.innerHTML = suggestions.map(sug => {
            let impactClass = 'bg-primary-subtle text-primary';
            if (sug.impact === 'HIGH') impactClass = 'bg-danger-subtle text-danger';
            if (sug.impact === 'MEDIUM') impactClass = 'bg-warning-subtle text-warning';

            return `
                <div class="suggestion-card">
                    <div class="suggestion-icon" style="background: var(--primary-soft); color: var(--primary);">
                        <i class="fa-solid ${sug.icon || 'fa-lightbulb'}"></i>
                    </div>
                    <div class="suggestion-content flex-grow-1">
                        <div class="d-flex align-items-center justify-content-between mb-1">
                            <h6>${escapeHtml(sug.title)}</h6>
                            <span class="badge ${impactClass}">${sug.impact} IMPACT</span>
                        </div>
                        <p>${escapeHtml(sug.description)}</p>
                        ${sug.actionUrl ? `<a href="${sug.actionUrl}" class="btn btn-sm btn-outline-primary">Take Action <i class="fa-solid fa-arrow-right ms-1"></i></a>` : ''}
                    </div>
                </div>
            `;
        }).join('');

    } catch (err) {
        showToast('Error loading suggestions: ' + err.message, 'error');
    }
}

// ==========================================================================
// Receipt Scanner (OCR) Module
// ==========================================================================

// Opens the scanner when triggered from the Monthly Report page
function openReportScannerModal() {
    window.location.hash = '#scanner';
    showToast('Upload or scan a receipt to add a transaction from the report view.', 'info');
}

let currentOcrResult = null;
let cameraStream = null;
let currentCameraFacing = 'environment';
let cameraModalInstance = null;

function resetScannerView() {
    currentOcrResult = null;
    document.getElementById('receipt-upload-card').style.display = 'block';
    document.getElementById('receipt-result-card').style.display = 'none';
    const fileInput = document.getElementById('receipt-file-input');
    if (fileInput) fileInput.value = '';
    const mobileInput = document.getElementById('mobile-camera-input');
    if (mobileInput) mobileInput.value = '';
}

async function handleReceiptUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    await processReceiptFile(file);
}

// Live Camera Scanner
async function openLiveCameraScanner() {
    const modalEl = document.getElementById('cameraScannerModal');
    if (!modalEl) return;

    if (!cameraModalInstance) {
        cameraModalInstance = new bootstrap.Modal(modalEl);
    }
    cameraModalInstance.show();

    await startCameraStream();
}

async function startCameraStream() {
    const videoEl = document.getElementById('camera-stream-video');
    const errOverlay = document.getElementById('camera-permission-error');
    const viewfinder = document.getElementById('camera-viewfinder');
    if (!videoEl) return;

    if (errOverlay) errOverlay.style.display = 'none';
    if (viewfinder) viewfinder.style.display = 'flex';

    // Stop existing stream if any
    if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
        cameraStream = null;
    }

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        showCameraPermissionHelp('Camera access is not supported by your current browser. You can use your device camera directly.');
        return;
    }

    let stream = null;
    // Attempt 1: with requested facingMode
    try {
        stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: { ideal: currentCameraFacing } },
            audio: false
        });
    } catch (err1) {
        console.warn('Attempt 1 failed, trying fallback constraint:', err1);
        try {
            // Attempt 2: minimal video constraint (works on standard PC webcams and laptops)
            stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        } catch (err2) {
            console.error('Camera stream access failed:', err2);
            showCameraPermissionHelp(err2.message || 'Camera permission was denied or camera is in use by another app.');
            return;
        }
    }

    cameraStream = stream;
    videoEl.srcObject = cameraStream;
    try {
        await videoEl.play();
    } catch (playErr) {
        console.warn('Video play error:', playErr);
    }
}

function showCameraPermissionHelp(msg) {
    const errOverlay = document.getElementById('camera-permission-error');
    const errMsg = document.getElementById('camera-error-message');
    const viewfinder = document.getElementById('camera-viewfinder');
    if (errOverlay) errOverlay.style.display = 'block';
    if (viewfinder) viewfinder.style.display = 'none';
    if (errMsg) {
        errMsg.innerHTML = `<strong>Camera notice:</strong> ${escapeHtml(msg)}<br><span class="text-white-50 mt-1 d-block">Click the 🔒 lock or 📷 camera icon in your browser's address bar to select <strong>"Allow"</strong>, or tap below to open your device camera directly:</span>`;
    }
    showToast('Camera blocked. Click the address bar icon to allow camera, or tap Device Camera.', 'warning');
}

function triggerMobileCameraFromModal() {
    closeCameraStream();
    if (cameraModalInstance) {
        cameraModalInstance.hide();
    }
    const mobileInput = document.getElementById('mobile-camera-input');
    if (mobileInput) {
        mobileInput.click();
    } else {
        const fileInput = document.getElementById('receipt-file-input');
        if (fileInput) fileInput.click();
    }
}

function closeCameraStream() {
    if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
        cameraStream = null;
    }
    const videoEl = document.getElementById('camera-stream-video');
    if (videoEl) videoEl.srcObject = null;
}

async function switchCameraFacing() {
    currentCameraFacing = (currentCameraFacing === 'environment' ? 'user' : 'environment');
    await startCameraStream();
}

function capturePhotoFromCamera() {
    const videoEl = document.getElementById('camera-stream-video');
    const canvasEl = document.getElementById('camera-capture-canvas');
    if (!videoEl || !canvasEl) return;

    if (!videoEl.videoWidth || !videoEl.videoHeight) {
        showToast('Camera is still initializing, please wait a moment.', 'warning');
        return;
    }

    canvasEl.width = videoEl.videoWidth;
    canvasEl.height = videoEl.videoHeight;
    const ctx = canvasEl.getContext('2d');
    ctx.drawImage(videoEl, 0, 0, canvasEl.width, canvasEl.height);

    canvasEl.toBlob(async (blob) => {
        if (!blob) {
            showToast('Failed to capture frame from camera', 'error');
            return;
        }

        // Close camera and modal
        closeCameraStream();
        if (cameraModalInstance) {
            cameraModalInstance.hide();
        }

        const file = new File([blob], `camera_scan_${Date.now()}.jpg`, { type: 'image/jpeg' });
        await processReceiptFile(file);
    }, 'image/jpeg', 0.92);
}

// Preset samples generator
async function uploadSampleReceiptPreset(type) {
    if (type === 'reliance') {
        try {
            const response = await fetch('/samples/reliance_smart_receipt.jpg');
            const blob = await response.blob();
            const file = new File([blob], "reliance_smart_superstore_receipt.jpg", { type: "image/jpeg" });
            await processReceiptFile(file);
            return;
        } catch (err) {
            console.warn('Could not fetch static sample, generating receipt canvas:', err);
        }
    }

    // Generate realistic simulated receipt canvas for instant test
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 800;
    const ctx = canvas.getContext('2d');

    // Receipt paper background
    ctx.fillStyle = '#fbfbfb';
    ctx.fillRect(0, 0, 600, 800);

    // Dotted border
    ctx.strokeStyle = '#d1d5db';
    ctx.lineWidth = 2;
    ctx.strokeRect(20, 20, 560, 760);

    ctx.fillStyle = '#111827';
    ctx.font = 'bold 26px monospace';
    ctx.textAlign = 'center';

    let filename = 'receipt.jpg';
    if (type === 'starbucks') {
        filename = 'starbucks_coffee_cafe_bill.jpg';
        ctx.fillText('STARBUCKS COFFEE', 300, 80);
        ctx.font = '16px monospace';
        ctx.fillText('Store #4829 - Airport Terminal', 300, 110);
        ctx.fillText(`Date: ${new Date().toISOString().split('T')[0]}`, 300, 140);
        ctx.textAlign = 'left';
        ctx.fillText('----------------------------------', 100, 200);
        ctx.fillText('1x Caffe Latte Grande      ₹340.00', 100, 240);
        ctx.fillText('1x Chocolate Croissant     ₹145.00', 100, 280);
        ctx.fillText('----------------------------------', 100, 320);
        ctx.font = 'bold 20px monospace';
        ctx.fillText('TOTAL AMOUNT:              ₹485.00', 100, 370);
    } else if (type === 'shell') {
        filename = 'shell_fuel_station_petrol.jpg';
        ctx.fillText('SHELL SERVICE STATION', 300, 80);
        ctx.font = '16px monospace';
        ctx.fillText('PUMP #04 - HIGHWAY EXPRESS', 300, 110);
        ctx.fillText(`Date: ${new Date().toISOString().split('T')[0]}`, 300, 140);
        ctx.textAlign = 'left';
        ctx.fillText('----------------------------------', 100, 200);
        ctx.fillText('V-Power Unleaded Petrol 20.48L', 100, 240);
        ctx.fillText('Rate: ₹102.54 / LTR', 100, 270);
        ctx.fillText('----------------------------------', 100, 320);
        ctx.font = 'bold 20px monospace';
        ctx.fillText('TOTAL PAID (UPI):        ₹2,100.00', 100, 370);
    } else if (type === 'apollo') {
        filename = 'apollo_pharmacy_med_invoice.jpg';
        ctx.fillText('APOLLO PHARMACY LTD', 300, 80);
        ctx.font = '16px monospace';
        ctx.fillText('HEALTHCARE & DRUG STORE', 300, 110);
        ctx.fillText(`Invoice: RX-994012`, 300, 140);
        ctx.textAlign = 'left';
        ctx.fillText('----------------------------------', 100, 200);
        ctx.fillText('1x Multivitamin Tablets    ₹520.00', 100, 240);
        ctx.fillText('1x Cetirizine 10mg Strip   ₹120.00', 100, 270);
        ctx.fillText('1x Paracetamol 650 Strip   ₹180.00', 100, 300);
        ctx.fillText('----------------------------------', 100, 340);
        ctx.font = 'bold 20px monospace';
        ctx.fillText('NET PAYABLE:               ₹820.00', 100, 390);
    } else if (type === 'amazon') {
        filename = 'amazon_shopping_invoice.jpg';
        ctx.fillText('AMAZON RETAIL INDIA', 300, 80);
        ctx.font = '16px monospace';
        ctx.fillText('TAX INVOICE - ORDER #402-9842103', 300, 110);
        ctx.textAlign = 'left';
        ctx.fillText('----------------------------------', 100, 200);
        ctx.fillText('1x Wireless ANC Earbuds  ₹2,499.00', 100, 240);
        ctx.fillText('Delivery Charges:            FREE', 100, 270);
        ctx.fillText('----------------------------------', 100, 320);
        ctx.font = 'bold 20px monospace';
        ctx.fillText('GRAND TOTAL:             ₹2,499.00', 100, 370);
    } else {
        filename = 'reliance_smart_supermarket.jpg';
        ctx.fillText('RELIANCE SMART SUPERSTORE', 300, 80);
        ctx.font = '16px monospace';
        ctx.fillText('Retail Supermarket Invoice', 300, 110);
        ctx.textAlign = 'left';
        ctx.fillText('----------------------------------', 100, 200);
        ctx.fillText('Aashirvaad Atta 5kg        ₹265.00', 100, 240);
        ctx.fillText('Amul Butter 500g           ₹275.00', 100, 270);
        ctx.fillText('Tata Tea Gold 1kg          ₹480.00', 100, 300);
        ctx.fillText('Fortune Sunflower Oil 1L   ₹225.00', 100, 330);
        ctx.fillText('----------------------------------', 100, 370);
        ctx.font = 'bold 20px monospace';
        ctx.fillText('TOTAL AMOUNT:            ₹1,245.00', 100, 420);
    }

    canvas.toBlob(async (blob) => {
        const file = new File([blob], filename, { type: 'image/jpeg' });
        await processReceiptFile(file);
    }, 'image/jpeg', 0.9);
}

async function uploadSampleReceipt() {
    await uploadSampleReceiptPreset('reliance');
}

async function processReceiptFile(file) {
    // Show progress in scanner
    const progressEl = document.getElementById('scanner-progress-bar');
    if (progressEl) progressEl.style.display = 'block';
    showToast('Scanning receipt using OCR engine...', 'info');

    try {
        const result = await API.scanner.scanReceipt(file);
        if (!result || !result.success) {
            showToast(result ? result.message : 'Failed to scan receipt', 'error');
            return;
        }

        currentOcrResult = result;

        // Add to scan history
        addToScanHistory(result, file.name);

        // Display results for user review
        document.getElementById('receipt-upload-card').style.display = 'none';
        document.getElementById('receipt-result-card').style.display = 'block';

        document.getElementById('ocr-merchant-name').value = result.merchantName || '';
        document.getElementById('ocr-date').value = result.date || new Date().toISOString().split('T')[0];
        document.getElementById('ocr-amount').value = result.totalAmount || '';

        // Category
        populateCategoryDropdown('ocr-category', result.suggestedCategoryId);

        // Preview image
        const previewImg = document.getElementById('ocr-preview-image');
        if (result.receiptImagePath && previewImg) {
            previewImg.src = result.receiptImagePath;
            previewImg.style.display = 'block';
        } else if (previewImg) {
            previewImg.style.display = 'none';
        }

        // Line items list
        const itemsList = document.getElementById('ocr-items-list');
        if (result.detectedItems && result.detectedItems.length > 0) {
            itemsList.innerHTML = result.detectedItems.map(item => `<div class="list-group-item py-1">${escapeHtml(item)}</div>`).join('');
        } else {
            itemsList.innerHTML = `<div class="list-group-item text-muted py-1">Itemized details not available</div>`;
        }

        showToast('Receipt scanned! Review and save transaction.', 'success');

    } catch (err) {
        showToast('OCR scan failed: ' + err.message, 'error');
    } finally {
        if (progressEl) progressEl.style.display = 'none';
    }
}

// Scan history storage
let scanHistory = [];

function addToScanHistory(result, filename) {
    const entry = {
        id: Date.now(),
        filename: filename || 'receipt.jpg',
        merchant: result.merchantName || 'Unknown',
        amount: result.totalAmount || 0,
        date: result.date || new Date().toISOString().split('T')[0],
        imagePath: result.receiptImagePath,
        timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
    };
    scanHistory.unshift(entry);
    if (scanHistory.length > 10) scanHistory.pop();
    renderScanHistory();
}

function renderScanHistory() {
    const container = document.getElementById('scan-history-list');
    const countBadge = document.getElementById('scan-history-count');
    if (!container) return;

    if (countBadge) countBadge.textContent = `${scanHistory.length} scan${scanHistory.length !== 1 ? 's' : ''}`;

    if (scanHistory.length === 0) {
        container.innerHTML = `<div class="text-center py-4 text-muted small"><i class="fa-solid fa-receipt fa-2x mb-2 d-block opacity-50"></i>Your scanned receipts will appear here.</div>`;
        return;
    }

    const c = AppState.currency;
    container.innerHTML = scanHistory.map(entry => `
        <div class="d-flex align-items-center gap-3 p-3 border-bottom hover-bg" style="cursor: pointer;" onclick="recallScanEntry(${entry.id})">
            <div class="rounded-2 p-2" style="background: var(--primary-soft); flex-shrink: 0;">
                <i class="fa-solid fa-receipt text-primary"></i>
            </div>
            <div class="flex-grow-1 overflow-hidden">
                <div class="fw-semibold text-truncate" style="font-size: 0.85rem;">${escapeHtml(entry.merchant)}</div>
                <div class="text-muted" style="font-size: 0.75rem;">${entry.filename} &bull; ${entry.timestamp}</div>
            </div>
            <div class="text-danger fw-bold" style="font-size: 0.85rem; flex-shrink: 0;">${c}${formatNumber(entry.amount)}</div>
        </div>
    `).join('');
}

async function confirmOcrTransaction() {
    const merchantName = document.getElementById('ocr-merchant-name').value.trim();
    const transactionDate = document.getElementById('ocr-date').value;
    const amount = document.getElementById('ocr-amount').value;
    const categoryId = document.getElementById('ocr-category').value;
    const paymentMethodEl = document.getElementById('ocr-payment-method');
    const paymentMethod = paymentMethodEl ? paymentMethodEl.value : 'UPI';

    if (!amount || parseFloat(amount) <= 0) {
        showToast('Please enter a valid amount', 'warning');
        return;
    }
    if (!transactionDate) {
        showToast('Please select a valid date', 'warning');
        return;
    }

    const payload = {
        type: 'EXPENSE',
        amount: parseFloat(amount),
        categoryId: categoryId ? parseInt(categoryId) : null,
        description: `Receipt: ${merchantName || 'Store Purchase'}`,
        merchantName: merchantName || 'Store',
        transactionDate,
        paymentMethod,
        receiptPath: currentOcrResult ? currentOcrResult.receiptImagePath : null,
        notes: 'Digitized from receipt via Smart OCR Scanner'
    };

    try {
        await API.transactions.create(payload);
        showToast(`Receipt transaction saved! \u20b9${formatNumber(parseFloat(amount))} expense recorded.`, 'success');
        resetScannerView();
        // Stay on scanner page to allow more scans
        setTimeout(() => startAlertPolling(), 500);
    } catch (err) {
        showToast('Error confirming transaction: ' + err.message, 'error');
    }
}

function handleScannerDrop(event) {
    event.preventDefault();
    const dropZone = document.getElementById('scanner-drop-zone');
    if (dropZone) dropZone.classList.remove('drag-over');

    const files = event.dataTransfer.files;
    if (files && files.length > 0) {
        const file = files[0];
        const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf'];
        if (!validTypes.includes(file.type)) {
            showToast('Please upload a JPG, PNG, or PDF receipt file', 'warning');
            return;
        }
        processReceiptFile(file);
    }
}

function recallScanEntry(id) {
    const entry = scanHistory.find(e => e.id === id);
    if (!entry) return;

    const uploadCard = document.getElementById('receipt-upload-card');
    const resultCard = document.getElementById('receipt-result-card');
    if (uploadCard) uploadCard.style.display = 'none';
    if (resultCard) resultCard.style.display = 'block';

    const merchantEl = document.getElementById('ocr-merchant-name');
    if (merchantEl) merchantEl.value = entry.merchant || '';

    const dateEl = document.getElementById('ocr-date');
    if (dateEl) dateEl.value = entry.date || new Date().toISOString().split('T')[0];

    const amountEl = document.getElementById('ocr-amount');
    if (amountEl) amountEl.value = entry.amount || '';

    const previewImg = document.getElementById('ocr-preview-image');
    if (previewImg) {
        if (entry.imagePath) {
            previewImg.src = entry.imagePath;
            previewImg.style.display = 'block';
        } else {
            previewImg.style.display = 'none';
        }
    }

    showToast(`Loaded ${entry.merchant} (₹${formatNumber(entry.amount)}) for review`, 'info');
}

// ==========================================================================
// Bank Statement Import Module
// ==========================================================================

let stagedBankItems = [];

async function loadBankPendingTransactions() {
    try {
        const items = await API.bank.getPending();
        stagedBankItems = items || [];
        renderBankStagingTable();
    } catch (err) {
        console.error('Error fetching staged bank transactions:', err);
    }
}

async function handleBankFileUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    await processBankStatementFile(file);
}

async function uploadSampleBankStatement() {
    try {
        const res = await fetch('/samples/sample_bank_statement.csv');
        const text = await res.text();
        const file = new File([text], "sample_bank_statement.csv", { type: "text/csv" });
        await processBankStatementFile(file);
    } catch (err) {
        showToast('Error loading sample statement: ' + err.message, 'error');
    }
}

async function processBankStatementFile(file) {
    showToast('Importing and auto-categorizing statement transactions...', 'info');

    try {
        const res = await API.bank.importStatement(file);
        if (res && res.success) {
            showToast(res.message, 'success');
            stagedBankItems = res.transactions || [];
            renderBankStagingTable();
        } else {
            showToast(res.message || 'Import failed', 'error');
        }
    } catch (err) {
        showToast('Error importing statement: ' + err.message, 'error');
    }
}

function renderBankStagingTable() {
    const tbody = document.getElementById('bank-staging-body');
    const importBtn = document.getElementById('btn-confirm-bank-import');

    if (!stagedBankItems || stagedBankItems.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="text-center py-5 text-muted">No pending bank statement transactions. Upload a CSV or PDF file above to review.</td></tr>`;
        importBtn.disabled = true;
        return;
    }

    importBtn.disabled = false;
    tbody.innerHTML = stagedBankItems.map((item, idx) => {
        const isExpense = item.type === 'EXPENSE';
        const sign = isExpense ? '-' : '+';
        const badgeClass = isExpense ? 'badge-expense' : 'badge-income';

        // Build category dropdown options for this item
        const catOptions = AppState.categories.map(c =>
            `<option value="${c.id}" ${item.categoryId === c.id ? 'selected' : ''}>${c.name}</option>`
        ).join('');

        return `
            <tr>
                <td>
                    <input type="checkbox" class="form-check-input bank-item-check" data-index="${idx}" checked>
                </td>
                <td>${formatDate(item.transactionDate)}</td>
                <td class="fw-semibold small">${escapeHtml(item.description)}</td>
                <td><span class="badge ${isExpense ? 'bg-danger-subtle text-danger' : 'bg-success-subtle text-success'}">${item.type}</span></td>
                <td class="${badgeClass}">${sign}${AppState.currency}${formatNumber(item.amount)}</td>
                <td>
                    <select class="form-select form-select-sm bank-cat-select" data-index="${idx}">
                        ${catOptions}
                    </select>
                </td>
                <td><span class="badge bg-warning-subtle text-warning">Pending Review</span></td>
            </tr>
        `;
    }).join('');
}

async function confirmBankTransactions() {
    const checkboxes = document.querySelectorAll('.bank-item-check:checked');
    if (checkboxes.length === 0) {
        showToast('Please select at least one transaction to import', 'warning');
        return;
    }

    const itemsToConfirm = [];
    checkboxes.forEach(cb => {
        const idx = parseInt(cb.dataset.index);
        const item = stagedBankItems[idx];
        const select = document.querySelector(`.bank-cat-select[data-index="${idx}"]`);
        if (select) {
            item.categoryId = parseInt(select.value);
        }
        itemsToConfirm.push(item);
    });

    try {
        const res = await API.bank.confirm(itemsToConfirm);
        showToast(res.message || 'Transactions imported successfully!', 'success');
        stagedBankItems = [];
        renderBankStagingTable();
        window.location.hash = '#transactions';
    } catch (err) {
        showToast('Error confirming bank transactions: ' + err.message, 'error');
    }
}

// ==========================================================================
// Financial Reports Module
// ==========================================================================

async function loadMonthlyReport() {
    const month = document.getElementById('report-month-selector').value || AppState.currentMonth;
    const year = AppState.currentYear;

    try {
        const report = await API.reports.getMonthly(month, year);
        const c = AppState.currency;

        document.getElementById('rep-user-name').textContent = report.userName;
        document.getElementById('rep-user-email').textContent = report.userEmail;
        document.getElementById('rep-month-title').textContent = `${report.month} ${report.year}`;

        document.getElementById('rep-income').textContent = `${c}${formatNumber(report.totalIncome)}`;
        document.getElementById('rep-expense').textContent = `${c}${formatNumber(report.totalExpense)}`;
        document.getElementById('rep-savings').textContent = `${c}${formatNumber(report.totalSavings)}`;
        document.getElementById('rep-budget').textContent = `${c}${formatNumber(report.monthlyBudget)}`;
        document.getElementById('rep-remaining-budget').textContent = `${c}${formatNumber(report.remainingBudget)}`;
        document.getElementById('rep-budget-usage').textContent = `${report.budgetUsagePercentage}%`;

        document.getElementById('rep-highest-cat').textContent = report.highestCategory;
        document.getElementById('rep-highest-cat-amt').textContent = `${c}${formatNumber(report.highestCategoryAmount)}`;
        document.getElementById('rep-avg-daily').textContent = `${c}${formatNumber(report.averageDailyExpense)}`;
        document.getElementById('rep-total-tx').textContent = report.transactionCount;

        // Render categories table in report
        const catBody = document.getElementById('report-categories-body');
        if (report.categories && report.categories.length > 0) {
            catBody.innerHTML = report.categories.map(cItem => `
                <tr>
                    <td><i class="fa-solid ${cItem.icon || 'fa-tags'} me-2 text-primary"></i>${escapeHtml(cItem.name)}</td>
                    <td class="fw-bold">${c}${formatNumber(cItem.amount)}</td>
                    <td>${cItem.percentage}%</td>
                </tr>
            `).join('');
        } else {
            catBody.innerHTML = `<tr><td colspan="3" class="text-center text-muted">No expense categories recorded for this month.</td></tr>`;
        }

        // Render transactions in report
        const txBody = document.getElementById('report-tx-body');
        if (report.transactions && report.transactions.length > 0) {
            txBody.innerHTML = report.transactions.map(t => `
                <tr>
                    <td>${formatDate(t.transactionDate)}</td>
                    <td>${escapeHtml(t.description)}</td>
                    <td>${escapeHtml(t.categoryName || 'Other')}</td>
                    <td>${t.paymentMethod}</td>
                    <td class="${t.type === 'EXPENSE' ? 'text-danger' : 'text-success'} fw-bold">${t.type === 'EXPENSE' ? '-' : '+'}${c}${formatNumber(t.amount)}</td>
                </tr>
            `).join('');
        } else {
            txBody.innerHTML = `<tr><td colspan="5" class="text-center text-muted">No transactions found.</td></tr>`;
        }

    } catch (err) {
        showToast('Error loading monthly report: ' + err.message, 'error');
    }
}

function downloadPdfReport() {
    const month = document.getElementById('report-month-selector').value || AppState.currentMonth;
    const year = AppState.currentYear;
    const url = API.reports.getPdfUrl(month, year);
    window.open(url, '_blank');
}

function printReport() {
    window.print();
}

async function loadCategoryReport(targetCatId = null) {
    // Ensure categories are loaded first
    if (!AppState.categories || AppState.categories.length === 0) {
        await loadCategories();
    }
    populateCategoryDropdown('category-report-selector');
    const select = document.getElementById('category-report-selector');
    let catId = targetCatId || (select ? select.value : null);
    if (!catId && AppState.categories && AppState.categories.length > 0) {
        catId = AppState.categories[0].id;
    }
    if (select && catId) {
        select.value = catId;
    }
    if (!catId) return;

    viewCategoryReport(catId);
}


async function viewCategoryReport(catId) {
    if (!catId) return;
    if (window.location.hash !== '#category-report') {
        window.location.hash = '#category-report';
    }

    const select = document.getElementById('category-report-selector');
    if (select) {
        select.value = catId;
    }

    const month = AppState.currentMonth;
    const year = AppState.currentYear;

    try {
        const data = await API.reports.getCategory(catId, month, year);
        const c = AppState.currency;

        document.getElementById('cat-rep-title').textContent = data.categoryName || 'Category Report';
        document.getElementById('cat-rep-total').textContent = `${c}${formatNumber(data.totalSpending || 0)}`;
        document.getElementById('cat-rep-count').textContent = data.transactionCount || 0;
        document.getElementById('cat-rep-avg').textContent = `${c}${formatNumber(data.averageTransaction || 0)}`;
        document.getElementById('cat-rep-pct').textContent = `${data.percentageOfTotalExpenses || 0}%`;

        const tbody = document.getElementById('cat-report-tx-body');
        if (data.transactions && data.transactions.length > 0) {
            tbody.innerHTML = data.transactions.map(t => `
                <tr>
                    <td>${formatDate(t.transactionDate)}</td>
                    <td>${escapeHtml(t.description)}</td>
                    <td>${t.paymentMethod}</td>
                    <td class="text-danger fw-bold">-${c}${formatNumber(t.amount)}</td>
                </tr>
            `).join('');
        } else {
            tbody.innerHTML = `<tr><td colspan="4" class="text-center text-muted py-4">No transactions found in this category for the month.</td></tr>`;
        }
    } catch (err) {
        showToast('Error loading category report: ' + err.message, 'error');
    }
}

// ==========================================================================
// Profile & Settings Module
// ==========================================================================

async function loadProfileView() {
    try {
        const profile = await API.profile.get();
        document.getElementById('profile-form-name').value = profile.name || '';
        document.getElementById('profile-form-email').value = profile.email || '';
        document.getElementById('profile-form-mobile').value = profile.mobile || '';
        document.getElementById('profile-form-currency').value = profile.currency || '₹';
    } catch (err) {
        showToast('Error loading profile: ' + err.message, 'error');
    }
}

async function saveProfile() {
    const name = document.getElementById('profile-form-name').value.trim();
    const mobile = document.getElementById('profile-form-mobile').value.trim();
    const currency = document.getElementById('profile-form-currency').value;

    if (!name) {
        showToast('Name cannot be empty', 'warning');
        return;
    }

    try {
        const res = await API.profile.update({ name, mobile, currency });
        AppState.currency = res.currency;
        AppState.user.name = res.name;
        AppState.user.currency = res.currency;
        updateUserUI();
        showToast('Profile updated successfully!', 'success');
    } catch (err) {
        showToast('Error: ' + err.message, 'error');
    }
}

async function changePasswordForm() {
    const currentPassword = document.getElementById('pass-current').value;
    const newPassword = document.getElementById('pass-new').value;
    const confirmPassword = document.getElementById('pass-confirm').value;

    if (!currentPassword || !newPassword) {
        showToast('Please fill out all password fields', 'warning');
        return;
    }
    if (newPassword !== confirmPassword) {
        showToast('New password and confirmation do not match', 'warning');
        return;
    }

    try {
        const res = await API.profile.changePassword({ currentPassword, newPassword, confirmPassword });
        showToast(res.message, 'success');
        document.getElementById('pass-current').value = '';
        document.getElementById('pass-new').value = '';
        document.getElementById('pass-confirm').value = '';
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// ==========================================================================
// Event Listeners & Interactive Controls
// ==========================================================================

function setupEventListeners() {
    // Sidebar toggle (mobile)
    const toggleBtn = document.getElementById('btn-sidebar-toggle');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            document.getElementById('sidebar').classList.toggle('show');
        });
    }

    // Password strength check on registration
    const regPass = document.getElementById('reg-password');
    if (regPass) {
        regPass.addEventListener('input', (e) => {
            updatePasswordStrength(e.target.value);
        });
    }
}

// Share modal
function openShareModal() {
    bootstrap.Modal.getOrCreateInstance(document.getElementById('shareModal')).show();
    const isLocal = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
    const networkUrl = isLocal ? 'http://10.176.58.55:8080' : window.location.origin;
    const netUrlInput = document.getElementById('share-network-url');
    const localUrlInput = document.getElementById('share-local-url');
    const qrImg = document.getElementById('share-qr-image');
    if (netUrlInput) netUrlInput.value = networkUrl;
    if (localUrlInput) localUrlInput.value = 'http://localhost:8080';
    if (qrImg) qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(networkUrl)}`;
}

function copyShareLink(inputId) {
    const input = document.getElementById(inputId);
    if (!input) return;
    navigator.clipboard.writeText(input.value).then(() => {
        showToast('Link copied to clipboard!', 'success');
    }).catch(() => {
        input.select();
        document.execCommand('copy');
        showToast('Link copied!', 'success');
    });
}

function updatePasswordStrength(val) {
    const bar = document.getElementById('reg-password-strength-bar');
    if (!bar) return;

    let score = 0;
    if (val.length >= 6) score += 25;
    if (/[A-Z]/.test(val)) score += 25;
    if (/[0-9]/.test(val)) score += 25;
    if (/[^A-Za-z0-9]/.test(val)) score += 25;

    bar.style.width = `${score}%`;
    if (score < 50) bar.style.backgroundColor = '#ef4444';
    else if (score < 75) bar.style.backgroundColor = '#f59e0b';
    else bar.style.backgroundColor = '#10b981';
}

// Auth Handlers
async function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;

    try {
        const res = await API.auth.login(email, password);
        if (res && res.success) {
            AppState.user = res;
            AppState.currency = res.currency || '₹';
            updateUserUI();
            await loadCategories();
            showToast('Welcome back, ' + res.name + '!', 'success');
            window.location.hash = '#dashboard';
            handleRoute();
            startAlertPolling();
        }
    } catch (err) {
        showToast(err.message || 'Login failed', 'error');
    }
}

async function handleRegister(e) {
    e.preventDefault();
    const name = document.getElementById('reg-name').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const mobile = document.getElementById('reg-mobile').value.trim();
    const password = document.getElementById('reg-password').value;
    const confirmPassword = document.getElementById('reg-confirm-password').value;
    const terms = document.getElementById('reg-terms').checked;

    if (!terms) {
        showToast('Please agree to Terms & Conditions', 'warning');
        return;
    }

    try {
        const res = await API.auth.register({ name, email, mobile, password, confirmPassword });
        if (res && res.success) {
            showToast('Account registered! Please log in.', 'success');
            showAuthView('login');
            document.getElementById('login-email').value = email;
        }
    } catch (err) {
        showToast(err.message || 'Registration failed', 'error');
    }
}

function fillDemoCredentials() {
    document.getElementById('login-email').value = 'demo@expensetracker.com';
    document.getElementById('login-password').value = 'Password123';
    showToast('Demo credentials filled! Click Log In.', 'info');
}

async function handleLogout() {
    try {
        await API.auth.logout();
        AppState.user = null;
        showToast('Logged out successfully', 'info');
        showAuthView('login');
    } catch (err) {
        showToast('Error during logout', 'error');
    }
}

// Utility Helpers
function formatNumber(num) {
    if (num === null || num === undefined) return '0.00';
    return Number(num).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatDate(dateStr) {
    if (!dateStr) return '-';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>'"]/g, tag => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        "'": '&#39;',
        '"': '&quot;'
    }[tag] || tag));
}

function destroyChart(chartKey) {
    if (AppState.charts[chartKey]) {
        try { AppState.charts[chartKey].destroy(); } catch (e) {}
        delete AppState.charts[chartKey];
    }
    const canvas = document.getElementById(chartKey);
    if (canvas && typeof Chart !== 'undefined' && Chart.getChart) {
        try {
            const existing = Chart.getChart(canvas);
            if (existing) existing.destroy();
        } catch (e) {}
    }
}

function viewReceiptImage(path) {
    window.open(path, '_blank');
}

function showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `custom-toast toast-${type}`;

    let icon = 'fa-circle-check';
    if (type === 'error') icon = 'fa-circle-xmark';
    if (type === 'warning') icon = 'fa-triangle-exclamation';
    if (type === 'info') icon = 'fa-circle-info';

    toast.innerHTML = `<i class="fa-solid ${icon}"></i><span>${escapeHtml(message)}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}
