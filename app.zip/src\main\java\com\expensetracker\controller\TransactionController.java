package com.expensetracker.controller;

import com.expensetracker.dto.TransactionDto;
import com.expensetracker.model.User;
import com.expensetracker.security.SecurityUtil;
import com.expensetracker.service.TransactionService;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private SecurityUtil securityUtil;

    @GetMapping
    public ResponseEntity<List<TransactionDto>> getTransactions(
            @RequestParam(required = false) String type,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(required = false) String paymentMethod,
            @RequestParam(required = false) BigDecimal minAmount,
            @RequestParam(required = false) BigDecimal maxAmount,
            @RequestParam(required = false) String keyword) {

        User user = securityUtil.getRequiredCurrentUser();
        List<TransactionDto> list = transactionService.searchTransactions(
                user.getId(), type, categoryId, startDate, endDate, paymentMethod, minAmount, maxAmount, keyword);
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TransactionDto> getTransactionById(@PathVariable Long id) {
        User user = securityUtil.getRequiredCurrentUser();
        TransactionDto dto = transactionService.getTransactionById(id, user.getId());
        return ResponseEntity.ok(dto);
    }

    @PostMapping
    public ResponseEntity<TransactionDto> createTransaction(@Valid @RequestBody TransactionDto dto) {
        User user = securityUtil.getRequiredCurrentUser();
        TransactionDto created = transactionService.createTransaction(user, dto);
        return ResponseEntity.ok(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<TransactionDto> updateTransaction(
            @PathVariable Long id,
            @Valid @RequestBody TransactionDto dto) {

        User user = securityUtil.getRequiredCurrentUser();
        TransactionDto updated = transactionService.updateTransaction(user, id, dto);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTransaction(@PathVariable Long id) {
        User user = securityUtil.getRequiredCurrentUser();
        transactionService.deleteTransaction(user, id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/export")
    public void exportTransactionsToCsv(HttpServletResponse response) throws IOException {
        User user = securityUtil.getRequiredCurrentUser();
        List<TransactionDto> list = transactionService.getAllTransactions(user.getId());

        response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment; filename=\"transactions_" + LocalDate.now() + ".csv\"");

        try (CSVPrinter printer = new CSVPrinter(response.getWriter(), CSVFormat.DEFAULT.builder().setHeader(
                "ID", "Date", "Type", "Category", "Description", "Amount (" + user.getCurrency() + ")", "Payment Method", "Merchant", "Notes").build())) {

            for (TransactionDto t : list) {
                printer.printRecord(
                        t.getId(),
                        t.getTransactionDate(),
                        t.getType(),
                        t.getCategoryName(),
                        t.getDescription(),
                        t.getAmount(),
                        t.getPaymentMethod(),
                        t.getMerchantName() != null ? t.getMerchantName() : "",
                        t.getNotes() != null ? t.getNotes() : ""
                );
            }
        }
    }
}
