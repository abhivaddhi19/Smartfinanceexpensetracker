package com.expensetracker.dto;

public class AuthResponse {
    private boolean success;
    private String message;
    private Long userId;
    private String name;
    private String email;
    private String currency;

    public AuthResponse() {}

    public AuthResponse(boolean success, String message, Long userId, String name, String email, String currency) {
        this.success = success;
        this.message = message;
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.currency = currency;
    }

    public static AuthResponse success(String message, Long userId, String name, String email, String currency) {
        return new AuthResponse(true, message, userId, name, email, currency);
    }

    public static AuthResponse error(String message) {
        return new AuthResponse(false, message, null, null, null, null);
    }

    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
}
