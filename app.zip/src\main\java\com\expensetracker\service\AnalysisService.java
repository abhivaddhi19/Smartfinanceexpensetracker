package com.expensetracker.service;

import com.expensetracker.dto.AnalysisDto;
import com.expensetracker.model.Transaction;
import com.expensetracker.model.User;
import com.expensetracker.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.temporal.TemporalAdjusters;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AnalysisService {

    @Autowired
    private TransactionRepository transactionRepository;

    public AnalysisDto.DailyAnalysis getDailyAnalysis(User user, LocalDate date) {
        if (date == null) date = LocalDate.now();

        List<Transaction> expenses = transactionRepository.findByUserIdAndTransactionDateBetween(user.getId(), date, date)
                .stream().filter(t -> "EXPENSE".equalsIgnoreCase(t.getType()))
                .collect(Collectors.toList());

        AnalysisDto.DailyAnalysis daily = new AnalysisDto.DailyAnalysis();
        daily.setTransactionCount(expenses.size());

        if (expenses.isEmpty()) {
            daily.setHourlyExpenses(Collections.emptyList());
            return daily;
        }

        BigDecimal total = BigDecimal.ZERO;
        BigDecimal highest = BigDecimal.ZERO;
        for (Transaction t : expenses) {
            if (t != null && t.getAmount() != null) {
                BigDecimal amt = t.getAmount();
                total = total.add(amt);
                if (amt.compareTo(highest) > 0) {
                    highest = amt;
                }
            }
        }
        daily.setTodayTotal(total);
        daily.setHighestExpense(highest);

        BigDecimal avg = total.divide(BigDecimal.valueOf(expenses.size()), 2, RoundingMode.HALF_UP);
        daily.setAverageExpense(avg);

        // Hourly breakdown
        Map<Integer, BigDecimal> hourMap = new TreeMap<>();
        for (int h = 0; h < 24; h++) hourMap.put(h, BigDecimal.ZERO);

        for (Transaction t : expenses) {
            int h = (t.getCreatedAt() != null) ? t.getCreatedAt().getHour() : 12;
            hourMap.put(h, hourMap.get(h).add(t.getAmount()));
        }

        List<Map<String, Object>> hourlyList = new ArrayList<>();
        hourMap.forEach((hour, amt) -> {
            Map<String, Object> m = new HashMap<>();
            m.put("hour", String.format("%02d:00", hour));
            m.put("amount", amt);
            hourlyList.add(m);
        });
        daily.setHourlyExpenses(hourlyList);

        return daily;
    }

    public AnalysisDto.WeeklyAnalysis getWeeklyAnalysis(User user, LocalDate referenceDate) {
        if (referenceDate == null) referenceDate = LocalDate.now();

        LocalDate monday = referenceDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate sunday = referenceDate.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY));

        List<Transaction> weekExpenses = transactionRepository.findByUserIdAndTransactionDateBetween(user.getId(), monday, sunday)
                .stream().filter(t -> "EXPENSE".equalsIgnoreCase(t.getType()))
                .collect(Collectors.toList());

        Map<String, BigDecimal> daySpending = new LinkedHashMap<>();
        daySpending.put("Monday", BigDecimal.ZERO);
        daySpending.put("Tuesday", BigDecimal.ZERO);
        daySpending.put("Wednesday", BigDecimal.ZERO);
        daySpending.put("Thursday", BigDecimal.ZERO);
        daySpending.put("Friday", BigDecimal.ZERO);
        daySpending.put("Saturday", BigDecimal.ZERO);
        daySpending.put("Sunday", BigDecimal.ZERO);

        BigDecimal totalWeekly = BigDecimal.ZERO;
        for (Transaction t : weekExpenses) {
            String dayName = t.getTransactionDate().getDayOfWeek().toString();
            // Capitalize First Letter: e.g. MONDAY -> Monday
            String formatted = dayName.substring(0, 1).toUpperCase() + dayName.substring(1).toLowerCase();
            daySpending.put(formatted, daySpending.getOrDefault(formatted, BigDecimal.ZERO).add(t.getAmount()));
            totalWeekly = totalWeekly.add(t.getAmount());
        }

        AnalysisDto.WeeklyAnalysis weekly = new AnalysisDto.WeeklyAnalysis();
        weekly.setDaySpending(daySpending);
        weekly.setTotalWeekly(totalWeekly);
        weekly.setAverageDaily(totalWeekly.divide(BigDecimal.valueOf(7), 2, RoundingMode.HALF_UP));

        String highestDay = "N/A";
        BigDecimal maxAmt = BigDecimal.ZERO;
        String lowestDay = "N/A";
        BigDecimal minAmt = BigDecimal.valueOf(Double.MAX_VALUE);

        for (Map.Entry<String, BigDecimal> entry : daySpending.entrySet()) {
            if (entry.getValue().compareTo(maxAmt) > 0) {
                maxAmt = entry.getValue();
                highestDay = entry.getKey();
            }
            if (entry.getValue().compareTo(minAmt) < 0) {
                minAmt = entry.getValue();
                lowestDay = entry.getKey();
            }
        }

        weekly.setHighestSpendingDay(highestDay);
        weekly.setHighestSpendingAmount(maxAmt);
        weekly.setLowestSpendingDay(lowestDay.equals("N/A") ? "None" : lowestDay);
        weekly.setLowestSpendingAmount(minAmt.compareTo(BigDecimal.valueOf(Double.MAX_VALUE)) == 0 ? BigDecimal.ZERO : minAmt);

        return weekly;
    }

    public AnalysisDto.MonthlyAnalysis getMonthlyAnalysis(User user, int month, int year) {
        YearMonth ym = YearMonth.of(year, month);
        LocalDate start = ym.atDay(1);
        LocalDate end = ym.atEndOfMonth();

        BigDecimal income = transactionRepository.sumAmountByUserIdAndTypeAndDateBetween(
                user.getId(), "INCOME", start, end);
        if (income == null) income = BigDecimal.ZERO;

        BigDecimal expense = transactionRepository.sumAmountByUserIdAndTypeAndDateBetween(
                user.getId(), "EXPENSE", start, end);
        if (expense == null) expense = BigDecimal.ZERO;

        List<Transaction> txList = transactionRepository.findByUserIdAndTransactionDateBetween(user.getId(), start, end)
                .stream().filter(t -> "EXPENSE".equalsIgnoreCase(t.getType()))
                .collect(Collectors.toList());

        BigDecimal highest = BigDecimal.ZERO;
        BigDecimal lowest = txList.isEmpty() ? BigDecimal.ZERO : null;
        for (Transaction t : txList) {
            if (t != null && t.getAmount() != null) {
                BigDecimal amt = t.getAmount();
                if (amt.compareTo(highest) > 0) {
                    highest = amt;
                }
                if (lowest == null || amt.compareTo(lowest) < 0) {
                    lowest = amt;
                }
            }
        }
        if (lowest == null) lowest = BigDecimal.ZERO;

        int daysInMonth = ym.lengthOfMonth();
        BigDecimal avgDaily = expense.divide(BigDecimal.valueOf(daysInMonth), 2, RoundingMode.HALF_UP);

        // Daily trend
        List<Object[]> trendRows = transactionRepository.findDailyExpenseTrend(user.getId(), start, end);
        Map<String, BigDecimal> trendMap = new TreeMap<>();
        for (int d = 1; d <= daysInMonth; d++) {
            trendMap.put(String.format("%02d", d), BigDecimal.ZERO);
        }
        for (Object[] r : trendRows) {
            LocalDate d;
            if (r[0] instanceof LocalDate) {
                d = (LocalDate) r[0];
            } else if (r[0] instanceof java.sql.Date) {
                d = ((java.sql.Date) r[0]).toLocalDate();
            } else {
                d = LocalDate.parse(r[0].toString());
            }
            BigDecimal amt = (BigDecimal) r[1];
            trendMap.put(String.format("%02d", d.getDayOfMonth()), amt);
        }

        List<Map<String, Object>> trendList = new ArrayList<>();
        trendMap.forEach((day, amt) -> {
            Map<String, Object> m = new HashMap<>();
            m.put("day", day);
            m.put("amount", amt);
            trendList.add(m);
        });

        AnalysisDto.MonthlyAnalysis monthly = new AnalysisDto.MonthlyAnalysis();
        monthly.setTotalIncome(income);
        monthly.setTotalExpenses(expense);
        monthly.setMonthlySavings(income.subtract(expense));
        monthly.setAverageDailyExpense(avgDaily);
        monthly.setHighestExpense(highest);
        monthly.setLowestExpense(lowest);
        monthly.setDailyTrend(trendList);

        return monthly;
    }

    public List<AnalysisDto.CategoryShare> getCategoryExpenses(User user, LocalDate start, LocalDate end) {
        if (start == null || end == null) {
            YearMonth ym = YearMonth.now();
            start = ym.atDay(1);
            end = ym.atEndOfMonth();
        }

        BigDecimal total = transactionRepository.sumAmountByUserIdAndTypeAndDateBetween(
                user.getId(), "EXPENSE", start, end);
        if (total == null || total.compareTo(BigDecimal.ZERO) == 0) {
            return Collections.emptyList();
        }

        List<Object[]> rows = transactionRepository.findCategoryExpensesBetween(user.getId(), start, end);
        List<AnalysisDto.CategoryShare> list = new ArrayList<>();

        for (Object[] r : rows) {
            Long catId = (Long) r[0];
            String name = (String) r[1];
            BigDecimal amt = (BigDecimal) r[2];
            String icon = (String) r[3];
            double pct = amt.divide(total, 4, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100)).doubleValue();
            list.add(new AnalysisDto.CategoryShare(catId, name, icon != null ? icon : "fa-tags", amt, Math.round(pct * 10.0) / 10.0));
        }

        return list;
    }
}
