package com.expensetracker.repository;

import com.expensetracker.model.BankTransaction;
import com.expensetracker.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BankTransactionRepository extends JpaRepository<BankTransaction, Long> {
    List<BankTransaction> findByUserIdOrderByTransactionDateDesc(Long userId);
    List<BankTransaction> findByUserIdAndStatusOrderByTransactionDateDesc(Long userId, String status);

    @Modifying
    @Query("UPDATE BankTransaction b SET b.category = :fallback WHERE b.category.id = :categoryId")
    void reassignCategory(@Param("categoryId") Long categoryId, @Param("fallback") Category fallback);
}
