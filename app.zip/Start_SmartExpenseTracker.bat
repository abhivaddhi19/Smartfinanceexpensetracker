@echo off
title Smart Expense Tracker
echo =====================================================================
echo  Starting Smart Expense Tracker and Personal Finance Management System
echo =====================================================================
echo.

:: Ensure Java is used from tools
set "JAVA_HOME=C:\Users\sniper\tools\jdk-17.0.12+7"
set "PATH=%JAVA_HOME%\bin;%PATH%"

echo Starting backend server from the bundled application file...
echo (This window will stay open to keep the server running)
echo.

:: Wait for a few seconds to let the server start, then launch the browser
start cmd /c "timeout /t 8 /nobreak >nul && start http://localhost:8080"

:: Run the fat JAR which includes everything
java -jar SmartExpenseTrackerApp.jar

pause
