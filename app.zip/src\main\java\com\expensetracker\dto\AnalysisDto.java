package com.expensetracker.dto;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public class AnalysisDto {

    public static class CategoryShare {
        private Long id;
        private String name;
        private String icon;
        private BigDecimal amount;
        private double percentage;

        public CategoryShare() {}
        public CategoryShare(Long id, String name, String icon, BigDecimal amount, double percentage) {
            this.id = id;
            this.name = name;
            this.icon = icon;
            this.amount = amount;
            this.percentage = percentage;
        }

        public CategoryShare(String name, String icon, BigDecimal amount, double percentage) {
            this(null, name, icon, amount, percentage);
        }

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getIcon() { return icon; }
        public void setIcon(String icon) { this.icon = icon; }
        public BigDecimal getAmount() { return amount; }
        public void setAmount(BigDecimal amount) { this.amount = amount; }
        public double getPercentage() { return percentage; }
        public void setPercentage(double percentage) { this.percentage = percentage; }
    }

    public static class DailyAnalysis {
        private BigDecimal todayTotal = BigDecimal.ZERO;
        private int transactionCount = 0;
        private BigDecimal highestExpense = BigDecimal.ZERO;
        private BigDecimal averageExpense = BigDecimal.ZERO;
        private List<Map<String, Object>> hourlyExpenses;

        public DailyAnalysis() {}

        public BigDecimal getTodayTotal() { return todayTotal; }
        public void setTodayTotal(BigDecimal todayTotal) { this.todayTotal = todayTotal; }
        public int getTransactionCount() { return transactionCount; }
        public void setTransactionCount(int transactionCount) { this.transactionCount = transactionCount; }
        public BigDecimal getHighestExpense() { return highestExpense; }
        public void setHighestExpense(BigDecimal highestExpense) { this.highestExpense = highestExpense; }
        public BigDecimal getAverageExpense() { return averageExpense; }
        public void setAverageExpense(BigDecimal averageExpense) { this.averageExpense = averageExpense; }
        public List<Map<String, Object>> getHourlyExpenses() { return hourlyExpenses; }
        public void setHourlyExpenses(List<Map<String, Object>> hourlyExpenses) { this.hourlyExpenses = hourlyExpenses; }
    }

    public static class WeeklyAnalysis {
        private Map<String, BigDecimal> daySpending; // Monday -> Sun
        private BigDecimal totalWeekly = BigDecimal.ZERO;
        private BigDecimal averageDaily = BigDecimal.ZERO;
        private String highestSpendingDay = "N/A";
        private BigDecimal highestSpendingAmount = BigDecimal.ZERO;
        private String lowestSpendingDay = "N/A";
        private BigDecimal lowestSpendingAmount = BigDecimal.ZERO;

        public WeeklyAnalysis() {}

        public Map<String, BigDecimal> getDaySpending() { return daySpending; }
        public void setDaySpending(Map<String, BigDecimal> daySpending) { this.daySpending = daySpending; }
        public BigDecimal getTotalWeekly() { return totalWeekly; }
        public void setTotalWeekly(BigDecimal totalWeekly) { this.totalWeekly = totalWeekly; }
        public BigDecimal getAverageDaily() { return averageDaily; }
        public void setAverageDaily(BigDecimal averageDaily) { this.averageDaily = averageDaily; }
        public String getHighestSpendingDay() { return highestSpendingDay; }
        public void setHighestSpendingDay(String highestSpendingDay) { this.highestSpendingDay = highestSpendingDay; }
        public BigDecimal getHighestSpendingAmount() { return highestSpendingAmount; }
        public void setHighestSpendingAmount(BigDecimal highestSpendingAmount) { this.highestSpendingAmount = highestSpendingAmount; }
        public String getLowestSpendingDay() { return lowestSpendingDay; }
        public void setLowestSpendingDay(String lowestSpendingDay) { this.lowestSpendingDay = lowestSpendingDay; }
        public BigDecimal getLowestSpendingAmount() { return lowestSpendingAmount; }
        public void setLowestSpendingAmount(BigDecimal lowestSpendingAmount) { this.lowestSpendingAmount = lowestSpendingAmount; }
    }

    public static class MonthlyAnalysis {
        private BigDecimal totalIncome = BigDecimal.ZERO;
        private BigDecimal totalExpenses = BigDecimal.ZERO;
        private BigDecimal monthlySavings = BigDecimal.ZERO;
        private BigDecimal averageDailyExpense = BigDecimal.ZERO;
        private BigDecimal highestExpense = BigDecimal.ZERO;
        private BigDecimal lowestExpense = BigDecimal.ZERO;
        private List<Map<String, Object>> dailyTrend;

        public MonthlyAnalysis() {}

        public BigDecimal getTotalIncome() { return totalIncome; }
        public void setTotalIncome(BigDecimal totalIncome) { this.totalIncome = totalIncome; }
        public BigDecimal getTotalExpenses() { return totalExpenses; }
        public void setTotalExpenses(BigDecimal totalExpenses) { this.totalExpenses = totalExpenses; }
        public BigDecimal getMonthlySavings() { return monthlySavings; }
        public void setMonthlySavings(BigDecimal monthlySavings) { this.monthlySavings = monthlySavings; }
        public BigDecimal getAverageDailyExpense() { return averageDailyExpense; }
        public void setAverageDailyExpense(BigDecimal averageDailyExpense) { this.averageDailyExpense = averageDailyExpense; }
        public BigDecimal getHighestExpense() { return highestExpense; }
        public void setHighestExpense(BigDecimal highestExpense) { this.highestExpense = highestExpense; }
        public BigDecimal getLowestExpense() { return lowestExpense; }
        public void setLowestExpense(BigDecimal lowestExpense) { this.lowestExpense = lowestExpense; }
        public List<Map<String, Object>> getDailyTrend() { return dailyTrend; }
        public void setDailyTrend(List<Map<String, Object>> dailyTrend) { this.dailyTrend = dailyTrend; }
    }
}
