package com.expensetracker.service;

import com.expensetracker.dto.BudgetDto;
import com.expensetracker.model.Budget;
import com.expensetracker.model.User;
import com.expensetracker.repository.BudgetRepository;
import com.expensetracker.repository.TransactionRepository;
import com.expensetracker.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.Objects;
import java.util.Optional;

@Service
public class BudgetService {

    @Autowired
    private BudgetRepository budgetRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AlertService alertService;

    public BudgetDto getBudgetDetails(User user, int month, int year) {
        Optional<Budget> budgetOpt = budgetRepository.findByUserIdAndMonthAndYear(user.getId(), month, year);

        YearMonth ym = YearMonth.of(year, month);
        LocalDate start = ym.atDay(1);
        LocalDate end = ym.atEndOfMonth();

        BigDecimal spent = transactionRepository.sumAmountByUserIdAndTypeAndDateBetween(
                user.getId(), "EXPENSE", start, end);
        if (spent == null) spent = BigDecimal.ZERO;

        BudgetDto dto = new BudgetDto();
        dto.setMonth(month);
        dto.setYear(year);
        dto.setSpent(spent);

        String currency = (user.getCurrency() != null && !user.getCurrency().isEmpty()) ? user.getCurrency() : "₹";

        if (budgetOpt.isPresent()) {
            Budget budget = budgetOpt.get();
            dto.setId(budget.getId());
            BigDecimal amount = budget.getAmount();
            dto.setAmount(amount);

            BigDecimal remaining = amount.subtract(spent);
            dto.setRemaining(remaining);

            double usage = 0.0;
            if (amount.compareTo(BigDecimal.ZERO) > 0) {
                usage = spent.divide(amount, 4, RoundingMode.HALF_UP)
                        .multiply(BigDecimal.valueOf(100)).doubleValue();
            }
            dto.setUsagePercentage(Math.round(usage * 10.0) / 10.0);

            // Determine status & alert message
            if (usage > 100.0) {
                dto.setStatus("EXCEEDED_OVER");
                BigDecimal overAmount = spent.subtract(amount);
                dto.setAlertMessage("You have exceeded your monthly budget by " + currency + overAmount);
            } else if (usage >= 100.0) {
                dto.setStatus("EXCEEDED");
                dto.setAlertMessage("Your monthly budget has been exceeded.");
            } else if (usage >= 85.0) {
                dto.setStatus("WARNING_85");
                dto.setAlertMessage("Warning: You have used " + Math.round(usage) + "% of your monthly budget.");
            } else if (usage >= 70.0) {
                dto.setStatus("WARNING_70");
                dto.setAlertMessage(Math.round(usage) + "% of your monthly budget has been used.");
            } else {
                dto.setStatus("HEALTHY");
                dto.setAlertMessage("Your spending is well within budget.");
            }
        } else {
            dto.setAmount(BigDecimal.ZERO);
            dto.setRemaining(BigDecimal.ZERO.subtract(spent));
            dto.setUsagePercentage(0.0);
            dto.setStatus("NOT_SET");
            dto.setAlertMessage("No budget set for this month.");
        }

        return dto;
    }

    @Transactional
    public BudgetDto setBudget(User user, int month, int year, BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Budget amount must be greater than 0");
        }

        User managedUser = userRepository.findById(Objects.requireNonNull(user.getId())).orElse(user);

        Budget budget = budgetRepository.findByUserIdAndMonthAndYear(user.getId(), month, year)
                .orElseGet(() -> new Budget(managedUser, month, year, amount));

        budget.setAmount(amount);
        budgetRepository.save(budget);

        BudgetDto details = getBudgetDetails(managedUser, month, year);
        checkAndTriggerBudgetAlert(managedUser, details);
        return details;
    }

    public void checkAndTriggerBudgetAlert(User user, BudgetDto details) {
        if (details == null || details.getAmount().compareTo(BigDecimal.ZERO) <= 0) return;

        double usage = details.getUsagePercentage();
        String currency = (user.getCurrency() != null && !user.getCurrency().isEmpty()) ? user.getCurrency() : "₹";

        if (usage > 100.0) {
            BigDecimal over = details.getSpent().subtract(details.getAmount());
            alertService.createAlert(user,
                    "Monthly Budget Exceeded!",
                    "You have exceeded your monthly budget by " + currency + over + ". Current spending: " + currency + details.getSpent(),
                    "BUDGET");
        } else if (usage >= 85.0) {
            alertService.createAlert(user,
                    "Budget Alert (85%+ Used)",
                    "Warning: You have used " + Math.round(usage) + "% of your monthly budget (" + currency + details.getSpent() + " of " + currency + details.getAmount() + ").",
                    "BUDGET");
        } else if (usage >= 70.0) {
            alertService.createAlert(user,
                    "Budget Notice (70% Used)",
                    Math.round(usage) + "% of your monthly budget has been used. Remaining: " + currency + details.getRemaining() + ".",
                    "BUDGET");
        }
    }
}
