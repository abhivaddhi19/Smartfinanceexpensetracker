$s = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$rand = Get-Random -Minimum 1000 -Maximum 9999
$email = "testuser$rand@example.com"
$regBody = @{
    name = "Test User $rand"
    email = $email
    password = "Password123"
    confirmPassword = "Password123"
    mobile = "9876543210"
} | ConvertTo-Json

# Register
$regRes = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/register" -Method Post -ContentType "application/json" -Body $regBody -WebSession $s
Write-Host "[PASS] User Register: $($regRes.message)" -ForegroundColor Green

# Login
$loginBody = @{
    email = $email
    password = "Password123"
} | ConvertTo-Json
$loginRes = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/login" -Method Post -ContentType "application/json" -Body $loginBody -WebSession $s
Write-Host "[PASS] User Login: $($loginRes.message)" -ForegroundColor Green

# Check Current User
$curUser = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/current-user" -Method Get -WebSession $s
Write-Host "[PASS] Current User: $($curUser.name) ($($curUser.email))" -ForegroundColor Green

# Check Categories (should have default categories)
$cats = Invoke-RestMethod -Uri "http://localhost:8080/api/categories" -Method Get -WebSession $s
Write-Host "[PASS] Categories Count for new user: $($cats.Count)" -ForegroundColor Green

# Check Dashboard Summary
$summary = Invoke-RestMethod -Uri "http://localhost:8080/api/dashboard/summary" -Method Get -WebSession $s
Write-Host "[PASS] Dashboard Total Balance: $($summary.currentBalance)" -ForegroundColor Green

# Add an Income Transaction
$inTx = @{
    amount = 50000
    type = "INCOME"
    description = "First Salary"
    transactionDate = "2026-09-01"
    paymentMethod = "BANK_TRANSFER"
} | ConvertTo-Json
$inRes = Invoke-RestMethod -Uri "http://localhost:8080/api/transactions" -Method Post -ContentType "application/json" -Body $inTx -WebSession $s
Write-Host "[PASS] Created Income Tx (ID: $($inRes.id))" -ForegroundColor Green

# Add an Expense Transaction
$foodCat = ($cats | Where-Object { $_.name -eq "Food" })[0]
$exTx = @{
    amount = 1200
    type = "EXPENSE"
    categoryId = $foodCat.id
    description = "Groceries & Dinner"
    transactionDate = "2026-09-05"
    paymentMethod = "UPI"
} | ConvertTo-Json
$exRes = Invoke-RestMethod -Uri "http://localhost:8080/api/transactions" -Method Post -ContentType "application/json" -Body $exTx -WebSession $s
Write-Host "[PASS] Created Expense Tx (ID: $($exRes.id))" -ForegroundColor Green

# Set Budget
$budgetBody = @{
    month = 9
    year = 2026
    amount = 20000
} | ConvertTo-Json
$bRes = Invoke-RestMethod -Uri "http://localhost:8080/api/budget" -Method Post -ContentType "application/json" -Body $budgetBody -WebSession $s
Write-Host "[PASS] Set Budget: $($bRes.amount), Remaining: $($bRes.remaining), Usage: $($bRes.usagePercentage)%" -ForegroundColor Green

# Check Monthly Analysis
$analysis = Invoke-RestMethod -Uri "http://localhost:8080/api/analysis/monthly?month=9&year=2026" -Method Get -WebSession $s
Write-Host "[PASS] Monthly Analysis Total Income: $($analysis.totalIncome), Total Expense: $($analysis.totalExpense)" -ForegroundColor Green

# Generate PDF Report
$pdf = Invoke-WebRequest -Uri "http://localhost:8080/api/reports/monthly/pdf?month=9&year=2026" -Method Get -WebSession $s
Write-Host "[PASS] PDF Report downloaded, status: $($pdf.StatusCode), length: $($pdf.RawContentLength) bytes" -ForegroundColor Green
