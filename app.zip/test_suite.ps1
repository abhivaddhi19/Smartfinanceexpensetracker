$s = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$loginBody = '{"email":"demo@expensetracker.com","password":"Password123"}'
$login = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/login" -Method Post -ContentType "application/json" -Body $loginBody -WebSession $s
Write-Host "Login: $($login.message)" -ForegroundColor Cyan

$tests = @(
    @{ Name="Current User"; Url="http://localhost:8080/api/auth/current-user"; Method="Get" },
    @{ Name="Dashboard Summary"; Url="http://localhost:8080/api/dashboard/summary?month=9&year=2026"; Method="Get" },
    @{ Name="Recent Transactions"; Url="http://localhost:8080/api/dashboard/recent-transactions"; Method="Get" },
    @{ Name="List Transactions"; Url="http://localhost:8080/api/transactions"; Method="Get" },
    @{ Name="List Categories"; Url="http://localhost:8080/api/categories"; Method="Get" },
    @{ Name="Get Budget"; Url="http://localhost:8080/api/budget?month=9&year=2026"; Method="Get" },
    @{ Name="Daily Analysis"; Url="http://localhost:8080/api/analysis/daily"; Method="Get" },
    @{ Name="Weekly Analysis"; Url="http://localhost:8080/api/analysis/weekly"; Method="Get" },
    @{ Name="Monthly Analysis"; Url="http://localhost:8080/api/analysis/monthly?month=9&year=2026"; Method="Get" },
    @{ Name="Categories Analysis"; Url="http://localhost:8080/api/analysis/categories"; Method="Get" },
    @{ Name="Alerts"; Url="http://localhost:8080/api/alerts"; Method="Get" },
    @{ Name="Alerts Unread Count"; Url="http://localhost:8080/api/alerts/unread-count"; Method="Get" },
    @{ Name="Suggestions"; Url="http://localhost:8080/api/suggestions"; Method="Get" },
    @{ Name="Pending Bank Tx"; Url="http://localhost:8080/api/bank/pending"; Method="Get" },
    @{ Name="Monthly Report"; Url="http://localhost:8080/api/reports/monthly?month=9&year=2026"; Method="Get" },
    @{ Name="Category Report"; Url="http://localhost:8080/api/reports/category?categoryId=1&month=9&year=2026"; Method="Get" },
    @{ Name="Monthly PDF Report"; Url="http://localhost:8080/api/reports/monthly/pdf?month=9&year=2026"; Method="Get" },
    @{ Name="Profile"; Url="http://localhost:8080/api/profile"; Method="Get" }
)

foreach ($t in $tests) {
    try {
        $res = Invoke-RestMethod -Uri $t.Url -Method $t.Method -WebSession $s
        Write-Host "[PASS] $($t.Name)" -ForegroundColor Green
    } catch {
        Write-Host "[FAIL] $($t.Name): $($_.Exception.Message)" -ForegroundColor Red
    }
}
