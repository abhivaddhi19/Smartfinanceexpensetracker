package com.expensetracker.controller;

import com.expensetracker.dto.AuthRequest;
import com.expensetracker.dto.AuthResponse;
import com.expensetracker.model.User;
import com.expensetracker.repository.UserRepository;
import com.expensetracker.security.SecurityUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private SecurityUtil securityUtil;

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody AuthRequest request) {
        if (request.getName() == null || request.getName().trim().isEmpty()) {
            return ResponseEntity.badRequest().body(AuthResponse.error("Full Name is required."));
        }

        if (userRepository.existsByEmail(request.getEmail().trim().toLowerCase())) {
            return ResponseEntity.badRequest().body(AuthResponse.error("An account with this email already exists."));
        }

        if (request.getConfirmPassword() != null && !request.getPassword().equals(request.getConfirmPassword())) {
            return ResponseEntity.badRequest().body(AuthResponse.error("Passwords do not match."));
        }

        User user = new User();
        user.setName(request.getName().trim());
        user.setEmail(request.getEmail().trim().toLowerCase());
        user.setMobile(request.getMobile() != null ? request.getMobile().trim() : null);
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setCurrency("₹");

        User saved = userRepository.save(user);

        return ResponseEntity.ok(AuthResponse.success(
                "Registration successful! You can now log in.",
                saved.getId(), saved.getName(), saved.getEmail(), saved.getCurrency()
        ));
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest request, HttpServletRequest httpRequest, HttpServletResponse httpResponse) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getEmail().trim().toLowerCase(), request.getPassword())
            );

            SecurityContext context = SecurityContextHolder.createEmptyContext();
            context.setAuthentication(authentication);
            SecurityContextHolder.setContext(context);

            HttpSession session = httpRequest.getSession(true);
            session.setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, context);

            User user = userRepository.findByEmail(request.getEmail().trim().toLowerCase()).orElseThrow();

            return ResponseEntity.ok(AuthResponse.success(
                    "Login successful!",
                    user.getId(), user.getName(), user.getEmail(), user.getCurrency()
            ));

        } catch (BadCredentialsException e) {
            return ResponseEntity.status(401).body(AuthResponse.error("Incorrect email or password."));
        } catch (Exception e) {
            return ResponseEntity.status(500).body(AuthResponse.error("Login failed: " + e.getMessage()));
        }
    }

    @GetMapping("/current-user")
    public ResponseEntity<AuthResponse> getCurrentUser() {
        Optional<User> userOpt = securityUtil.getCurrentUser();
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            return ResponseEntity.ok(AuthResponse.success(
                    "User active", user.getId(), user.getName(), user.getEmail(), user.getCurrency()
            ));
        }
        return ResponseEntity.status(401).body(AuthResponse.error("No active session"));
    }

    @PostMapping("/logout")
    public ResponseEntity<AuthResponse> logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        SecurityContextHolder.clearContext();
        return ResponseEntity.ok(AuthResponse.success("Logged out successfully", null, null, null, null));
    }
}
