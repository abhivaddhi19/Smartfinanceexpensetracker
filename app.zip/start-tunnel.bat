@echo off
echo Starting Smart Expense Tracker Public Tunnel...
powershell -ExecutionPolicy Bypass -File "%~dp0start-tunnel.ps1"
pause
