package com.expensetracker.controller;

import com.expensetracker.dto.BudgetDto;
import com.expensetracker.model.User;
import com.expensetracker.security.SecurityUtil;
import com.expensetracker.service.BudgetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api/budget")
public class BudgetController {

    @Autowired
    private BudgetService budgetService;

    @Autowired
    private SecurityUtil securityUtil;

    @GetMapping
    public ResponseEntity<BudgetDto> getBudget(
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year) {

        User user = securityUtil.getRequiredCurrentUser();
        LocalDate now = LocalDate.now();
        int m = month != null ? month : now.getMonthValue();
        int y = year != null ? year : now.getYear();

        BudgetDto dto = budgetService.getBudgetDetails(user, m, y);
        return ResponseEntity.ok(dto);
    }

    @PostMapping
    public ResponseEntity<BudgetDto> setBudget(@RequestBody Map<String, Object> payload) {
        User user = securityUtil.getRequiredCurrentUser();
        LocalDate now = LocalDate.now();

        int month = now.getMonthValue();
        if (payload.get("month") != null && !payload.get("month").toString().trim().isEmpty()) {
            month = Integer.parseInt(payload.get("month").toString().trim());
        }
        int year = now.getYear();
        if (payload.get("year") != null && !payload.get("year").toString().trim().isEmpty()) {
            year = Integer.parseInt(payload.get("year").toString().trim());
        }
        if (payload.get("amount") == null || payload.get("amount").toString().trim().isEmpty()) {
            throw new IllegalArgumentException("Budget amount is required and must be greater than 0");
        }
        BigDecimal amount = new BigDecimal(payload.get("amount").toString().trim());

        BudgetDto saved = budgetService.setBudget(user, month, year, amount);
        return ResponseEntity.ok(saved);
    }
}
