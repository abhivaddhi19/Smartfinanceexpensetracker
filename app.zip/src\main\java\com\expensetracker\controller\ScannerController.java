package com.expensetracker.controller;

import com.expensetracker.dto.ReceiptScanResultDto;
import com.expensetracker.model.User;
import com.expensetracker.security.SecurityUtil;
import com.expensetracker.service.ScannerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/scanner")
public class ScannerController {

    @Autowired
    private ScannerService scannerService;

    @Autowired
    private SecurityUtil securityUtil;

    @PostMapping("/receipt")
    public ResponseEntity<ReceiptScanResultDto> scanReceipt(@RequestParam("file") MultipartFile file) {
        User user = securityUtil.getRequiredCurrentUser();
        ReceiptScanResultDto result = scannerService.scanReceipt(file, user);
        return ResponseEntity.ok(result);
    }
}
