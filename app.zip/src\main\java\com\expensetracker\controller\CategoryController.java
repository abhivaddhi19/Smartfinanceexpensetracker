package com.expensetracker.controller;

import com.expensetracker.model.Category;
import com.expensetracker.model.User;
import com.expensetracker.security.SecurityUtil;
import com.expensetracker.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private SecurityUtil securityUtil;

    @GetMapping
    public ResponseEntity<List<Map<String, Object>>> getCategories() {
        User user = securityUtil.getRequiredCurrentUser();
        List<Category> list = categoryService.getAllCategoriesForUser(user.getId());
        Map<Long, Map<String, Object>> stats = categoryService.getCategoryStats(user.getId());

        List<Map<String, Object>> dtos = list.stream().map(c -> {
            Map<String, Object> map = new HashMap<>();
            map.put("id", c.getId());
            map.put("name", c.getName());
            map.put("icon", c.getIcon());
            map.put("description", c.getDescription());
            map.put("isCustom", c.getUser() != null);
            Map<String, Object> s = stats.get(c.getId());
            map.put("transactionCount", s != null ? s.get("count") : 0);
            map.put("totalSpent", s != null ? s.get("total") : 0);
            return map;
        }).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> createCategory(@RequestBody Map<String, String> payload) {
        User user = securityUtil.getRequiredCurrentUser();
        String name = payload.get("name");
        String icon = payload.get("icon");
        String description = payload.get("description");

        Category created = categoryService.createCustomCategory(user, name, icon, description);

        Map<String, Object> res = new HashMap<>();
        res.put("id", created.getId());
        res.put("name", created.getName());
        res.put("icon", created.getIcon());
        res.put("description", created.getDescription());
        res.put("isCustom", true);

        return ResponseEntity.ok(res);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> updateCategory(
            @PathVariable Long id,
            @RequestBody Map<String, String> payload) {

        User user = securityUtil.getRequiredCurrentUser();
        String name = payload.get("name");
        String icon = payload.get("icon");
        String description = payload.get("description");

        Category updated = categoryService.updateCustomCategory(user, id, name, icon, description);

        Map<String, Object> res = new HashMap<>();
        res.put("id", updated.getId());
        res.put("name", updated.getName());
        res.put("icon", updated.getIcon());
        res.put("description", updated.getDescription());
        res.put("isCustom", true);

        return ResponseEntity.ok(res);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCategory(@PathVariable Long id) {
        User user = securityUtil.getRequiredCurrentUser();
        categoryService.deleteCustomCategory(user, id);
        return ResponseEntity.noContent().build();
    }
}
