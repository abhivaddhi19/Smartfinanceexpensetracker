package com.expensetracker.service;

import com.expensetracker.model.Category;
import com.expensetracker.model.User;
import com.expensetracker.repository.BankTransactionRepository;
import com.expensetracker.repository.CategoryRepository;
import com.expensetracker.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private BankTransactionRepository bankTransactionRepository;

    public List<Category> getAllCategoriesForUser(Long userId) {
        return categoryRepository.findAllForUser(userId);
    }

    public Map<Long, Map<String, Object>> getCategoryStats(Long userId) {
        List<Object[]> rows = transactionRepository.findCategoryStatsForUser(userId);
        Map<Long, Map<String, Object>> stats = new HashMap<>();
        for (Object[] r : rows) {
            Long catId = (Long) r[0];
            Long count = (Long) r[1];
            BigDecimal total = (BigDecimal) r[2];
            Map<String, Object> s = new HashMap<>();
            s.put("count", count);
            s.put("total", total);
            stats.put(catId, s);
        }
        return stats;
    }

    public Optional<Category> getCategoryById(Long id) {
        return categoryRepository.findById(Objects.requireNonNull(id));
    }

    public Category createCustomCategory(User user, String name, String icon, String description) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Category name cannot be empty");
        }
        Optional<Category> existing = categoryRepository.findByNameIgnoreCaseAndUserId(name.trim(), user.getId());
        if (existing.isPresent()) {
            throw new IllegalArgumentException("Category with name '" + name + "' already exists");
        }
        Category category = new Category(name.trim(), icon != null && !icon.trim().isEmpty() ? icon : "fa-tag", description, user);
        return categoryRepository.save(category);
    }

    public Category updateCustomCategory(User user, Long categoryId, String name, String icon, String description) {
        Category category = categoryRepository.findById(Objects.requireNonNull(categoryId))
                .orElseThrow(() -> new IllegalArgumentException("Category not found"));

        if (category.getUser() == null || !category.getUser().getId().equals(user.getId())) {
            throw new IllegalArgumentException("Default system categories cannot be modified");
        }

        category.setName(name.trim());
        if (icon != null && !icon.trim().isEmpty()) {
            category.setIcon(icon.trim());
        }
        category.setDescription(description);
        return categoryRepository.save(category);
    }

    @Transactional
    public void deleteCustomCategory(User user, Long categoryId) {
        Category category = categoryRepository.findById(Objects.requireNonNull(categoryId))
                .orElseThrow(() -> new IllegalArgumentException("Category not found"));

        if (category.getUser() == null || !category.getUser().getId().equals(user.getId())) {
            throw new IllegalArgumentException("Default system categories cannot be deleted");
        }

        Category fallback = categoryRepository.findByNameIgnoreCaseForUser("Other", user.getId()).orElse(null);
        transactionRepository.reassignCategory(categoryId, fallback);
        bankTransactionRepository.reassignCategory(categoryId, fallback);

        categoryRepository.delete(category);
    }

    public Category findOrCreateCategory(String name, String icon, User user) {
        return categoryRepository.findByNameIgnoreCaseForUser(name, user.getId())
                .orElseGet(() -> categoryRepository.save(new Category(name, icon, "Auto-created", user)));
    }
}
