package com.expensetracker.service;

import com.expensetracker.dto.BudgetDto;
import com.expensetracker.dto.DashboardSummaryDto;
import com.expensetracker.model.User;
import com.expensetracker.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;

@Service
public class DashboardService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private BudgetService budgetService;

    public DashboardSummaryDto getSummary(User user, int month, int year) {
        YearMonth ym = YearMonth.of(year, month);
        LocalDate startOfMonth = ym.atDay(1);
        LocalDate endOfMonth = ym.atEndOfMonth();

        // All-time Totals
        BigDecimal totalIncome = transactionRepository.sumAmountByUserIdAndType(user.getId(), "INCOME");
        if (totalIncome == null) totalIncome = BigDecimal.ZERO;

        BigDecimal totalExpenses = transactionRepository.sumAmountByUserIdAndType(user.getId(), "EXPENSE");
        if (totalExpenses == null) totalExpenses = BigDecimal.ZERO;

        BigDecimal currentBalance = totalIncome.subtract(totalExpenses);

        // Monthly Totals
        BigDecimal monthlyIncome = transactionRepository.sumAmountByUserIdAndTypeAndDateBetween(
                user.getId(), "INCOME", startOfMonth, endOfMonth);
        if (monthlyIncome == null) monthlyIncome = BigDecimal.ZERO;

        BigDecimal monthlyExpenses = transactionRepository.sumAmountByUserIdAndTypeAndDateBetween(
                user.getId(), "EXPENSE", startOfMonth, endOfMonth);
        if (monthlyExpenses == null) monthlyExpenses = BigDecimal.ZERO;

        BigDecimal monthlySavings = monthlyIncome.subtract(monthlyExpenses);

        // Budget Calculations
        BudgetDto budgetDto = budgetService.getBudgetDetails(user, month, year);

        DashboardSummaryDto summary = new DashboardSummaryDto();
        summary.setTotalIncome(totalIncome);
        summary.setTotalExpenses(totalExpenses);
        summary.setCurrentBalance(currentBalance);
        summary.setMonthlyIncome(monthlyIncome);
        summary.setMonthlyExpenses(monthlyExpenses);
        summary.setMonthlySavings(monthlySavings);
        summary.setMonthlyBudget(budgetDto.getAmount());
        summary.setRemainingBudget(budgetDto.getRemaining());
        summary.setBudgetUsagePercentage(budgetDto.getUsagePercentage());
        summary.setCurrency(user.getCurrency() != null ? user.getCurrency() : "₹");
        summary.setTransactionCount(transactionRepository.findByUserIdOrderByTransactionDateDescCreatedAtDesc(user.getId()).size());

        return summary;
    }
}
