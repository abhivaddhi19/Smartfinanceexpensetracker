package com.expensetracker.service;

import com.expensetracker.dto.BankImportItemDto;
import com.expensetracker.dto.TransactionDto;
import com.expensetracker.model.BankTransaction;
import com.expensetracker.model.User;
import com.expensetracker.repository.BankTransactionRepository;
import com.expensetracker.repository.CategoryRepository;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class BankStatementService {

    @Autowired
    private BankTransactionRepository bankTransactionRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private TransactionService transactionService;

    public List<BankImportItemDto> parseAndStageStatement(MultipartFile file, User user) throws Exception {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Please upload a valid CSV or PDF bank statement file.");
        }

        String rawFilename = file.getOriginalFilename();
        String filename = rawFilename != null ? rawFilename.toLowerCase() : "";
        List<BankTransaction> stagedList;

        if (filename.endsWith(".csv") || filename.endsWith(".txt")) {
            stagedList = parseCsv(file, user);
        } else if (filename.endsWith(".pdf")) {
            stagedList = parsePdf(file, user);
        } else {
            throw new IllegalArgumentException("Unsupported file type. Please upload a CSV or PDF file.");
        }

        List<BankTransaction> saved = bankTransactionRepository.saveAll(Objects.requireNonNull(stagedList));
        return saved.stream().map(this::toDto).collect(Collectors.toList());
    }

    public List<BankImportItemDto> getPendingTransactions(User user) {
        return bankTransactionRepository.findByUserIdAndStatusOrderByTransactionDateDesc(user.getId(), "PENDING")
                .stream().map(this::toDto).collect(Collectors.toList());
    }

    @Transactional
    public int clearPendingTransactions(User user) {
        List<BankTransaction> pending = bankTransactionRepository.findByUserIdAndStatusOrderByTransactionDateDesc(user.getId(), "PENDING");
        bankTransactionRepository.deleteAll(pending);
        return pending.size();
    }

    @Transactional
    public int confirmTransactions(User user, List<BankImportItemDto> items) {
        int confirmedCount = 0;

        for (BankImportItemDto item : items) {
            if (item.getId() == null) continue;

            Optional<BankTransaction> bankTxOpt = bankTransactionRepository.findById(Objects.requireNonNull(item.getId()));
            if (bankTxOpt.isPresent()) {
                BankTransaction bankTx = bankTxOpt.get();
                if (!bankTx.getUser().getId().equals(user.getId())) continue;

                // Create official transaction
                TransactionDto txDto = new TransactionDto();
                txDto.setTransactionDate(bankTx.getTransactionDate());
                txDto.setDescription(bankTx.getDescription());
                txDto.setPaymentMethod("BANK_TRANSFER");

                if (item.getCategoryId() != null) {
                    txDto.setCategoryId(item.getCategoryId());
                } else if (bankTx.getCategory() != null) {
                    txDto.setCategoryId(bankTx.getCategory().getId());
                }

                if (bankTx.getDebit() != null && bankTx.getDebit().compareTo(BigDecimal.ZERO) > 0) {
                    txDto.setType("EXPENSE");
                    txDto.setAmount(bankTx.getDebit());
                } else {
                    txDto.setType("INCOME");
                    txDto.setAmount(bankTx.getCredit());
                }

                transactionService.createTransaction(user, txDto);

                bankTx.setStatus("CONFIRMED");
                if (item.getCategoryId() != null) {
                    categoryRepository.findById(Objects.requireNonNull(item.getCategoryId())).ifPresent(bankTx::setCategory);
                }
                bankTransactionRepository.save(bankTx);
                confirmedCount++;
            }
        }
        return confirmedCount;
    }

    private List<BankTransaction> parseCsv(MultipartFile file, User user) throws Exception {
        List<BankTransaction> list = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8));
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).setIgnoreHeaderCase(true).setTrim(true).build())) {

            for (CSVRecord record : csvParser) {
                try {
                    String dateStr = getField(record, "Date", "Txn Date", "Transaction Date", "Value Date");
                    String desc = getField(record, "Description", "Narration", "Remarks", "Details");
                    String debitStr = getField(record, "Debit", "Withdrawal", "Debit Amount", "DR");
                    String creditStr = getField(record, "Credit", "Deposit", "Credit Amount", "CR");
                    String balanceStr = getField(record, "Balance", "Closing Balance", "Bal");

                    if (dateStr == null || desc == null) continue;

                    LocalDate date = parseDate(dateStr);
                    BigDecimal debit = parseAmount(debitStr);
                    BigDecimal credit = parseAmount(creditStr);
                    BigDecimal balance = parseAmount(balanceStr);

                    if (debit.compareTo(BigDecimal.ZERO) == 0 && credit.compareTo(BigDecimal.ZERO) == 0) continue;

                    BankTransaction tx = new BankTransaction();
                    tx.setUser(user);
                    tx.setTransactionDate(date);
                    tx.setDescription(desc);
                    tx.setDebit(debit);
                    tx.setCredit(credit);
                    tx.setBalance(balance);
                    tx.setStatus("PENDING");

                    // Auto-classify category
                    String catName = classifyDescription(desc, credit.compareTo(BigDecimal.ZERO) > 0);
                    categoryRepository.findByNameIgnoreCaseForUser(catName, user.getId()).ifPresent(tx::setCategory);

                    list.add(tx);
                } catch (Exception e) {
                    // skip malformed row
                }
            }
        }
        return list;
    }

    private List<BankTransaction> parsePdf(MultipartFile file, User user) throws Exception {
        List<BankTransaction> list = new ArrayList<>();
        try (PDDocument document = PDDocument.load(file.getInputStream())) {
            PDFTextStripper stripper = new PDFTextStripper();
            String text = stripper.getText(document);
            String[] lines = text.split("\\r?\\n");

            Pattern datePattern = Pattern.compile("(\\d{2}[-/.]\\d{2}[-/.]\\d{4})");
            Pattern amountPattern = Pattern.compile("([\\d,]+\\.\\d{2})");

            for (String line : lines) {
                line = line.trim();
                Matcher dateMatcher = datePattern.matcher(line);
                if (dateMatcher.find()) {
                    String dateStr = dateMatcher.group(1);
                    LocalDate date = parseDate(dateStr);

                    Matcher amtMatcher = amountPattern.matcher(line);
                    List<String> foundAmounts = new ArrayList<>();
                    while (amtMatcher.find()) {
                        foundAmounts.add(amtMatcher.group(1));
                    }

                    if (!foundAmounts.isEmpty()) {
                        BigDecimal amt = parseAmount(foundAmounts.get(0));
                        boolean isCredit = line.toUpperCase().contains(" CR ") || line.toUpperCase().contains("CREDIT") || line.toUpperCase().contains("SALARY");

                        BankTransaction tx = new BankTransaction();
                        tx.setUser(user);
                        tx.setTransactionDate(date);
                        tx.setDescription(line.replaceAll("[\\d,]+\\.\\d{2}", "").replaceAll("(\\d{2}[-/.]\\d{2}[-/.]\\d{4})", "").trim());
                        if (tx.getDescription().isEmpty()) tx.setDescription("Bank Statement Record");

                        if (isCredit) {
                            tx.setCredit(amt);
                            tx.setDebit(BigDecimal.ZERO);
                        } else {
                            tx.setDebit(amt);
                            tx.setCredit(BigDecimal.ZERO);
                        }

                        if (foundAmounts.size() > 1) {
                            tx.setBalance(parseAmount(foundAmounts.get(foundAmounts.size() - 1)));
                        }

                        tx.setStatus("PENDING");
                        String catName = classifyDescription(tx.getDescription(), isCredit);
                        categoryRepository.findByNameIgnoreCaseForUser(catName, user.getId()).ifPresent(tx::setCategory);
                        list.add(tx);
                    }
                }
            }
        }
        return list;
    }

    private String getField(CSVRecord record, String... possibleHeaders) {
        for (String header : possibleHeaders) {
            if (record.isMapped(header) && record.get(header) != null && !record.get(header).trim().isEmpty()) {
                return record.get(header).trim();
            }
        }
        return null;
    }

    private LocalDate parseDate(String dateStr) {
        String[] patterns = {"dd-MM-yyyy", "dd/MM/yyyy", "yyyy-MM-dd", "d-M-yyyy", "d/M/yyyy"};
        for (String pat : patterns) {
            try {
                return LocalDate.parse(dateStr, DateTimeFormatter.ofPattern(pat));
            } catch (DateTimeParseException ignored) {}
        }
        return LocalDate.now();
    }

    private BigDecimal parseAmount(String str) {
        if (str == null || str.trim().isEmpty()) return BigDecimal.ZERO;
        String clean = str.replaceAll("[^0-9.]", "");
        try {
            return new BigDecimal(clean);
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    public String classifyDescription(String description, boolean isCredit) {
        if (isCredit) return "Salary";

        String desc = description.toUpperCase();
        if (desc.contains("SWIGGY") || desc.contains("ZOMATO") || desc.contains("FOOD") || desc.contains("CAFE") || desc.contains("RESTAURANT")) {
            return "Food";
        }
        if (desc.contains("DMART") || desc.contains("BIGBASKET") || desc.contains("GROCERY") || desc.contains("BLINKIT") || desc.contains("ZEPTO")) {
            return "Grocery";
        }
        if (desc.contains("AMAZON") || desc.contains("FLIPKART") || desc.contains("MYNTRA") || desc.contains("SHOPPING")) {
            return "Shopping";
        }
        if (desc.contains("UBER") || desc.contains("OLA") || desc.contains("RAPIDO") || desc.contains("IRCTC") || desc.contains("METRO")) {
            return "Travel";
        }
        if (desc.contains("BESCOM") || desc.contains("ELECTRICITY") || desc.contains("POWER")) {
            return "Electricity";
        }
        if (desc.contains("AIRTEL") || desc.contains("JIO") || desc.contains("VODAFONE") || desc.contains("RECHARGE")) {
            return "Mobile";
        }
        if (desc.contains("ACT") || desc.contains("BROADBAND") || desc.contains("WIFI")) {
            return "Internet";
        }
        if (desc.contains("NETFLIX") || desc.contains("SPOTIFY") || desc.contains("PRIME") || desc.contains("CINEMA")) {
            return "Entertainment";
        }
        if (desc.contains("APOLLO") || desc.contains("PHARMACY") || desc.contains("HOSPITAL") || desc.contains("MEDICINE")) {
            return "Healthcare";
        }
        if (desc.contains("PETROL") || desc.contains("SHELL") || desc.contains("FUEL") || desc.contains("BPCL")) {
            return "Fuel";
        }
        if (desc.contains("RENT") || desc.contains("FLAT") || desc.contains("APARTMENT")) {
            return "Rent";
        }
        return "Bills";
    }

    private BankImportItemDto toDto(BankTransaction tx) {
        BankImportItemDto dto = new BankImportItemDto();
        dto.setId(tx.getId());
        dto.setTransactionDate(tx.getTransactionDate());
        dto.setDescription(tx.getDescription());
        dto.setDebit(tx.getDebit());
        dto.setCredit(tx.getCredit());
        dto.setBalance(tx.getBalance());
        dto.setStatus(tx.getStatus());

        if (tx.getDebit() != null && tx.getDebit().compareTo(BigDecimal.ZERO) > 0) {
            dto.setType("EXPENSE");
            dto.setAmount(tx.getDebit());
        } else {
            dto.setType("INCOME");
            dto.setAmount(tx.getCredit());
        }

        if (tx.getCategory() != null) {
            dto.setCategoryId(tx.getCategory().getId());
            dto.setSuggestedCategory(tx.getCategory().getName());
        } else {
            dto.setSuggestedCategory("Other");
        }

        return dto;
    }
}
