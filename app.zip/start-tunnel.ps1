
# Smart Expense Tracker - Public Tunnel Script
# Keeps tunnel alive by auto-restarting on disconnect

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Smart Expense Tracker - Public Tunnel" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Starting tunnel... (keep this window open)" -ForegroundColor Yellow
Write-Host "Press CTRL+C to stop." -ForegroundColor Yellow
Write-Host ""

while ($true) {
    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Connecting tunnel..." -ForegroundColor Green
    
    $proc = Start-Process -FilePath "ssh" `
        -ArgumentList "-o StrictHostKeyChecking=no -o ServerAliveInterval=30 -o ServerAliveCountMax=10 -T -R 80:localhost:8080 nokey@localhost.run" `
        -NoNewWindow -PassThru -RedirectStandardOutput "$env:TEMP\tunnel.log" -RedirectStandardError "$env:TEMP\tunnel_err.log"
    
    # Wait a moment then show the URL
    Start-Sleep -Seconds 8
    $log = Get-Content "$env:TEMP\tunnel_err.log" -ErrorAction SilentlyContinue
    $url = $log | Select-String -Pattern "https://\S+\.lhr\.life" | ForEach-Object { $_.Matches[0].Value } | Select-Object -First 1
    if ($url) {
        Write-Host ""
        Write-Host "============================================" -ForegroundColor Cyan
        Write-Host "  PUBLIC URL (share with anyone!)" -ForegroundColor Green
        Write-Host "  $url" -ForegroundColor White
        Write-Host "============================================" -ForegroundColor Cyan
        Write-Host ""
        $shortcutContent = "[InternetShortcut]`r`nURL=$url`r`n"
        Set-Content -Path "$PSScriptRoot\smartexpensetracker-public.url" -Value $shortcutContent -Force
        if (Test-Path "$env:USERPROFILE\OneDrive\Desktop") {
            Set-Content -Path "$env:USERPROFILE\OneDrive\Desktop\smartexpensetracker-public.url" -Value $shortcutContent -Force
        }
    }
    
    $proc.WaitForExit()
    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Tunnel disconnected. Reconnecting in 5s..." -ForegroundColor Red
    Start-Sleep -Seconds 5
}
