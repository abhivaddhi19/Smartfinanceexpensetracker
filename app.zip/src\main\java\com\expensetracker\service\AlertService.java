package com.expensetracker.service;

import com.expensetracker.model.Alert;
import com.expensetracker.model.User;
import com.expensetracker.repository.AlertRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

@Service
public class AlertService {

    @Autowired
    private AlertRepository alertRepository;

    public List<Alert> getAllAlerts(Long userId) {
        return alertRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    public List<Alert> getUnreadAlerts(Long userId) {
        return alertRepository.findByUserIdAndIsReadFalseOrderByCreatedAtDesc(userId);
    }

    public long getUnreadCount(Long userId) {
        return alertRepository.countByUserIdAndIsReadFalse(userId);
    }

    @Transactional
    public void markAsRead(Long alertId, Long userId) {
        alertRepository.findById(Objects.requireNonNull(alertId)).ifPresent(alert -> {
            if (alert.getUser().getId().equals(userId)) {
                alert.setIsRead(true);
                alertRepository.save(alert);
            }
        });
    }

    @Transactional
    public void markAllAsRead(Long userId) {
        alertRepository.markAllAsReadForUser(userId);
    }

    @Transactional
    public Alert createAlert(User user, String title, String message, String alertType) {
        // Simple deduplication for today
        List<Alert> recent = alertRepository.findByUserIdOrderByCreatedAtDesc(user.getId());
        boolean exists = recent.stream().anyMatch(a ->
                a.getTitle().equalsIgnoreCase(title) &&
                a.getCreatedAt().toLocalDate().isEqual(LocalDate.now()));

        if (!exists) {
            Alert alert = new Alert(user, title, message, alertType);
            return alertRepository.save(alert);
        }
        return null;
    }
}
