package com.expensetracker.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class ReceiptScanResultDto {
    private boolean success;
    private String merchantName;
    private LocalDate date;
    private BigDecimal totalAmount;
    private String suggestedCategory;
    private Long suggestedCategoryId;
    private List<String> detectedItems;
    private String rawText;
    private String receiptImagePath;
    private String message;

    public ReceiptScanResultDto() {}

    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }

    public String getMerchantName() { return merchantName; }
    public void setMerchantName(String merchantName) { this.merchantName = merchantName; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }

    public String getSuggestedCategory() { return suggestedCategory; }
    public void setSuggestedCategory(String suggestedCategory) { this.suggestedCategory = suggestedCategory; }

    public Long getSuggestedCategoryId() { return suggestedCategoryId; }
    public void setSuggestedCategoryId(Long suggestedCategoryId) { this.suggestedCategoryId = suggestedCategoryId; }

    public List<String> getDetectedItems() { return detectedItems; }
    public void setDetectedItems(List<String> detectedItems) { this.detectedItems = detectedItems; }

    public String getRawText() { return rawText; }
    public void setRawText(String rawText) { this.rawText = rawText; }

    public String getReceiptImagePath() { return receiptImagePath; }
    public void setReceiptImagePath(String receiptImagePath) { this.receiptImagePath = receiptImagePath; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}
