package com.expensetracker.service;

import com.expensetracker.model.*;
import com.expensetracker.repository.*;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Objects;

@Service
public class DemoDataService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private BudgetRepository budgetRepository;

    @Autowired
    private AlertRepository alertRepository;

    @Autowired
    private BankTransactionRepository bankTransactionRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostConstruct
    public void initDemoData() {
        // 1. Initialize default categories
        initDefaultCategories();

        // 2. Initialize demo user
        User demoUser = userRepository.findByEmail("demo@expensetracker.com").orElseGet(() -> {
            User u = new User("Rahul Sharma", "demo@expensetracker.com", "+91 9876543210", passwordEncoder.encode("Password123"));
            u.setCurrency("₹");
            return userRepository.save(u);
        });

        // 3. Initialize custom categories for demo user
        Category gymCat = categoryRepository.findByNameIgnoreCaseAndUserId("Gym", demoUser.getId())
                .orElseGet(() -> categoryRepository.save(new Category("Gym", "fa-dumbbell", "Fitness & gym membership", demoUser)));

        Category subCat = categoryRepository.findByNameIgnoreCaseAndUserId("Subscriptions", demoUser.getId())
                .orElseGet(() -> categoryRepository.save(new Category("Subscriptions", "fa-repeat", "Digital subscriptions & OTT", demoUser)));

        // 4. Initialize demo transactions if empty
        if (transactionRepository.findByUserIdOrderByTransactionDateDescCreatedAtDesc(demoUser.getId()).isEmpty()) {
            initSampleTransactions(demoUser, gymCat, subCat);
        }

        // 5. Initialize demo budget
        LocalDate now = LocalDate.now();
        int month = now.getMonthValue();
        int year = now.getYear();

        if (budgetRepository.findByUserIdAndMonthAndYear(demoUser.getId(), month, year).isEmpty()) {
            budgetRepository.save(new Budget(demoUser, month, year, new BigDecimal("40000.00")));
        }

        // 6. Initialize demo alerts if empty
        if (alertRepository.findByUserIdOrderByCreatedAtDesc(demoUser.getId()).isEmpty()) {
            alertRepository.save(new Alert(demoUser, "Budget Notice (83% Used)",
                    "Warning: You have used 83% of your monthly budget (₹33,247 of ₹40,000).", "BUDGET"));
            alertRepository.save(new Alert(demoUser, "High Shopping Spend",
                    "You spent ₹4,200 on Shopping this month. Keep track of non-essential purchases.", "HIGH_SPENDING"));
            alertRepository.save(new Alert(demoUser, "Bill Reminder",
                    "Electricity bill of ₹1,800 was paid on 10-09-2026.", "BILL_REMINDER"));
        }

        // 7. Initialize staged bank statement records for import demo
        if (bankTransactionRepository.findByUserIdOrderByTransactionDateDesc(demoUser.getId()).isEmpty()) {
            Category food = categoryRepository.findByNameIgnoreCaseForUser("Food", demoUser.getId()).orElse(null);
            Category grocery = categoryRepository.findByNameIgnoreCaseForUser("Grocery", demoUser.getId()).orElse(null);
            Category travel = categoryRepository.findByNameIgnoreCaseForUser("Travel", demoUser.getId()).orElse(null);

            BankTransaction b1 = new BankTransaction();
            b1.setUser(demoUser);
            b1.setTransactionDate(now.minusDays(1));
            b1.setDescription("UPI/SWIGGY/ORDER-84920/BANGALORE");
            b1.setDebit(new BigDecimal("450.00"));
            b1.setCredit(BigDecimal.ZERO);
            b1.setBalance(new BigDecimal("17050.00"));
            b1.setCategory(food);
            b1.setStatus("PENDING");

            BankTransaction b2 = new BankTransaction();
            b2.setUser(demoUser);
            b2.setTransactionDate(now.minusDays(2));
            b2.setDescription("UBER INDIA RIDES PVT LTD");
            b2.setDebit(new BigDecimal("320.00"));
            b2.setCredit(BigDecimal.ZERO);
            b2.setBalance(new BigDecimal("17500.00"));
            b2.setCategory(travel);
            b2.setStatus("PENDING");

            BankTransaction b3 = new BankTransaction();
            b3.setUser(demoUser);
            b3.setTransactionDate(now.minusDays(3));
            b3.setDescription("BLINKIT GROCERY DELIVERY");
            b3.setDebit(new BigDecimal("890.00"));
            b3.setCredit(BigDecimal.ZERO);
            b3.setBalance(new BigDecimal("17820.00"));
            b3.setCategory(grocery);
            b3.setStatus("PENDING");

            bankTransactionRepository.saveAll(Objects.requireNonNull(Arrays.asList(b1, b2, b3)));
        }
    }

    private void initDefaultCategories() {
        String[][] defaults = {
                {"Food", "fa-utensils", "Dining out, cafes, and restaurant expenses"},
                {"Grocery", "fa-basket-shopping", "Daily household groceries and vegetables"},
                {"Shopping", "fa-bag-shopping", "Apparel, electronics, and personal shopping"},
                {"Travel", "fa-plane-departure", "Flights, trains, cabs, and daily transit"},
                {"Rent", "fa-house", "Monthly house or apartment rent"},
                {"Electricity", "fa-bolt", "Power and electricity utility bills"},
                {"Water", "fa-faucet-drip", "Municipal water supply and tanker bills"},
                {"Internet", "fa-wifi", "Broadband, fiber, and home Wi-Fi"},
                {"Mobile", "fa-mobile-screen", "Mobile prepaid recharge and postpaid bills"},
                {"Education", "fa-graduation-cap", "Tuition fees, books, and courses"},
                {"Healthcare", "fa-heart-pulse", "Medicines, doctor visits, and pharmacy"},
                {"Entertainment", "fa-film", "Movies, OTT streams, and outings"},
                {"EMI", "fa-money-bill-transfer", "Loan EMIs and credit card minimum payments"},
                {"Insurance", "fa-shield-halved", "Health, term, and vehicle insurance"},
                {"Fuel", "fa-gas-pump", "Petrol, diesel, and EV charging"},
                {"Bills", "fa-file-invoice-dollar", "General utility and maintenance bills"},
                {"Other", "fa-ellipsis", "Miscellaneous uncategorized expenses"}
        };

        for (String[] def : defaults) {
            String name = def[0];
            String icon = def[1];
            String desc = def[2];
            if (categoryRepository.findByNameIgnoreCaseAndUserIsNull(name).isEmpty()) {
                categoryRepository.save(new Category(name, icon, desc, null));
            }
        }
    }

    private void initSampleTransactions(User user, Category gymCat, Category subCat) {
        LocalDate today = LocalDate.now();
        int month = today.getMonthValue();
        int year = today.getYear();

        Category food = getCat("Food", user);
        Category grocery = getCat("Grocery", user);
        Category shopping = getCat("Shopping", user);
        Category travel = getCat("Travel", user);
        Category rent = getCat("Rent", user);
        Category electricity = getCat("Electricity", user);
        Category internet = getCat("Internet", user);
        Category fuel = getCat("Fuel", user);
        Category health = getCat("Healthcare", user);
        getCat("Bills", user); // Ensure Bills category exists

        // Incomes
        createTx(user, "50000.00", "INCOME", null, "Monthly Salary Credit", LocalDate.of(year, month, 1), "BANK_TRANSFER", "TechCorp Ltd");
        createTx(user, "15000.00", "INCOME", null, "Freelance UI Consulting", LocalDate.of(year, month, 10), "UPI", "Client Upwork");

        // Expenses for current month
        createTx(user, "12000.00", "EXPENSE", rent, "Apartment Monthly Rent", LocalDate.of(year, month, 2), "BANK_TRANSFER", "Landlord Housing");
        createTx(user, "4500.00", "EXPENSE", grocery, "Monthly Supermarket Groceries", LocalDate.of(year, month, 3), "DEBIT_CARD", "Reliance Smart");
        createTx(user, "1800.00", "EXPENSE", electricity, "Electricity Board Power Bill", LocalDate.of(year, month, 5), "UPI", "State Power Corp");
        createTx(user, "999.00", "EXPENSE", internet, "High-Speed Fiber Broadband", LocalDate.of(year, month, 6), "UPI", "Airtel Xstream");
        createTx(user, "4200.00", "EXPENSE", shopping, "Running Shoes & Activewear", LocalDate.of(year, month, 8), "CREDIT_CARD", "Nike Store");
        createTx(user, "2100.00", "EXPENSE", fuel, "Full Tank Petrol", LocalDate.of(year, month, 11), "CREDIT_CARD", "Shell Station");
        createTx(user, "1500.00", "EXPENSE", gymCat, "Gold's Gym Monthly Pass", LocalDate.of(year, month, 12), "UPI", "FitHub Gym");
        createTx(user, "1499.00", "EXPENSE", subCat, "Netflix & Spotify Subscriptions", LocalDate.of(year, month, 13), "CREDIT_CARD", "Digital Services");
        createTx(user, "1650.00", "EXPENSE", food, "Weekend Family Dinner", LocalDate.of(year, month, 14), "CREDIT_CARD", "Barbeque Nation");
        createTx(user, "820.00", "EXPENSE", health, "Vitamins & Prescription Meds", LocalDate.of(year, month, 15), "UPI", "Apollo Pharmacy");
        createTx(user, "550.00", "EXPENSE", food, "Office Team Lunch", LocalDate.of(year, month, 16), "UPI", "Cafe Coffee Day");
        createTx(user, "850.00", "EXPENSE", travel, "Cab to Airport", LocalDate.of(year, month, 17), "UPI", "Uber India");
        createTx(user, "778.00", "EXPENSE", food, "Dinner & Pizza delivery", today, "UPI", "Domino's Pizza");
    }

    private Category getCat(String name, User user) {
        return categoryRepository.findByNameIgnoreCaseForUser(name, user.getId()).orElse(null);
    }

    private void createTx(User user, String amount, String type, Category cat, String desc, LocalDate date, String method, String merchant) {
        Transaction tx = new Transaction();
        tx.setUser(user);
        tx.setAmount(new BigDecimal(amount));
        tx.setType(type);
        tx.setCategory(cat);
        tx.setDescription(desc);
        tx.setTransactionDate(date);
        tx.setPaymentMethod(method);
        tx.setMerchantName(merchant);
        tx.setNotes("Logged via Smart Expense Tracker");
        transactionRepository.save(tx);
    }
}
