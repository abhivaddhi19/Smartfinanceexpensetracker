/**
 * Smart Expense Tracker & Personal Finance Management System
 * API Client Module
 */

const API = {
    baseUrl: '/api',

    async request(endpoint, options = {}) {
        const url = `${this.baseUrl}${endpoint}`;
        const headers = options.headers || {};

        if (!(options.body instanceof FormData)) {
            headers['Content-Type'] = 'application/json';
        }

        const config = {
            ...options,
            headers,
            credentials: 'same-origin'
        };

        try {
            const response = await fetch(url, config);
            if (response.status === 401 && !endpoint.includes('/auth/')) {
                window.location.hash = '#login';
                throw new Error('Session expired. Please log in.');
            }

            if (response.status === 204) {
                return null;
            }

            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                const data = await response.json();
                if (!response.ok) {
                    throw new Error(data.message || 'Request failed');
                }
                return data;
            }

            if (!response.ok) {
                const text = await response.text();
                throw new Error(text || 'Request failed');
            }

            return response;
        } catch (error) {
            console.error(`API Error on ${endpoint}:`, error);
            throw error;
        }
    },

    // Auth
    auth: {
        login: (email, password) => API.request('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        }),
        register: (data) => API.request('/auth/register', {
            method: 'POST',
            body: JSON.stringify(data)
        }),
        getCurrentUser: () => API.request('/auth/current-user'),
        logout: () => API.request('/auth/logout', { method: 'POST' })
    },

    // Dashboard
    dashboard: {
        getSummary: (month, year) => {
            const params = new URLSearchParams();
            if (month) params.append('month', month);
            if (year) params.append('year', year);
            return API.request(`/dashboard/summary?${params.toString()}`);
        },
        getRecentTransactions: (limit = 5) => API.request(`/dashboard/recent-transactions?limit=${limit}`)
    },

    // Transactions
    transactions: {
        list: (filters = {}) => {
            const params = new URLSearchParams();
            Object.entries(filters).forEach(([key, val]) => {
                if (val !== undefined && val !== null && val !== '') {
                    params.append(key, val);
                }
            });
            return API.request(`/transactions?${params.toString()}`);
        },
        get: (id) => API.request(`/transactions/${id}`),
        create: (data) => API.request('/transactions', {
            method: 'POST',
            body: JSON.stringify(data)
        }),
        update: (id, data) => API.request(`/transactions/${id}`, {
            method: 'PUT',
            body: JSON.stringify(data)
        }),
        delete: (id) => API.request(`/transactions/${id}`, { method: 'DELETE' }),
        exportUrl: () => `${API.baseUrl}/transactions/export`
    },

    // Categories
    categories: {
        list: () => API.request('/categories'),
        create: (data) => API.request('/categories', {
            method: 'POST',
            body: JSON.stringify(data)
        }),
        update: (id, data) => API.request(`/categories/${id}`, {
            method: 'PUT',
            body: JSON.stringify(data)
        }),
        delete: (id) => API.request(`/categories/${id}`, { method: 'DELETE' })
    },

    // Budget
    budget: {
        get: (month, year) => {
            const params = new URLSearchParams();
            if (month) params.append('month', month);
            if (year) params.append('year', year);
            return API.request(`/budget?${params.toString()}`);
        },
        set: (month, year, amount) => API.request('/budget', {
            method: 'POST',
            body: JSON.stringify({ month, year, amount })
        })
    },

    // Analysis
    analysis: {
        getDaily: (date) => API.request(`/analysis/daily${date ? '?date=' + date : ''}`),
        getWeekly: (date) => API.request(`/analysis/weekly${date ? '?date=' + date : ''}`),
        getMonthly: (month, year) => {
            const params = new URLSearchParams();
            if (month) params.append('month', month);
            if (year) params.append('year', year);
            return API.request(`/analysis/monthly?${params.toString()}`);
        },
        getCategories: (startDate, endDate) => {
            const params = new URLSearchParams();
            if (startDate) params.append('startDate', startDate);
            if (endDate) params.append('endDate', endDate);
            return API.request(`/analysis/categories?${params.toString()}`);
        }
    },

    // Alerts
    alerts: {
        list: (unreadOnly = false) => API.request(`/alerts?unreadOnly=${unreadOnly}`),
        unreadCount: () => API.request('/alerts/unread-count'),
        markAsRead: (id) => API.request(`/alerts/${id}/read`, { method: 'PUT' }),
        markAllAsRead: () => API.request('/alerts/mark-all-read', { method: 'PUT' })
    },

    // Suggestions
    suggestions: {
        list: () => API.request('/suggestions')
    },

    // Scanner
    scanner: {
        scanReceipt: (file) => {
            const formData = new FormData();
            formData.append('file', file);
            return API.request('/scanner/receipt', {
                method: 'POST',
                body: formData
            });
        }
    },

    // Bank
    bank: {
        importStatement: (file) => {
            const formData = new FormData();
            formData.append('file', file);
            return API.request('/bank/import', {
                method: 'POST',
                body: formData
            });
        },
        getPending: () => API.request('/bank/pending'),
        confirm: (items) => API.request('/bank/confirm', {
            method: 'POST',
            body: JSON.stringify(items)
        }),
        clearPending: () => API.request('/bank/pending', {
            method: 'DELETE'
        })
    },

    // Reports
    reports: {
        getMonthly: (month, year) => {
            const params = new URLSearchParams();
            if (month) params.append('month', month);
            if (year) params.append('year', year);
            return API.request(`/reports/monthly?${params.toString()}`);
        },
        getCategory: (categoryId, month, year) => {
            const params = new URLSearchParams();
            params.append('categoryId', categoryId);
            if (month) params.append('month', month);
            if (year) params.append('year', year);
            return API.request(`/reports/category?${params.toString()}`);
        },
        getPdfUrl: (month, year) => {
            const params = new URLSearchParams();
            if (month) params.append('month', month);
            if (year) params.append('year', year);
            return `${API.baseUrl}/reports/monthly/pdf?${params.toString()}`;
        }
    },

    // Profile
    profile: {
        get: () => API.request('/profile'),
        update: (data) => API.request('/profile', {
            method: 'PUT',
            body: JSON.stringify(data)
        }),
        changePassword: (data) => API.request('/profile/password', {
            method: 'PUT',
            body: JSON.stringify(data)
        })
    }
};
