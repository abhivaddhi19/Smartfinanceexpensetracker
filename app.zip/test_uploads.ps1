$s = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$loginBody = '{"email":"demo@expensetracker.com","password":"Password123"}'
$login = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/login" -Method Post -ContentType "application/json" -Body $loginBody -WebSession $s
Write-Host "Login: $($login.message)" -ForegroundColor Cyan

# Test Bank Statement CSV Upload
try {
    $filePath = "C:\Users\sniper\OneDrive\Desktop\AOOP\src\main\resources\static\samples\sample_bank_statement.csv"
    $fileBytes = [System.IO.File]::ReadAllBytes($filePath)
    $fileEnc = [System.Text.Encoding]::GetEncoding('iso-8859-1').GetString($fileBytes)
    $boundary = [System.Guid]::NewGuid().ToString()
    $LF = "`r`n"
    $body = "--$boundary$LF" +
            "Content-Disposition: form-data; name=`"file`"; filename=`"sample_bank_statement.csv`"$LF" +
            "Content-Type: text/csv$LF$LF" +
            "$fileEnc$LF" +
            "--$boundary--$LF"

    $importRes = Invoke-RestMethod -Uri "http://localhost:8080/api/bank/import" -Method Post -ContentType "multipart/form-data; boundary=$boundary" -Body $body -WebSession $s
    Write-Host "[PASS] Bank Import: $($importRes.message), items: $($importRes.transactions.Count)" -ForegroundColor Green
} catch {
    Write-Host "[FAIL] Bank Import: $($_.Exception.Message)" -ForegroundColor Red
}

# Test Receipt Scanner Upload
try {
    $receiptPath = "C:\Users\sniper\OneDrive\Desktop\AOOP\src\main\resources\static\samples\reliance_smart_receipt.jpg"
    $fileBytes = [System.IO.File]::ReadAllBytes($receiptPath)
    $fileEnc = [System.Text.Encoding]::GetEncoding('iso-8859-1').GetString($fileBytes)
    $boundary = [System.Guid]::NewGuid().ToString()
    $LF = "`r`n"
    $body = "--$boundary$LF" +
            "Content-Disposition: form-data; name=`"file`"; filename=`"reliance_smart_receipt.jpg`"$LF" +
            "Content-Type: image/jpeg$LF$LF" +
            "$fileEnc$LF" +
            "--$boundary--$LF"

    $scanRes = Invoke-RestMethod -Uri "http://localhost:8080/api/scanner/receipt" -Method Post -ContentType "multipart/form-data; boundary=$boundary" -Body $body -WebSession $s
    Write-Host "[PASS] Receipt Scanner: Merchant: $($scanRes.merchantName), Amount: $($scanRes.totalAmount), Category: $($scanRes.suggestedCategory)" -ForegroundColor Green
} catch {
    Write-Host "[FAIL] Receipt Scanner: $($_.Exception.Message)" -ForegroundColor Red
}
