package com.expensetracker.service;

import com.expensetracker.dto.BudgetDto;
import com.expensetracker.dto.TransactionDto;
import com.expensetracker.model.Transaction;
import com.expensetracker.model.User;
import com.expensetracker.repository.CategoryRepository;
import com.expensetracker.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private BudgetService budgetService;

    @Autowired
    private AlertService alertService;

    public List<TransactionDto> getRecentTransactions(Long userId, int limit) {
        List<Transaction> list = limit <= 5 ?
                transactionRepository.findTop5ByUserIdOrderByTransactionDateDescCreatedAtDesc(userId) :
                transactionRepository.findTop10ByUserIdOrderByTransactionDateDescCreatedAtDesc(userId);

        return list.stream().map(this::toDto).collect(Collectors.toList());
    }

    public List<TransactionDto> getAllTransactions(Long userId) {
        return transactionRepository.findByUserIdOrderByTransactionDateDescCreatedAtDesc(userId)
                .stream().map(this::toDto).collect(Collectors.toList());
    }

    public List<TransactionDto> searchTransactions(
            Long userId, String type, Long categoryId, LocalDate startDate, LocalDate endDate,
            String paymentMethod, BigDecimal minAmount, BigDecimal maxAmount, String keyword) {

        return transactionRepository.searchTransactions(
                userId,
                (type != null && !type.trim().isEmpty() && !"ALL".equalsIgnoreCase(type)) ? type.toUpperCase() : null,
                categoryId,
                startDate,
                endDate,
                (paymentMethod != null && !paymentMethod.trim().isEmpty() && !"ALL".equalsIgnoreCase(paymentMethod)) ? paymentMethod : null,
                minAmount,
                maxAmount,
                (keyword != null && !keyword.trim().isEmpty()) ? keyword.trim() : null
        ).stream().map(this::toDto).collect(Collectors.toList());
    }

    public TransactionDto getTransactionById(Long id, Long userId) {
        Transaction tx = transactionRepository.findById(Objects.requireNonNull(id))
                .orElseThrow(() -> new IllegalArgumentException("Transaction not found"));
        if (!tx.getUser().getId().equals(userId)) {
            throw new SecurityException("Unauthorized access to transaction");
        }
        return toDto(tx);
    }

    @Transactional
    public TransactionDto createTransaction(User user, TransactionDto dto) {
        validateTransaction(dto);

        Transaction tx = new Transaction();
        tx.setUser(user);
        tx.setAmount(dto.getAmount());
        tx.setType(dto.getType().toUpperCase());
        tx.setDescription(dto.getDescription());
        tx.setTransactionDate(dto.getTransactionDate() != null ? dto.getTransactionDate() : LocalDate.now());
        tx.setPaymentMethod(dto.getPaymentMethod());
        tx.setMerchantName(dto.getMerchantName());
        tx.setNotes(dto.getNotes());
        tx.setReceiptPath(dto.getReceiptPath());
        tx.setCreatedAt(LocalDateTime.now());

        if (dto.getCategoryId() != null) {
            categoryRepository.findById(Objects.requireNonNull(dto.getCategoryId())).ifPresent(tx::setCategory);
        }

        Transaction saved = transactionRepository.save(tx);

        // Check alerts
        performPostTransactionChecks(user, saved);

        return toDto(saved);
    }

    @Transactional
    public TransactionDto updateTransaction(User user, Long id, TransactionDto dto) {
        validateTransaction(dto);

        Transaction tx = transactionRepository.findById(Objects.requireNonNull(id))
                .orElseThrow(() -> new IllegalArgumentException("Transaction not found"));

        if (!tx.getUser().getId().equals(user.getId())) {
            throw new SecurityException("Unauthorized access to transaction");
        }

        tx.setAmount(dto.getAmount());
        tx.setType(dto.getType().toUpperCase());
        tx.setDescription(dto.getDescription());
        tx.setTransactionDate(dto.getTransactionDate());
        tx.setPaymentMethod(dto.getPaymentMethod());
        tx.setMerchantName(dto.getMerchantName());
        tx.setNotes(dto.getNotes());
        if (dto.getReceiptPath() != null) {
            tx.setReceiptPath(dto.getReceiptPath());
        }

        if (dto.getCategoryId() != null) {
            categoryRepository.findById(Objects.requireNonNull(dto.getCategoryId())).ifPresent(tx::setCategory);
        } else {
            tx.setCategory(null);
        }

        Transaction updated = transactionRepository.save(tx);
        performPostTransactionChecks(user, updated);
        return toDto(updated);
    }

    @Transactional
    public void deleteTransaction(User user, Long id) {
        Transaction tx = transactionRepository.findById(Objects.requireNonNull(id))
                .orElseThrow(() -> new IllegalArgumentException("Transaction not found"));

        if (!tx.getUser().getId().equals(user.getId())) {
            throw new SecurityException("Unauthorized access to transaction");
        }

        transactionRepository.delete(tx);
    }

    private void performPostTransactionChecks(User user, Transaction tx) {
        // 1. Budget check if expense
        if ("EXPENSE".equalsIgnoreCase(tx.getType())) {
            int month = tx.getTransactionDate().getMonthValue();
            int year = tx.getTransactionDate().getYear();
            BudgetDto budgetDetails = budgetService.getBudgetDetails(user, month, year);
            budgetService.checkAndTriggerBudgetAlert(user, budgetDetails);

            // 2. High spending alert
            if (tx.getAmount().compareTo(BigDecimal.valueOf(5000)) >= 0) {
                alertService.createAlert(user,
                        "High Spending Alert",
                        "You spent " + user.getCurrency() + tx.getAmount() + " on " + tx.getDescription() + " (" + (tx.getCategory() != null ? tx.getCategory().getName() : "Uncategorized") + ").",
                        "HIGH_SPENDING");
            }
        }

        // 3. Low balance check
        BigDecimal totalInc = transactionRepository.sumAmountByUserIdAndType(user.getId(), "INCOME");
        BigDecimal totalExp = transactionRepository.sumAmountByUserIdAndType(user.getId(), "EXPENSE");
        BigDecimal balance = (totalInc != null ? totalInc : BigDecimal.ZERO).subtract(totalExp != null ? totalExp : BigDecimal.ZERO);

        if (balance.compareTo(BigDecimal.valueOf(3000)) < 0) {
            alertService.createAlert(user,
                    "Low Balance Alert",
                    "Your current balance has fallen to " + user.getCurrency() + balance + ". Please review upcoming expenses.",
                    "LOW_BALANCE");
        }
    }

    private void validateTransaction(TransactionDto dto) {
        if (dto.getAmount() == null || dto.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Amount must be greater than 0");
        }
        if (dto.getType() == null || (!dto.getType().equalsIgnoreCase("INCOME") && !dto.getType().equalsIgnoreCase("EXPENSE"))) {
            throw new IllegalArgumentException("Transaction type must be either INCOME or EXPENSE");
        }
        if (dto.getDescription() == null || dto.getDescription().trim().isEmpty()) {
            throw new IllegalArgumentException("Description cannot be empty");
        }
        if (dto.getTransactionDate() == null) {
            throw new IllegalArgumentException("Transaction date is required");
        }
        if (dto.getPaymentMethod() == null || dto.getPaymentMethod().trim().isEmpty()) {
            throw new IllegalArgumentException("Payment method is required");
        }
    }

    public TransactionDto toDto(Transaction tx) {
        TransactionDto dto = new TransactionDto();
        dto.setId(tx.getId());
        dto.setAmount(tx.getAmount());
        dto.setType(tx.getType());
        dto.setDescription(tx.getDescription());
        dto.setTransactionDate(tx.getTransactionDate());
        dto.setPaymentMethod(tx.getPaymentMethod());
        dto.setMerchantName(tx.getMerchantName());
        dto.setNotes(tx.getNotes());
        dto.setReceiptPath(tx.getReceiptPath());

        if (tx.getCategory() != null) {
            dto.setCategoryId(tx.getCategory().getId());
            dto.setCategoryName(tx.getCategory().getName());
            dto.setCategoryIcon(tx.getCategory().getIcon());
        } else {
            if ("INCOME".equalsIgnoreCase(tx.getType())) {
                dto.setCategoryName("Income");
                dto.setCategoryIcon("fa-arrow-down-left");
            } else {
                dto.setCategoryName("Other");
                dto.setCategoryIcon("fa-ellipsis");
            }
        }
        return dto;
    }
}
