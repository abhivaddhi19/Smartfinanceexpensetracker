package com.expensetracker.controller;

import com.expensetracker.model.User;
import com.expensetracker.security.SecurityUtil;
import com.expensetracker.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @Autowired
    private SecurityUtil securityUtil;

    @GetMapping("/monthly")
    public ResponseEntity<Map<String, Object>> getMonthlyReport(
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year) {

        User user = securityUtil.getRequiredCurrentUser();
        LocalDate now = LocalDate.now();
        int m = month != null ? month : now.getMonthValue();
        int y = year != null ? year : now.getYear();

        return ResponseEntity.ok(reportService.getMonthlyReportData(user, m, y));
    }

    @GetMapping("/category")
    public ResponseEntity<Map<String, Object>> getCategoryReport(
            @RequestParam Long categoryId,
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year) {

        User user = securityUtil.getRequiredCurrentUser();
        LocalDate now = LocalDate.now();
        int m = month != null ? month : now.getMonthValue();
        int y = year != null ? year : now.getYear();

        return ResponseEntity.ok(reportService.getCategoryReportData(user, categoryId, m, y));
    }

    @GetMapping("/monthly/pdf")
    public ResponseEntity<byte[]> downloadMonthlyPdfReport(
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year) {

        User user = securityUtil.getRequiredCurrentUser();
        LocalDate now = LocalDate.now();
        int m = month != null ? month : now.getMonthValue();
        int y = year != null ? year : now.getYear();

        byte[] pdfBytes = reportService.generateMonthlyPdfReport(user, m, y);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData("attachment", "Finance_Report_" + m + "_" + y + ".pdf");
        headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");

        return ResponseEntity.ok()
                .headers(headers)
                .body(pdfBytes);
    }
}
